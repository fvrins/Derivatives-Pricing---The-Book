T=2
n=1000
delta=T/n
t=seq(0,n)*delta # length is n+1

set.seed(1)
W<-c(0,cumsum(rnorm(n))*sqrt(delta))
mW=min(W)-0.02
MW=max(W)+0.02
X<-sin(W)
mX=min(X)-0.02
MX=max(X)+0.02
dev.new()
par(mfrow=c(1,2))
plot(t,W,type="l",col="blue",main="Brownian Motion",ylim=c(mW,MW))
plot(t,X,type="l",col="blue",main="X (blue) and Xn (red)",ylim=c(mX,MX))

Xn=0*W
for(i in 1:n){
  Xn[i+1]=Xn[i]+cos(W[i])*(W[i+1]-W[i])-0.5*sin(W[i])*delta
}
points(t,Xn,type="l",col="red",lty=2)


