
# This code aims at illustrating Monte Carlo estimation by approximating \int_a^b x^2 dx

a = -2
b = 2
N = 1000000

# analytical result
res.th=(b^3-a^3)/3

# MC sample

# choice: Normal

g=function(x){
	ind=which(x>a & x<b)
	x.ind=x[ind]
	r=(x.ind^2)/dnorm(x.ind)
	return(r)
}
u=runif(N)
x=qnorm(u) # equivalent to x=rnorm(N)

res.mc=sum(g(x))/N

print(paste("Exact (analytical) result: ", res.th))
print(paste("Approx (Monte Carlo) result: ", res.mc))