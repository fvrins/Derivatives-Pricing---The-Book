
# This code allows you to generate M pairs (xi,yi) of samples drawn from a bivariate Normal vector (X,Y)
# where X~N(mu.X,sd.X) , Y~N(mu.Y,sd.Y) and correlation between X and Y is rho

# PARAMETERS
# -----------------------

M = 1000 # number of samples

mu.X = 2	# E[X]
sd.X = 3	# sqrt Var[X]

mu.Y = -5	# E[Y]
sd.Y = 1	# sqrt Var[Y]

rho  = 0.4	# correlation bw (X,Y)

# SAMPLES OF UNDELRYING VARBIALES Z1 and Z2
# ------------------------------------------

# draw M samples from Z1~N(0,1) and Z2~N(0,1) where Z1 indepent of Z2
z1 = rnorm(M)
z2 = rnorm(M)

# SAMPLES OF X AND Y FROM Z1 AND Z2
# -----------------------------------

# build X~N(mu.X,sd.X^2) froma linear transform of Z1
x = mu.X + sd.X*z1

# build Y~N(mu.Y,sd.Y^2) froma linear transform of Z1 and Z2
y = mu.Y + sd.Y*(rho*z1 + sqrt(1-rho^2)*z2)

# CHECK THAT SAMPLE MEAN, STD DEVIATION AND CORRELATION ARE IN LINE WITH SPECIFIED VALUES
# ----------------------------------------------------------------------------------------

#check sample mean and standard deviation
print(c("sample mean of x: ",mean(x)))			# should be close to mu.X
print(c("Sample std dev of x: ",sd(x)))			# should be close to sd.X
print(c("sample mean of y: ",mean(y)))			# should be close to mu.Y
print(c("Sample std dev of y: ",sd(y)))			# should be close to mu.Y
print(c("Sample correlation of (x,y): ",cor(x,y)))	# should be close to rho

# PLOTS
# ---------

par(mfrow=c(1,3)) # make a 1x3 array of plots

# histogram of x and comparison with density of X~N(mu.X,sd.X^2)
hist(x,prob=TRUE,col="grey",breaks=20)
s=seq(min(x),max(x),.1)		
points(s,dnorm(s,mu.X,sd.X),type="l",col="red",lwd=2)

# histogram of y and comparison with density of Y~N(mu.Y,sd.Y^2)
hist(y,prob=TRUE,col="grey",breaks=20)
s=seq(min(y),max(y),.1)
points(s,dnorm(s,mu.Y,sd.Y),type="l",col="red",lwd=2)

# scatter plot of x vs y
plot(x,y,pch=19,col="blue",title="Scatter plot (X,Y)")