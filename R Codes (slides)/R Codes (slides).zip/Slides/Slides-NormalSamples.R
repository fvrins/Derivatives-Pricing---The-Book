rm(list = ls())

n=1000 # nb of samples
u=runif(n) # draw $n=1000$ samples from standard continuous uniform
x=qnorm(u) #  convert the $u_i$ to $x_i=\Phi^{-1}(u_i)$
par(mfrow=c(1,2)) # make a $1\times 2$ array of figures
plot(ecdf(x),col="blue",main="CDF",xlab="x",ylab="F(x)")
s=seq(-5,5,.01) # generate a vector $(-5,-4.99,-4.98,\ldots,4.99,5)$
points(s,pnorm(s),type="l",col="red",lty=2) #  $\Phi(s)$
hist(x,prob=TRUE,col="blue",main="Histogram")
points(s,dnorm(s),type="l",col="red",lwd=2) #  $\phi(s)$