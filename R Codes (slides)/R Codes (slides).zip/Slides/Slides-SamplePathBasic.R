#source("SamplePathBasic.R")

Y=matrix(0,nrow=3,ncol=15)
Y[1,]=c(1,3,5,3,6,4,1,4,2,5,1,2,5,6,4)
Y[2,]=c(4,3,2,1,3,1,4,3,5,1,4,6,2,5,3)
Y[3,]=c(6,3,6,4,1,6,1,5,4,3,4,1,4,5,6)

dev.new
par(mfrow=c(1,2))

plot(seq(1,15,1),rep(1,15),xlim=c(1,15),ylim=c(1,6),type="l",lty=3,col="black",xaxt="n",xlab="Time [min]",ylab="Space",main=expression(X(omega)))
axis(1, at=seq(1,15,1), labels=seq(1,15,1))
points(seq(1,15,1),Y[1,],type="p",pch=19,col="blue")
points(seq(1,15,1),Y[2,],type="p",pch=10,col="red")
points(seq(1,15,1),Y[3,],type="p",pch=13,col="green")
points(seq(1,15,1),Y[1,],type="l",lty=2,col="blue",lwd=2)
points(seq(1,15,1),Y[2,],type="l",lty=2,col="red",lwd=2)
points(seq(1,15,1),Y[3,],type="l",lty=2,col="green",lwd=2)
for(i in 1:15){
	points(c(i,i),c(1,6),col="black",type="l",lty=3)
}
points(c(1,15),rep(6,2),type="l",lty=3,col="black")


S=matrix(0,nrow=3,ncol=16)

for(j in 2:16){
	S[,j]=S[,j-1]+Y[,j-1]
}

yM=max(S)
ym=1

plot(seq(0,15,1),rep(0,16),ylim=c(ym,yM),type="l",lty=3,col="black",xaxt="n",xlab="Time [min]",ylab="Space",main=expression(Z(omega)))
axis(1, at=0:15, labels=c(0:15))

points(c(0,0),c(ym,yM),type="l",lty=3)
points(c(1,1),c(ym,yM),col="black",type="l",lty=3)
points(c(2,2),c(ym,yM),col="black",type="l",lty=3)
points(c(3,3),c(ym,yM),col="black",type="l",lty=3)
points(c(4,4),c(ym,yM),col="black",type="l",lty=3)
points(c(5,5),c(ym,yM),col="black",type="l",lty=3)
points(c(6,6),c(ym,yM),col="black",type="l",lty=3)
points(c(7,7),c(ym,yM),col="black",type="l",lty=3)
points(c(8,8),c(ym,yM),col="black",type="l",lty=3)
points(c(9,9),c(ym,yM),col="black",type="l",lty=3)
points(c(10,10),c(ym,yM),col="black",type="l",lty=3)
points(c(11,11),c(ym,yM),col="black",type="l",lty=3)
points(c(12,12),c(ym,yM),col="black",type="l",lty=3)
points(c(13,13),c(ym,yM),col="black",type="l",lty=3)
points(c(14,14),c(ym,yM),col="black",type="l",lty=3)
points(c(15,15),c(ym,yM),col="black",type="l",lty=3)

points(seq(0,15,1),S[1,],type="p",pch=19,col="blue")
points(seq(0,15,1),S[2,],type="p",pch=10,col="red")
points(seq(0,15,1),S[3,],type="p",pch=13,col="green")
points(seq(0,15,1),S[1,],type="l",lty=2,col="blue",lwd=2)
points(seq(0,15,1),S[2,],type="l",lty=2,col="red",lwd=2)
points(seq(0,15,1),S[3,],type="l",lty=2,col="green",lwd=2)

# CONTINUOUS TIME
dev.new()
par(mfrow=c(1,2))

plot(seq(1,17,1),rep(1,17),xlim=c(1,17),ylim=c(1,6),type="l",lty=3,col="black",xaxt="n",xlab="Time [min]",ylab="Space",main=expression(tilde(X)(omega)))
axis(1, at=seq(1,17,1), labels=seq(1,17,1))

s=seq(1,15,1)
ns=length(s)

for(j in 1:(ns-1)){
sj=c(s[j],s[j+1])
points(sj,rep(Y[1,j],2),type="l",lty=1,col="blue",lwd=2)
points(sj,rep(Y[2,j],2),type="l",lty=2,col="red",lwd=2)
points(sj,rep(Y[3,j],2),type="l",lty=3,col="green",lwd=2)

points(j,Y[1,j],type="p",pch=19,col="blue",lwd=2)
points(j,Y[2,j],type="p",pch=10,col="red",lwd=2)
points(j,Y[3,j],type="p",pch=13,col="green",lwd=2)
}

sj=c(15,17)
points(sj,rep(Y[1,ns],2),type="l",lty=1,col="blue",lwd=2)
points(sj,rep(Y[2,ns],2),type="l",lty=2,col="red",lwd=2)
points(sj,rep(Y[3,ns],2),type="l",lty=3,col="green",lwd=2)
points(15,Y[1,ns],type="p",pch=19,col="blue",lwd=2)
points(15,Y[2,ns],type="p",pch=10,col="red",lwd=2)
points(15,Y[3,ns],type="p",pch=13,col="green",lwd=2)

for(i in 1:16){
points(c(i,i),c(1,6),col="black",type="l",lty=3)
}

plot(seq(0,15,1),rep(0,16),xlim=c(0,17),ylim=c(ym,yM),type="l",lty=3,col="blue",xaxt="n",xlab="Time [min]",ylab="Space", main=expression(tilde(Z)(omega)))
axis(1, at=0:17, labels=c(0:17))

for(i in 0:16){
points(c(i,i),c(ym,yM),type="l",lty=3)
}

#points(seq(0,15,1),S[1,],type="p",pch=19,col="blue")
#points(seq(0,15,1),S[2,],type="p",pch=10,col="red")
#points(seq(0,15,1),S[3,],type="p",pch=13,col="magenta")
points(seq(0,15,1),S[1,],type="l",lty=1,col="blue",lwd=2)
points(seq(0,15,1),S[2,],type="l",lty=2,col="red",lwd=2)
points(seq(0,15,1),S[3,],type="l",lty=3,col="green",lwd=2)

