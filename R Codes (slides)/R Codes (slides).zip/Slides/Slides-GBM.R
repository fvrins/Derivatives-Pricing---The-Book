
#source("GBM.R")

mu=c(0,-0.5,0,0.1)
sigma=c(0.1,0.2,0.3,0.5)
col.v=c("blue","red","cyan","magenta")
S0=35
T=5
dt=0.01
n.path=5
t=seq(0,T,dt)
nt=length(t)

dev.new()
par(mfrow=c(2,2))

dW=sqrt(dt)*matrix(rnorm((nt-1)*n.path),ncol=nt-1,nrow=n.path)
W=matrix(0,ncol=nt,nrow=n.path)
t.mat=matrix(0,ncol=nt,nrow=n.path)
for(i in 1:n.path){
	t.mat[i,]=t
}

par(mfrow=c(2,2))
for(i in 2:nt){
	W[,i]=W[,i-1]+dW[,i-1]
}
for(k in 1:4){
	muk=mu[k]
	sdk=sigma[k]
	S=S0*exp(muk*t.mat+sdk*W)
	yl=c(min(S),max(S))
	plot(t,S[1,],type="l",col=col.v[1],ylim=yl,ylab=expression(S[t]),xlab="t",main=substitute(paste(mu,"=",m," , ", sigma," =",s),list(m=muk,s=sdk)))
	for(i in 2:n.path){
		points(t,S[i,],type="l",col=col.v[i])
	}
	points(t,S0*exp((muk+(sdk^2)/2)*t),type="l",lty=2)
}
