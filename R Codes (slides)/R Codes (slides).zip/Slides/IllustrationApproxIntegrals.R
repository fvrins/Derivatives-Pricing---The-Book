
# =================================================================================================================
# Riemann and Riemann-Stieltjes integrals
# =================================================================================================================

T<-15               # Approximate the integral from 0 to T
n<-10             # Number of time steps (rectangles)
delta<-T/n          # Length of the time step
t<-seq(0,T,delta)   # vector of times (left,right positions of the rectanlges: 0, delta, 2*delta, ... , n*delta=T)


# Estimation of the Riemann integral of h(t) wrt t from 0 to T using the Riemann sum with large n
h<-function(x){x*sin(x)+12}
In=sum(h(t[1:n])*delta) 
print(In)

# Estimation of the Riemann-Stieltjes integral of f(t) wrt g(t) from 0 to T using the Riemann sum with large n
f<-function(x){x*sin(x)+12}
g<-function(x){x^2}
In=sum(f(t[1:n])*diff(g(t))) 
print(In)

# Estimation of the Riemann-Stieltjes integral of g(t) wrt g(t) from 0 to T using the Riemann sum with large n
g<-function(x){x^2}
In=sum(g(t[1:n])*diff(g(t))) 
I=((g(T))^2-(g(0))^2)/2      # Exact solution using integration by parts
print(In)
print(I)

# =================================================================================================================
#Stochastic integrals
# =================================================================================================================

T<-5
n<-100
delta<-T/n
t<-seq(0,T,delta)

# Estimation of the Ito integral of W wrt W from 0 to t for t in [0,delta,2*delta,...,n*delta=T] using the Riemann sum with large n
Wt<-rep(0,n+1)
z<-sqrt(delta)*rnorm(n)
Wt[2:(n+1)]<-cumsum(z)
Ito.Sum<-c(0,cumsum(Wt[1:n]*diff(Wt))) #Ito sum with large n
Ito.Integral<-(Wt^2-t)/2  # Exact solution using the limit of the Ito sum
dev.new()
plot(t,Ito.Integral,type="l",col="blue",lwd=2)
points(t,Ito.Sum,type="l",col="red",lwd=2,lty=3)

# ======================================================================================================
# Explicit vs Integral forms of the solution to a determijnistic differential equation
# ======================================================================================================

# Comparison of f(t)=f0*exp(mu*t) with f(t)=f0+mu*\int_0^t f(s)ds where f(s)=f0*exp(mu*s)

f0<-5
mu<-1.1
f.explicit<-function(t){f0*exp(mu*t)}
ft.explicit<-f.explicit(t)
ft.integral<-f0+mu*cumsum(ft.explicit[1:n])*delta
dev.new()
plot(t,ft.explicit,type="l",col="blue",lwd=2)
points(t[1:n],ft.integral,type="l",col="red",lwd=2,lty=2)

# Comparison of N_t=n_0*exp((mu-sigma^2/2)*t+sigma*W_t) with N_0=n_0 and N_t=n_0+mu\int_0^t N_sds+sigma\int_0^t N_sdW_s (re-using the W trajectory above)
n0<-2
mu<-0.08
sigma<-0.2
N.explicit<-function(t){n0*exp((mu-sigma^2/2)*t+sigma*Wt)}
Nt.explicit<-N.explicit(t)
Nt.integral<-n0+mu*cumsum(Nt.explicit[1:n])*delta+sigma*c(cumsum(Nt.explicit[1:n]*diff(Wt)))
dev.new()
plot(t,Nt.explicit,type="l",col="blue",lwd=2)
points(t[1:n],Nt.integral,type="l",col="red",lwd=2,lty=3)