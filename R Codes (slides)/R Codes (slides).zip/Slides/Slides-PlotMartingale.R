
T<-5
dt<-0.01
n<-T/dt
t<-seq(0,T,dt)
sigma<-0.1
dW=rnorm(n,0,1)*sqrt(dt)
set.seed(1)
W<-c(0,cumsum(dW))
S<-3*exp(-sigma^2/2*t+sigma*W)
s<-2
dev.new()
plot(t,S,type="l",col="blue",xlab="t",ylab=expression(X[~t]),xaxt="n",yaxt="n")
points(c(s,T),rep(S[s/dt],2),type="l",lty=2,col="blue")
points(s,S[s/dt],type="p",pch=16,col="blue")
points(c(0,s),rep(S[s/dt],2),type="l",lty=3)
points(rep(s,2),c(0,S[s/dt]),type="l",lty=3)
axis(1, at = s, labels = "s")
axis(2, at = S[s/dt], labels = expression(X[~s]))

text(4, S[s/dt]*1.01, expression(E(X[t]*" | "*F(s))))