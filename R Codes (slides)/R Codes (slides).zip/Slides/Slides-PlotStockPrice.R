
# Set working directory to source file !
X=read.csv("AAPL.csv")
t=X$Date
P=X$Open

dev.new()
plot(P,type="p",pch=19,col="blue",cex.axis=1,xlab="t",ylab=expression(S[t]))
#plot(P,type="p",pch=19,col="blue",cex.axis=1,xaxt="n",yaxt="n",xlab="",ylab="")
#axis(1,cex.axis=1.2)
#mtext("t", side=1, line=2.2, cex=1.5)
#axis(2,cex.axis=1.2)
#mtext(expression(S[t]), side=2, line=2.2, cex=1.5)
n.P=length(P)
r=log(P[2:n.P]/P[1:(n.P-1)])
#r=(P[2:n.P]/P[1:(n.P-1)])-1

#r=r[1:230]

dev.new()
plot(r,type="p",pch=19,col="blue",cex.axis=1,xlab="t",ylab=expression(R[t]))
#plot(r,type="p",pch=19,col="blue",cex.axis=1.5,xlab="",ylab="",xaxt="n",yaxt="n")
#axis(1,cex.axis=1.2)
#mtext("t", side=1, line=2.2, cex=1.5)
#axis(2,cex.axis=1.2)
#mtext(expression(R[t]), side=2, line=2.2, cex=1.5)

mid=floor(n.P/2)

mu=mean(r)
sigma=sd(r)
x=seq(mu-3*sigma,mu+3*sigma,0.001)
dev.new()
hist(r,prob=T,main="",cex.axis=1,col="blue",xlab=expression(R[t]),ylab="Frequency",breaks=20)


#hist(r,prob=T,main="",cex.axis=1.5,col="blue",xlab="",ylab="",xaxt="n",yaxt="n")
#axis(1,cex.axis=1.2)
#mtext(expression(R[t]), side=1, line=2.2, cex=1.5)
#axis(2,cex.axis=1.2)
#mtext("Frequency", side=2, line=2.2, cex=1.5)
#hist(r,prob=T,main="",xlab="",ylab="",cex.axis=1.5,breaks=20)#,ylim=c(0,1.02*dnorm(0,mu,sigma))
points(x,dnorm(x,mu,sigma),type="l",col="red",lwd=2)

dev.new()
mu.P=mean(P)
sigma.P=sd(P)
x.P=seq(mu.P-5*sigma.P,mu.P+5*sigma.P,0.001)
hist(P,prob=T,main="",cex.axis=1,col="blue",xlab=expression(P[t]),ylab="Frequency",breaks=20)
points(x.P,dnorm(x.P,mu.P,sigma.P),type="l",col="red",lwd=2)

r=(r-mu)/sigma
#x<-qnorm(seq(1,(n.P-1))/(n.P),mu,sigma)
dev.new()
#qqnorm(r, pch = 19, col="blue", frame = FALSE,main="",xlab="",ylab="",cex.axis=1.5)
rs<-sort(r)
plot(qnorm(seq(1,n.P-1)/(n.P),0,1),rs,type="p", pch = 19, col="blue", main="",xlab="",ylab="",cex.axis=1.)
x=seq(-3,3,.01)
points(x,x,type="l",col="red",lty=2,lwd=2)


shapiro.test(r)

mu+sigma*qnorm(1-0.99,0,1)
mu+sigma*qnorm(1-0.995,0,1)

alpha=0.99
P[n.P]*exp(mu+sigma*qnorm(1-alpha))
P[n.P]*(1-exp(mu-sigma*qnorm(alpha)))
acf(r,lag.max=5)
acf(P,lag.max=5)