T=10
dt=0.05
t=seq(0,T,dt)
nT=length(t) # Nb max the step sur la grille la plus fine
n=c(10,2,1) # n=taille du saut sur la grille (en multiple de dt)
f0=1
sigma=0.2
f=function(t){exp(sigma*sin(t))}

plot(t,f(t),type="l",col="blue",lwd=2,ylab=substitute(paste("h(t) and ",h^(n),"(t)")),mgp=c(2,1,0))
for(i in 1:length(n)){
	ni=n[i]
	s=seq(1,nT,ni)
	N=length(s)
	f.hat=rep(f0,N)
	for(j in 2:N){
		f.hat[j]=f.hat[j-1]*(1+sigma*cos((j-1)*ni*dt)*dt)
	}
	points(t[s],f.hat,type="l",col="red",lty=1)#,lwd=2
	points(t[s],f.hat,type="p",pch=19,col="red",cex=0.7)
}
points(t,f(t),type="l",col="blue",lwd=2)