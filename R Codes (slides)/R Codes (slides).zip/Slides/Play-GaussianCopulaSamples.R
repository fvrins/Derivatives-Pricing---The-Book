
# This code allows you to generate M pairs (xi,yi) of samples of (X,Y) where
# X~Exp(lambda), Y~t(nu) and (X,Y) coupled via a Gaussian copula with correlation rho

# PARAMETERS
# -----------------------

M = 1000 # number of samples

lambda = 2	# E[X]
nu = 4	# sqrt Var[X]

rho  = 0.8	# correlation bw (X,Y)

# SAMPLES OF UNDELRYING VARBIALES Z1 and Z2
# ------------------------------------------

# draw M samples from Z1~N(0,1) and Z2~N(0,1) where Z1 indepent of Z2
z1 = rnorm(M)
z2 = rnorm(M)

# SAMPLES OF U AND V uniform on [0,1]
# -----------------------------------

# pnorm(x)=Phi(x) is the CDF of N(0,1)
u = pnorm(z1)
v = pnorm(rho*z1 + sqrt(1-rho^2)*z2)

# SAMPLES OF X,Y VIA PIT
# ------------------------

x=qexp(u,lambda) 	# qexp is the quantile function (inverse of the CDF) associated to Exp(lambda)
y=qt(v,nu)		# qt is the quantile function (inverse of the CDF) associated to T(nu)

# PLOTS
# ---------

par(mfrow=c(1,3)) # make a 1x3 array of plots

# histogram of x and comparison with density of X~Exp(lambda)
hist(x,prob=TRUE,col="grey",breaks=20)
s=seq(min(x),max(x),.1)		
points(s,dexp(s,lambda),type="l",col="red",lwd=2)

# histogram of x and comparison with density of Y~T(nu)
hist(y,prob=TRUE,col="grey",breaks=20)
s=seq(min(y),max(y),.1)
points(s,dt(s,nu),type="l",col="red",lwd=2)

# scatter plot of x vs y
plot(x,y,pch=19,col="blue",title="Scatter plot (X,Y)")