
# Quadratic variation of BM
# When taking dt --> 0  all the lines on the right figure converge to the line y(t)=t, showing that the time-t QV of W is indeed t
# Notice that this is true for ALL paths (ie it is not an average over trajectories, but holds for each of them, independently of the sample path)
# Observe that when scaling W by a factor sigma, the QV of sigma*W is t*sigma^2

dev.new()
T  = 5
dt = 0.01
t = seq(0,T,dt)
n = length(t)
M = 4
sigma = 1

dW = sqrt(dt)*matrix(rnorm(M*(n-1)),nrow=M,ncol=(n-1))
W = matrix(0,nrow=M,ncol=n)
QV = matrix(0,nrow=M,ncol=n)

for(i in 2:n){
	W[,i]=W[,i-1]+sigma*dW[,i-1]
	QV[,i]=QV[,i-1]+(sigma*dW[,i-1])^2
}

col.v=rainbow(M)

par(mfrow=c(1,2))
#par(mfrow=c(2,2))
yl=c(min(W),max(W))
plot(t,W[1,],col=col.v[1],type="l",main="Sample paths of Brownian Motion",ylab=expression(W[t]),xlab="t",ylim=yl)
for(i in 2:M){
	points(t,W[i,],col=col.v[i],type="l")
}

plot(t,QV[1,],col=col.v[1],type="l",main="Quadratic Variation",ylab="Cum Sum of Squares",xlab="t",ylim=c(0,T))
for(i in 2:min(M,5)){
	points(t,QV[i,],col=col.v[i],type="l")
}
points(t,t,type="l",lty=2)