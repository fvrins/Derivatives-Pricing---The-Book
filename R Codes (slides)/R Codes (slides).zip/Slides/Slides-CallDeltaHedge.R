
#Stock
S0 = 30
r  = 0.02
sigma = 0.2
K<-S0
T<-0.5
t<-0.25

d = function(tau,x,pm,vol,K){
  if(pm=="p"){
    y = (r+vol^2/2)
  }else{
    y = (r-vol^2/2)
  }
  return( 1/vol/sqrt(tau)*(log(x/K)+y*tau) )
}
Call = function(tau,x,vol,K){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( x*pnorm(d(tau,x,"p",vol,K))-K*exp(-r*tau)*pnorm(d(tau,x,"m",vol,K)) )
}
Delta<-function(tau,x,vol,K){
  return(pnorm(d(tau,x,"p",vol,K)))
}


# Profit when selling the call:
V0<-Call(T,S0,sigma,K)
Delta0<-Delta(T,S0,sigma,K)
dev.new()
par(mfrow=c(1,2))
x<-seq(20, 40, 1)
Vt<-Call(T-t,x,sigma,K)
plot(x,V0-Vt,type="l",col="blue",lwd=2,xlab="Stock Price @ t=3M",ylab="Net Profit @ t=3M",main="Sell a 6M Call")
arrows(x0 = S0, y0 = 0, x1 = S0, y1 = V0-Call(T-t,S0,sigma,K), code = 3, angle = 30, length = 0.1, col = "red", lwd = 2)
points(x,rep(V0,length(x)),type="l",col="black",lty=2)
grid()
plot(x,(V0-Delta0*S0)-(Vt-Delta0*x),lwd=2,type="l",col="blue",xlab="Stock Price @ t=3M",ylab="Net Profit @ t=3M", main="Sell delta-hedged 6M Call")
arrows(x0 = S0, y0 = 0, x1 = S0, y1 = V0-Call(T-t,S0,sigma,K), code = 3, angle = 30, length = 0.1, col = "red", lwd = 2)
points(c(S0*exp(-sigma*sqrt(t)),S0*exp(sigma*sqrt(t))),rep(0,2),type="p",pch=16,cex=1.2,col="blue")
grid()
