
#source("BM2D.R")

rho=-0.8
T=5
dt=0.01
t=seq(0,T,dt)
nt=length(t)

dev.new()
par(mfrow=c(2,2))

dW=sqrt(dt)*rnorm(nt-1)
dW1=sqrt(dt)*rnorm(nt-1)
dB=rho*dW+sqrt(1-rho^2)*dW1

W=rep(0,nt)
W1=rep(0,nt)
B=rep(0,nt)

par(mfrow=c(2,2))
for(i in 2:nt){
	
	W[i]=W[i-1]+dW[i-1]
	W1[i]=W1[i-1]+dW1[i-1]
	B[i]=B[i-1]+dB[i-1]
	
}

plot(t,W,lwd=2,type="l",col="blue",ylim=c(min(W,W1),max(W,W1)),ylab="",xlab="t",main=expression(paste("sample paths (",rho,"=0)")))
points(t,W1,lwd=2,type="l",col="red")
plot(dW,dW1,type="p",pch=19,col="blue",ylab=expression(paste(delta,B[t])),xlab=expression(paste(delta,W[t])),main=expression(paste("scatter (",rho,"=0)")))

plot(t,W,lwd=2,type="l",col="blue",ylim=c(min(W,B),max(W,B)),ylab="",xlab="t",main=expression(paste("sample paths (",rho,"=80%)")))
points(t,B,lwd=2,type="l",col="red")
plot(dW,dB,type="p",pch=19,col="blue",ylab=expression(paste(delta,B[t])),xlab=expression(paste(delta,W[t])),main=expression(paste("scatter (",rho,"=80%)")))

