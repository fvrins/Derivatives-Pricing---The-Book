# Clean workspace
rm(list = ls())
library(matrixStats)

# ----------------------------------------------------------------------------
# INUPTS
# ----------------------------------------------------------------------------

T  	  = 2			# maturity
r  	  = 1/100		# risk-free rate
#alpha	= 3*r			# alpha (drift of stock)
K 	  = 11			# strike
sigma = 0.2			# volatility
S0 <- 12

# ----------------------------------------------------------------------------
# FUNCTIONS
# ----------------------------------------------------------------------------

d = function(tau,x,sigma,K,pm){
  if(pm=="p"){
    y = (r+sigma^2/2)
  }else{
    y = (r-sigma^2/2)
  }
  return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
}
Call = function(tau,x,sigma,K){
  return( x*pnorm(d(tau,x,sigma,K,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,sigma,K,"m")) )
}
Put = function(tau,x,sigma,K){
  return( K*exp(-r*tau)*pnorm(-d(tau,x,sigma,K,"m"))-x*pnorm(-d(tau,x,sigma,K,"p")) )
}


n<-100
dt<-T/n
T.fix=seq(dt,T,dt)

beta<-(sqrt(n*(n+1)*(2*n+1)/6)*sqrt(dt))*sigma/n
sigma.A=beta/sqrt(T)
drift.A<-((r-sigma^2/2)/n)*sum(T.fix)/T
Adj<-exp((drift.A-(r-sigma.A^2/2))*T)
Price.th<-Adj*Call(T,S0,sigma.A,K/Adj)
print(Price.th)

# Draw M paths of a BM on T.fix
if(TRUE){
  M<-100000
  W<-matrix(0,ncol=n+1,nrow=M)
  for(i in 2:(n+1)){
    W[,i]=W[,i-1]+rnorm(M)*sqrt(dt)
  }
  Tmat<-t(replicate(M,T.fix))
  #sd(sigma*rowSums(W)/n)# shouyld be equal to beta
  S<-S0*exp((r-sigma^2/2)*Tmat+sigma*W[,2:(n+1)])
  Payoff<-(rowProds(S))^(1/n)-K
  Price.MC<-mean(pmax(Payoff,0))*exp(-r*T)
  print(Price.MC)
}




