T<-3
dt<-0.01
t<-seq(0,T,dt)
nt<-length(t)
s0<-1
mu<-0.1
sigma<-0.2
set.seed(8)

W<-cumsum(c(0,rnorm(nt-1)*sqrt(dt)))
Z<-s0*exp(mu*t-sigma*W)
Z<-W
#yL=c(min(W,Z),max(W,Z))

dev.new()
par(mfrow=c(1,2))
n<-4
delta=T/n
ti<-seq(1,n)*delta

plot(t,W,type="l",col="blue",xlab="t",ylab="W,Z",ylim=yL)
points(rep(0,2),c(-10,10),type="l",lty=3,col="gray")
points(t,Z,type="l",col="red")
points(0,Z[1],pch=16,col="red")
points(0,0,pch=1,col="blue")
for(i in 1:n){
  points(rep(ti[i],2),c(-10,10),type="l",lty=3,col="gray")
  if(i<n){
  points(ti[i],Z[1+i*delta/dt],pch=16,col="red")
  }
  points(ti[i],W[1+i*delta/dt],pch=1,col="blue")
  arrows(ti[i],W[1+(i-1)*delta/dt],ti[i],W[1+i*delta/dt],code=3,length=0.08,col="blue",lwd=2)
  arrows((i-1)*delta,W[1+(i-1)*delta/dt],(i)*delta,W[1+(i-1)*delta/dt],code=2,length=0.05,col="gray",lty=3)
}
ItoSum1=Z[1+(0:(n-1))*delta/dt]%*%(W[1+(1:n)*delta/dt]-W[1+(0:(n-1))*delta/dt])

n<-20
delta=T/n
ti<-seq(1,n)*delta
plot(t,W,type="l",col="blue",xlab="t",ylab="W,Z",ylim=yL)
points(rep(0,2),c(-10,10),type="l",lty=3,col="gray")
points(t,Z,type="l",col="red")
points(0,Z[1],pch=16,col="red")
points(0,0,pch=1,col="blue")
for(i in 1:n){
  points(rep(ti[i],2),c(-10,10),type="l",lty=3,col="gray")
  if(i<n){
    points(ti[i],Z[1+i*delta/dt],pch=16,col="red")
  }
  points(ti[i],W[1+i*delta/dt],pch=1,col="blue")
  arrows(ti[i],W[1+(i-1)*delta/dt],ti[i],W[1+i*delta/dt],code=3,length=0.08,col="blue",lwd=2)
  arrows((i-1)*delta,W[1+(i-1)*delta/dt],(i)*delta,W[1+(i-1)*delta/dt],code=2,length=0.05,col="gray",lty=3)
}
ItoSum2=Z[1+(0:(n-1))*delta/dt]%*%(W[1+(1:n)*delta/dt]-W[1+(0:(n-1))*delta/dt])

n<-nt-1
delta=T/n
ti<-seq(1,n)*delta
ItoSum3=Z[1+(0:(n-1))*delta/dt]%*%(W[1+(1:n)*delta/dt]-W[1+(0:(n-1))*delta/dt])

print(ItoSum1)
print(ItoSum2)
print(ItoSum3)
print(((W[nt])^2-T)/2)