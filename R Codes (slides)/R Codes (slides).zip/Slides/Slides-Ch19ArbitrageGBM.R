
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
#  Slide Ch 19 - Arbitrage GBM
#
# This version : 15/10/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# ------------------------------------------------------------------------------
# PARAMETERS
# ------------------------------------------------------------------------------

# time grid
dt<-0.01
Tmat<-2
t<-seq(0,Tmat,dt)
nt<-length(t)

# model parameters
r<-0.05
mu<-0.1
sigma.1<-0.1
sigma.2<-0.2
S0.1<-32
S0.2<-25

# Number of simulations
set.seed(5)
N <- 10000# Number of simulated trajectories, used for the histogram
M <- 5 # Number of trajectories shown (<=N)

# ------------------------------------------------------------------------------
# INITIALIZATION
# ------------------------------------------------------------------------------

# Position at inception
Delta0.1<-1/(sigma.1*S0.1)                # Nb of shares of S1 to buy 
Delta0.2<--1/(sigma.2*S0.2)               # Nb of shares of S2 to short-sell 
c0<--(Delta0.1*S0.1+Delta0.2*S0.2)        # Cash amount after having traded the stocks
Strategy0<-Delta0.1*S0.1+Delta0.2*S0.2+c0 # Net value of the strategy at the beginning (should be 0)

S.1<-S.2<-matrix(0,ncol=nt,nrow=N)
Delta.1<-Delta.2<-matrix(0,ncol=nt,nrow=N)
matrix(0,ncol=nt,nrow=N)
Cash<-matrix(c0,ncol=nt,nrow=N)

alpha.1<-mu-sigma.1^2/2
alpha.2<-mu-sigma.2^2/2

# ------------------------------------------------------------------------------
# SIMULATE N TRAJECTORIES FOR THE STOCKS, COMPUTE THE POSITION AND THE STRATEGY
# ------------------------------------------------------------------------------

for(i in 1:N){
  w<-c(0,cumsum(rnorm(nt-1)*sqrt(dt)))    # Brownian motion (i-th trajectory)
  S.1[i,]<-S0.1*exp(alpha.1*t+sigma.1*w)  # Share price of stock 1
  S.2[i,]<-S0.2*exp(alpha.2*t+sigma.2*w)  # Share price of stock 2
  
  Delta.1[i,1:(nt-1)]<-1/(sigma.1*S.1[i,1:(nt-1)])  # Nb of shares of stock 1
  Delta.2[i,1:(nt-1)]<--1/(sigma.2*S.2[i,1:(nt-1)]) # Nb of shares of stock 2
  
  # Adjust the cash accoun for the interests on the cash previously held and for the trades
  for(j in 2:nt){
    Cash[i,j]<-Cash[i,j-1]*exp(r*dt)-((Delta.1[i,j]-Delta.1[i,j-1])*S.1[i,j]+(Delta.2[i,j]-Delta.2[i,j-1])*S.2[i,j])
  }

}

# Value of the strategy is the total value of cash + assets
Strategy<-Cash+Delta.1*S.1+Delta.2*S.2

# Make the plots
dev.new()
par(mfrow=c(2,2))
# Stock price trajectories
plot(t,S.1[1,],type="l",lwd=2,col="blue",xlab="time",ylab="Stock price",ylim=c(min(S.1[1:M,],S.2[1:M,]),max(S.1[1:M,],S.2[1:M,])))
points(t,S.2[1,],type="l",lwd=2,col="blue",lty=2)
for(i in 2:M){
  points(t,S.1[i,],type="l",lwd=2,col=i)
  points(t,S.2[i,],type="l",lwd=2,col=i,lty=2)
}
# Nb of shares trajectories
plot(t,Delta.1[1,],type="l",lwd=2,col="blue",xlab="time",ylab="Nb of shares held",ylim=c(min(Delta.1[1:M,],Delta.2[1:M,]),max(Delta.1[1:M,],Delta.2[1:M,])))
points(t,Delta.2[1,],type="l",lwd=2,col="blue",lty=2)
points(c(0,Tmat),rep(0,2),lty=3,type="l",col="black")
for(i in 2:M){
  points(t,Delta.1[i,],type="l",lwd=2,col=i)
  points(t,Delta.2[i,],type="l",lwd=2,col=i,lty=2)
}
# Evolution of the total wealth
plot(t,Strategy[1,],type="l",lwd=2,col="blue",xlab="time",ylab="Value of arbitrage strategy")
for(i in 2:M){
  points(t,Strategy[i,],type="l",lwd=2,col=i)
}
# Distribution of the total wealth at T (because Delta[,nt]=0, the stocks positions are closed, hence, at T, Startegy=Cash)
hist(Cash[,nt],col="blue",prob="True",xlab="Value of arbitrage strategy at T",ylab="Density",main="")

