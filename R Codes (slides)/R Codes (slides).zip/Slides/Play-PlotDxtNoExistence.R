
dt<-0.000001
t<-seq(0,1,dt)
nt<-length(t)
X<-rep(0,nt)

for(i in 2:nt){
  X[i]<-X[i-1]+1/(1-X[i-1])*dt
}
plot(t,X)