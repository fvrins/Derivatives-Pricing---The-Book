#source("Normal.R")

x=seq(-5,5,.01)
par(mfrow=c(2,2))

plot(x,dnorm(x),type="l",col="blue",ylim=c(0,1),ylab="",xlab="")
points(x,dnorm(x,-1,1),type="l",col="blue",lty=2)
points(x,dnorm(x,1,1),type="l",col="blue",lty=3)

plot(x,dnorm(x),type="l",col="blue",ylim=c(0,1),ylab="",xlab="")
points(x,dnorm(x,0,1/2),type="l",col="blue",lty=2)
points(x,dnorm(x,0,2),type="l",col="blue",lty=3)

plot(x,pnorm(x),type="l",col="blue",ylim=c(0,1),ylab="",xlab="")
points(x,pnorm(x,-1,1),type="l",col="blue",lty=2)
points(x,pnorm(x,1,1),type="l",col="blue",lty=3)

plot(x,pnorm(x),type="l",col="blue",ylim=c(0,1),ylab="",xlab="")
points(x,pnorm(x,0,1/2),type="l",col="blue",lty=2)
points(x,pnorm(x,0,2),type="l",col="blue",lty=3)