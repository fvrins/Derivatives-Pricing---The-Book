
# source("BlackScholesTforward-Loop.R")

S0=18
sigma=0.3
K=18

T=1
dt=0.01
t=seq(0,T,dt)
nt=length(t)
n.paths=250000/100

rate.mode="stochastic" #"deterministic"
r0=0.04

if(rate.mode=="stochastic"){
	k=0.15
	theta=0.03
	gamma=0.08#0.08#
	IRparam=c(r0,theta,k,gamma)
	B=function(t,T,IRparam){
		k=IRparam[3]
		return(1/k*(1-exp(-k*(T-t))))
	}
	A=function(t,T,IRparam){
		r0=IRparam[1]; theta=IRparam[2]; k=IRparam[3]; gamma=IRparam[4]
		return(exp((theta-(gamma^2)/(2*k^2))*(B(t,T,IRparam)+t-T)-(gamma^2)/(4*k)*B(t,T,IRparam)*B(t,T,IRparam)))
	}
	P=function(T,IRparam){
		return(A(0,T,IRparam)*exp(-B(0,T,IRparam)*IRparam[1]))
	}
	F0=S0/P(T,IRparam)
	r=matrix(r0,ncol=nt,nrow=n.paths)
}else{
	gamma=0
	F0=S0/exp(-r0*T)
}


BS=function(r,S0,K,vol,T){
	d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
	d2=d1-vol*sqrt(T)

	return(S0*pnorm(d1)-K*exp(-r*T)*pnorm(d2))
}

BSK=function(S0,K,sigma,T){
	# le prix sous ind�pendance s'�crit comme une esp�rance de prix BS, ie call avec strike stochastique
	aT=(r0-theta)/k*(1-exp(-k*T))+theta*T 				# mean of \int_0^T r_s ds
	bT=(gamma^2)/(2*k^3)*(2*k*T-3+4*exp(-k*T)-exp(-2*k*T))		# var of \int_0^T r_s ds
	BSz=function(z){BS(0,S0,K*exp(-(aT+sqrt(bT)*z)),sigma,T)*dnorm(z)}

	return(integrate(BSz,-Inf,Inf)$value)
}




rho=seq(-1,1,0.2)
n.rho=length(rho)

Price.MC.max=rep(0,n.rho)
Price.MC.min=rep(0,n.rho)

for(kj in 1:10){

dW=sqrt(dt)*matrix(rnorm((nt-1)*n.paths),ncol=(nt-1),nrow=n.paths)
dW2=sqrt(dt)*matrix(rnorm((nt-1)*n.paths),ncol=(nt-1),nrow=n.paths)

S=matrix(S0,ncol=nt,nrow=n.paths)
D=matrix(1,ncol=nt,nrow=n.paths)

Price.Th=rep(0,n.rho)
Price.BS=rep(0,n.rho)
Price.MC=rep(0,n.rho)

Price.BS.ind=rep(0,n.rho)		# price under indep (proxy)		
Price.BS.ind.th=BSK(S0,K,sigma,T) 	# price under indep (exact)


for(i in 1:n.rho){
	dB=rho[i]*dW+sqrt(1-rho[i]^2)*dW2
	#vol=sqrt(sigma^2+2*rho[i]*sigma*gamma+gamma^2)
	int.fun=function(t){sigma^2+2*rho[i]*sigma*gamma*B(t,T,IRparam)+gamma^2*B(t,T,IRparam)^2}
	vol.fun=1/sqrt(T)*sqrt(integrate(int.fun,0,T)$value)
	for(j in 2:nt){
		if(rate.mode=="stochastic"){
			#r[,j]=r[,j-1]+k*(theta-r[,j-1])*dt+gamma*dB[,j-1]
			r[,j]=r[,j-1]*exp(-k*dt)+theta*(1-exp(-k*dt))+gamma/sqrt(2*k)*sqrt(1-exp(-2*k*dt))/sqrt(dt)*dB[,j-1]
			D[,j]=D[,j-1]*exp(-r[,j-1]*dt)
			#S[,j]=S[,j-1]*(1+r[,j-1]*dt+sigma*dW[,j-1])
			S[,j]=S[,j-1]*exp((r[,j-1]-sigma^2/2)*dt+sigma*dW[,j-1])
		}else{
			D[,j]=D[,j-1]*exp(-r0*dt)
			#S[,j]=S[,j-1]*(1+r0*dt+sigma*dW[,j-1])
			S[,j]=S[,j-1]*exp((r0-sigma^2/2)*dt+sigma*dW[,j-1])
		}
	}
	Payoff=((S[,nt]-K)+abs(S[,nt]-K))/2
	if(rate.mode=="stochastic"){
		P.emp=mean(D[,nt])
		Price.Th[i]=BS(0,F0,K,vol.fun,T)*P(T,IRparam)
		Price.BS[i]=BS(r0,S0,K,sigma,T)
		Price.BS.ind[i]=BS(0,S0*mean(1/D[,nt]),K,sigma,T)*mean(D[,nt]) # Attention: ceci semble bien marcher mais a mon avis n'est pas exact (proxy) !

	}else{
		Price.Th[i]=BS(0,F0,K,vol.fun,T)*exp(-r0*T)
		Price.BS[i]=BS(r0,S0,K,sigma,T)
	}
	Price.MC[i]=mean(Payoff*D[,nt])
}

for(i in 1:n.rho){
	if(kj==1){
		Price.MC.max[i]=Price.MC[i]
		Price.MC.min[i]=Price.MC[i]
	}else{
		Price.MC.max[i]=max(Price.MC.max[i],Price.MC[i])
		Price.MC.min[i]=min(Price.MC.min[i],Price.MC[i])
	}
}
}

par(mfrow=c(2,2))
col.v=c("blue","red","green","cyan")
n.plot=4
yl=c(min(S[1:n.plot,]),max(S[1:n.plot,]))

plot(t,S[1,],type="l",col=col.v[1],ylim=yl,ylab=expression(S[t](omega)),main="Stock sample paths")
for(i in 2:n.plot){
	points(t,S[i,],type="l",col=col.v[i])
}
if(rate.mode=="stochastic"){
	yl=c(min(r[1:n.plot,]),max(r[1:n.plot,]))
	plot(t,r[1,],type="l",ylim=yl,col=col.v[1],ylab=expression(r[t](omega)),main="Short-rate sample paths")
	for(i in 2:n.plot){
		points(t,r[i,],type="l",col=col.v[i])
	}
}else{
	plot(t,rep(r0,nt),type="l",col=col.v[1],ylab=expression(D[t](omega)),main="Short-rate sample paths")
}

yl=c(min(D[1:n.plot,]),max(D[1:n.plot,]))

plot(t,D[1,],type="l",ylim=yl,col="blue",ylab=expression(D[t](omega)),main="Discount factor sample paths")
for(i in 2:n.plot){
	points(t,D[i,],type="l",col=col.v[i])
}
points(t,P(t,IRparam),type="l",col="black",lty=2)

yl=c(min(Price.Th,Price.BS,Price.MC.min),max(Price.Th,Price.BS,Price.MC.max))
#yl=c(min(Price.Th,Price.BS,Price.MC.avg),max(Price.Th,Price.BS,Price.MC.avg))
plot(rho,Price.Th,ylim=yl,type="l",xlab=expression(rho),ylab="Price",col="blue",main="Impact of correlation on option price")
#points(rho,Price.BS,type="l",col="red")
#points(rho,Price.BS.ind,type="l",lty=2,col="red")
points(rho,rep(Price.BS.ind.th,n.rho),type="l",lty=2,col="red")

#points(rho,Price.MC,type="p",col="magenta",lty=2)

points(rho,Price.MC.min,type="l",col="blue",lty=2)
points(rho,Price.MC.max,type="l",col="blue",lty=2)

#points(rho,Price.MC.avg,type="l",col="magenta",lty=2)
points(rep(0,2),yl,type="l",lty=3)

#mean(D[,nt])
#P(T,IRparam)
#mean(S[,nt]*D[,nt])
#S0
#mean(r[,nt])
#r0*exp(-k*T)+theta*(1-exp(-k*T))
#var(r[,nt])
#(gamma^2)/(2*k)*(1-exp(-2*k*T))

#Price.MC.mat=matrix(0,nrow=20,ncol=n.rho)
#kj=0
#kj=kj+1
#Price.MC.mat[kj,]=Price.MC
#Price.MC.avg=colSums(Price.MC.mat[1:kj,])/kj
