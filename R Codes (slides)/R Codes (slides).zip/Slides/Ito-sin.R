
# evolution of X_t:=sin(alpha W_t)

alpha=0.6
T=4
dt=0.0001
t=seq(0,T,dt)
nt=length(t)
n.paths=4
col.v=rep("blue",4)

f=function(x){sin(alpha*x)}

y0=f(0)
dW=sqrt(dt)*matrix(rnorm(n.paths*(nt-1)),ncol=nt-1,nrow=n.paths)

W=matrix(0,ncol=nt,nrow=n.paths)
Y2=matrix(y0,ncol=nt,nrow=n.paths)
Y3=matrix(y0,ncol=nt,nrow=n.paths)
for(i in 2:nt){
	W[,i]=W[,i-1]+dW[,i-1]	
	Y2[,i]=Y2[,i-1]+alpha*cos(asin(Y2[,i-1]))*(W[,i]-W[,i-1])
	Y2[,i]=pmin(rep(0.9999,n.paths),pmax(rep(-0.9999,n.paths),Y2[,i]))
	Y3[,i]=Y3[,i-1]+alpha*cos(asin(Y3[,i-1]))*(W[,i]-W[,i-1])+0.5*(-alpha^2)*Y3[,i-1]*dt
	Y3[,i]=pmin(rep(0.9999,n.paths),pmax(rep(-0.9999,n.paths),Y3[,i]))
}
Y1=f(W)

dev.new()
par(mfrow=c(2,2))
for(i in 1:n.paths){
	plot(t,Y1[i,],ylim=c(min(Y2[i,]),max(Y1[i,])),col="blue",ylab=expression(Y[t]),type="l",main=paste("path #",i))
	points(t,Y2[i,],col="red",type="l",lty=2)
}

dev.new()
par(mfrow=c(2,2))
for(i in 1:n.paths){
	plot(t,Y1[i,],ylim=c(min(Y2[i,]),max(Y1[i,])),col="blue",ylab=expression(Y[t]),type="l",main=paste("path #",i))
	points(t,Y3[i,],col="green",type="l",lty=2)
}

