
s0=12
sigma=0.2
K=15
r=0.01
T=2
M.vec=seq(10,1000,10)
n.M=length(M.vec)
N=1000

BS.call=function(r,S0,K,vol,T){
  d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
  d2=d1-vol*sqrt(T)
  return(S0*pnorm(d1)-K*exp(-r*T)*pnorm(d2))
}
BS.price=BS.call(r,s0,K,sigma,T)

cdf=function(x){
  pnorm( (log(x/s0)-(r-sigma^2/2)*T)/(sigma*sqrt(T)) )
}
p=cdf(K)

cdf.inv=function(u){
  s0*exp((r-sigma^2/2)*T+sigma*sqrt(T)*qnorm(u))
}
cdf.cond.inv=function(u){
  s0*exp((r-sigma^2/2)*T+sigma*sqrt(T)*qnorm(p+(1-p)*u))
}

BS.price.M=matrix(0,ncol=N,nrow=n.M)
BS.price.hat=matrix(0,ncol=N,nrow=n.M)

BS.price.M.mean=rep(0,n.M)
BS.price.hat.mean=rep(0,n.M)
BS.price.M.sd=rep(0,n.M)
BS.price.hat.sd=rep(0,n.M)

for(i in 1:n.M){
  M=M.vec[i]
  for(j in 1:N){
  u=runif(M)

  x.MC=cdf.inv(u)
  x.hat=cdf.cond.inv(u)
  
  BS.price.M[i,j]=exp(-r*T)*mean(pmax(x.MC-K,0))
  BS.price.hat[i,j]=exp(-r*T)*(1-p)*(mean(x.hat)-K)
  }
  BS.price.M.mean[i]=mean(BS.price.M[i,])
  BS.price.hat.mean[i]=mean(BS.price.hat[i,])
  
  BS.price.M.sd[i]=sd(BS.price.M[i,])
  BS.price.hat.sd[i]=sd(BS.price.hat[i,])
}

ym=min(BS.price.M.mean-BS.price.M.sd)
yM=max(BS.price.M.mean+BS.price.M.sd)
dev.new()
plot(M.vec,rep(BS.price,n.M),type="l",col="black",lty=2,ylab="",xlab="n", cex.axis=1, cex.lab=1.5,mgp=c(2,1,0))
points(M.vec,BS.price.M.mean,type="l",col="blue",lwd=2)
points(M.vec,BS.price.hat.mean,type="l",col="red",lwd=2)
points(M.vec,BS.price.M.mean+BS.price.M.sd,type="l",col="blue",lty=2,lwd=2)
points(M.vec,BS.price.M.mean-BS.price.M.sd,type="l",col="blue",lty=2,lwd=2)
points(M.vec,BS.price.hat.mean+BS.price.hat.sd,type="l",col="red",lty=2,lwd=2)
points(M.vec,BS.price.hat.mean-BS.price.hat.sd,type="l",col="red",lty=2,lwd=2)

