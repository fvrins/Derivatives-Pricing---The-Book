T=5
n=250
m=50
delta=T/n
t=seq(0,T,delta)
W=matrix(0,ncol=n+1,nrow=m)
col.v0=c("blue","orange","magenta","cyan","purple","red")
col.v=col.v0
while(length(col.v)<n){col.v=c(col.v,col.v0)}
for(i in 1:m){
  Z=sqrt(delta)*rnorm(n)
  W[i,]=c(0,cumsum(Z))
}
plot(t,W[1,],type="l",col=col.v[1],ylim=c(-5,5))
for(i in 2:m){
  points(t,W[i,],type="l",col=col.v[i])
}
#W2=W[,51]
#hist(W2)