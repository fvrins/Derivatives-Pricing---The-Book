# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 13.1 -  Approximation Riemann integral
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

cex.val<-1#1.3
dx=0.01
a=0
b=15
x=seq(a,b,dx)
col.fun<-"blue"
col.rect<-"red"
wd.lwd<-1

f=function(x){
	#sin(x)/x*exp(-abs(x/10))
	12+x*sin(x)
}

dev.new()
#par(mfrow=(c(2,2)))
Int=rep(0,4)
dx.vec<-c(1,1/2,1/3,1/8)
for(i in 1:4){
  dev.new()
	#dx.grid=1/(i)
  dx.grid<-dx.vec[i]
	nj=(b-a)/dx.grid
	xj=a

	#plot(x,f(x),type="l",ylim=c(0,max(f(x))),col="blue",main=paste("n = ",nj))
	#dev.new()
	#plot(x,f(x),type="l",ylim=c(0,max(f(x))),col=col.rect,xaxt="n",yaxt="n",main="",xlab="",ylab="")
	plot(x,f(x),type="l",ylim=c(0,max(f(x))),col=col.rect,xaxt="n",yaxt="n",main=paste("n = ",nj),xlab="",ylab="")
	axis(1,cex.axis=cex.val)
	mtext("t", side=1, line=2.2, cex=cex.val)
	axis(2,cex.axis=cex.val)
	mtext("h(t)", side=2, line=2.5, cex=cex.val)
	for(j in 1:nj){
		#points(rep(xj,2),c(a,f(xj)),type="l",lty=2)
		#if(j>1){points(rep(xj+dx.grid,2),c(a,f(xj)),type="l",lty=2)}
		#points(c(xj,xj+dx.grid),rep(f(xj),2),type="l",lty=2)
		#rect(xj,0, xj+dx.grid, f(xj), density = NULL, col = col.rect, border = NULL)
	  rect(xj,0, xj+dx.grid, f(xj), density = NULL, col = NULL, border = col.rect)
	  Int[i]=Int[i]+f(xj)*dx.grid		
		xj=xj+dx.grid
	}
	points(x,f(x),type="l",col=col.fun,lwd=wd.lwd)
}

12*15-15*cos(15)+sin(15)
integrate(f,0,15)

g=function(x){
	x^2
}
dg=function(x){
	2*x
}
h=function(x){
	f(x)*dg(x)
}
integrate(h,0,15)

Int1=rep(0,4)
Int2=rep(0,4)
for(i in 1:4){
	dx.grid=1/(50*i)
	nj=(b-a)/dx.grid
	xj=a

	#plot(x,f(x),type="l",ylim=c(0,max(f(x))),col="blue",main=paste("n = ",nj))
	for(j in 1:nj){
		#rect(xj,0, xj+dx.grid, f(xj), density = NULL, col = "blue", border = NULL)
		Int1[i]=Int1[i]+h(xj)*dx.grid		
		Int2[i]=Int2[i]+f(xj)*(g(xj+dx.grid)-g(xj))
		xj=xj+dx.grid
	}
	points(x,f(x),type="l",col=col.fun,lwd=wd.lwd)
}
12*15*15-2*15*15*cos(15)+60*sin(15)+4*(cos(15)-1)
2696-446*cos(15)+60*sin(15)
integrate(h,0,15)
Int1
Int2