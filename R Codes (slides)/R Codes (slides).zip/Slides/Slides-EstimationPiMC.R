rm(list = ls())

# source("D:/Users/fvrins/Documents/Cours/MQANT1113/Resources/EstimationPiMC.R") 

n = 10E3 		# max 1E9
U = 2*runif(n)-1	# echantillonage de U
V = 2*runif(n)-1	# echantillonage de V
r=sqrt(U^2+V^2)	# distance d(ui,vi) entre (0,0) et (ui,vi)


# comptage du nombre de points dans le cercle, c?d d(ui,vi)<1
# -----------------------------------------------------------

cpt=length(which(r<=1))

# r?sultats
# -----------------------------------------------------------

print(paste("Valeur de pi theorique : ",pi))
print(paste("Valeur de pi estimee (sur base de ",n, " echantillons) : ", cpt*4/n))

# graphe
# -----------------------------------------------------------

if(n>1E4){r=r[1:1E4]; U=U[1:1E4]; V=V[1:1E4]}

idx=which(r<=1)
uin=U[idx]
vin=V[idx]
#plot(U,V,type="p",col="red",ylim=c(-1,1),xlim=c(-1,1),pch=19,asp=1,main=expression(paste("Estimation de ", pi)))
dev.new
plot(U,V,type="p",col="red",ylim=c(-1,1),xlim=c(-1,1),xlab="X",ylab="Y",pch=19,asp=1)
points(uin,vin,type="p",col="green",pch=19)
points(0,0,type="p",col="black",pch=19)
points(c(0,0),c(-1,1),type="l",col="black",lty=2)
points(c(-1,1),c(0,0),type="l",col="black",lty=2)
points(c(-1,1),c(-1,-1),type="l",col="black",lty=2)
points(c(-1,1),c(1,1),type="l",col="black",lty=2)
points(c(-1,-1),c(-1,1),type="l",col="black",lty=2)
points(c(1,1),c(-1,1),type="l",col="black",lty=2)
library("plotrix")
draw.circle(0,0,1,nv=1000,border=NULL,col=NA,lty=1,lwd=1)
