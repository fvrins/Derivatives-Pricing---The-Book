#source("DiscreterandomWalk.R")

DotSize=2
AxisSize=2
M=matrix(0,3,16)
t=0:15

M[1,]=c(0,1,2,3,2,3,4,5,4,3,2,3,2,3,4,3)
M[2,]=c(0,1,0,1,0,-1,-2,-1,-2,-3,-2,-1,0,-1,-2,-3)
M[3,]=c(0,-1,-2,-1,-2,-3,-2,-1,0,-1,0,1,0,1,0,1)

ym=min(M)
yM=max(M)

plot(t,M[1,],type="p",pch=19,col="blue",ylim=c(ym,yM),xlab="i",ylab=expression(M[i]),cex=DotSize,cex.lab=AxisSize,cex.axis=AxisSize,mgp=c(2,1,0))
points(t,M[1,],type="l",col="blue",lty=2,lwd=2)
points(t,M[2,],type="p",pch=19,col="red",cex=DotSize)
points(t,M[2,],type="l",col="red",lty=2,lwd=2)
points(t,M[3,],type="p",pch=19,col="green",cex=DotSize)
points(t,M[3,],type="l",col="green",lty=2,lwd=2)

for(i in 1:16){
	points(rep(i-1,2),c(ym,yM),lty=3,type="l")
}
for(i in ym:yM){
	points(c(0,15),rep(i,2),lty=3,type="l")
}

dev.new()
plot(0,0,type="p",pch=19,xlim=c(0,15),ylim=c(-15,15),xlab="i",ylab=expression(M[i]),col="grey")
for(i in 1:16){
	points(rep(i-1,2),c(-15,15),lty=3,type="l",col="grey")
}
for(i in -15:15){
	points(c(0,15),rep(i,2),lty=3,type="l",col="grey")
}
for(i in 1:15){
	for(j in seq(-i,i,2)){
		points(i,j,pch=19,col="grey")
	}
}
for(i in 1:16){
	points(c(i-1,15),c(-(i-1),17-2*i),type="l",lty=2,col="grey",lwd=1.2)
	points(c(i-1,15),c((i-1),2*i-17),type="l",lty=2,col="grey",lwd=1.2)
}

points(t,M[1,],type="p",pch=19,col="blue")
points(t,M[1,],type="l",col="blue",lty=2,lwd=2)
points(t,M[2,],type="p",pch=19,col="red")
points(t,M[2,],type="l",col="red",lty=2,lwd=2)
points(t,M[3,],type="p",pch=19,col="green")
points(t,M[3,],type="l",col="green",lty=2,lwd=2)

dev.new()
par(mfrow=c(2,2))
i=15
sj=seq(-15,15,2)
pj=c(0.05,0.25,0.5,0.75)
si=seq(-i,i,.01)
for(ip in 1:4){
	probj=dbinom(round((i+sj)/2),i,pj[ip])
	mu=probj%*%sj
	sd=sqrt((sj*sj)%*%probj-mu^2)
	probi=2*dnorm(si,mu,sd)
	yl=c(min(probi,probj),max(probi,probj))
	plot(sj,probj,type="p",pch=19,col="blue",xlab="j",ylab="p(15,j)",main=paste("p = ",pj[ip]),ylim=yl,cex.lab=1.2,cex.axis=1.2)
	points(si,probi,type="l",col="red")

	for(k in 1:(2*i+1)){
		points(rep(-i+k-1,2),yl,type="l",col="grey",lty=3)
	}
}

# ---------------------------
# shifted/scaled random walk
# ---------------------------

mu=1
sigma=1

#dev.new()
plot(0,0,type="p",pch=19,xlim=c(0,15),ylim=c(min(0,mu*15-sigma*15),mu*15+sigma*15),xlab="i",ylab=expression(X[i]),col="grey")
for(i in 1:16){
	points(rep(i-1,2),c(min(0,mu*15-sigma*15),mu*15+sigma*15),lty=3,type="l",col="grey")
}
for(i in 1:15){
	for(j in seq(-i,i,2)){
		points(c(0,15),mu*i+sigma*rep(j,2),lty=3,type="l",col="grey")
	}
}
for(i in 1:15){
	for(j in seq(-i,i,2)){
		points(i,mu*i+sigma*j,pch=19,col="grey")
	}
}

# ---------------------------
# log random walk
# ---------------------------

sigma=0.1
tv=M*0
tv[1,]=0:15
tv[2,]=0:15
tv[3,]=0:15

alpha=2*exp(sigma)/(exp(2*sigma)+1)
Y=42*alpha^tv*exp(sigma*M)

dev.new()
plot(0,42,type="p",pch=19,col="grey",ylim=c(0,200),xlim=c(0,15),xlab="i",ylab=expression( S[i]))
points(c(0,15),rep(0,2),lty=3,type="l")
for(i in 1:15){
	for(j in seq(-i,i,2)){
		points(i,42*alpha^i*exp(sigma*j),pch=19,col="grey")
		if(j>-(i-1)){
			points(c(i-1,i),c(42*alpha^{i-1}*exp(sigma*(j-1)),42*alpha^{i}*exp(sigma*j)),type="l",lty=2,col="grey")
		}
		if(j<(i-1)){
			points(c(i-1,i),c(42*alpha^{i-1}*exp(sigma*(j+1)),42*alpha^{i}*exp(sigma*j)),type="l",lty=2,col="grey")
		}
	}
}

points(t,(Y[1,]),type="p",pch=19,col="blue")
points(t,(Y[1,]),type="l",col="blue",lty=2,lwd=2)
points(t,(Y[2,]),type="p",pch=19,col="red")
points(t,(Y[2,]),type="l",col="red",lty=2,lwd=2)
points(t,(Y[3,]),type="p",pch=19,col="green")
points(t,(Y[3,]),type="l",col="green",lty=2,lwd=2)

dev.new()
par(mfrow=c(2,2))
i=15
sj=seq(-15,15,2)
yj=42*alpha^i*exp(sigma*sj)
pj=c(0.05,0.25,0.5,0.75)
si=seq(0.01,200,.01)
for(ip in 1:4){
	probj=dbinom(round((i+sj)/2),i,pj[ip])
	mu=probj%*%sj
	sd=sqrt((sj*sj)%*%probj-mu^2)
	probi=2*dnorm(log(si/(42*alpha^i))/sigma,mu,sd)
	yl=c(min(probi,probj),max(probi,probj))
	plot(yj,probj,type="p",pch=19,col="blue",xlab=expression(S[15]),ylab="p(15,j)",main=paste("p = ",pj[ip]),xlim=c(0,200),ylim=yl,cex.lab=1.2,cex.axis=1.2)
	points(si,probi,type="l",col="red")

	for(k in 1:(2*i+1)){
		points(rep(yj[k],2),yl,type="l",col="grey",lty=3)
	}
}
