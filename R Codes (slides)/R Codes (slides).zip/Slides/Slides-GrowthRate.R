
#source("GrowthRate.R")

f0=7.2
r.vec=c(0.001,0.01,0.05,0.1)
nr=length(r.vec)
r=0.011
sig=c(0.001,0.005,0.01,0.1)
n.sig=length(sig)
n.paths=100
T=50
dt=0.01
t.vec=seq(0,T,dt)
nt=length(t.vec)

col.v=c("red","cyan","magenta","orange","green")

t=seq(0,T,.1)
par(mfrow=c(2,2))
for(k in 1:nr){
	f=function(t){7.2*exp(r.vec[k]*t)}
	plot(t,f(t),lwd=2,type="l",col="blue",ylab="population size [bln]",xlab="time [yrs]",main=paste(r.vec[k]*100,"%"))
	points(rep(20,2),c(f0,f(20)),type="l",lty=3)
	points(c(0,20),rep(f(20),2),type="l",lty=3)
	points(c(0,50),rep(f0,2),type="l",lty=3)
}

dev.new()
par(mfrow=c(2,2))
f=function(t){7.2*exp(r*t)}
M=array(0,dim=c(n.sig,n.paths,nt))

for(i in 1:n.sig){
	dW=matrix(sqrt(dt)*rnorm(n.paths*(nt-1)),ncol=nt-1,nrow=n.paths)
	N=matrix(f0,ncol=nt,nrow=n.paths)
	for(j in 2:nt){
		N[,j]=N[,j-1]*exp((r-0.5*(sig[i])^2)*dt+sig[i]*dW[,j-1])
	}
	ym=min(N[1:min(n.paths,5),])
	yM=max(N[1:min(n.paths,5),])
	#plot(t,f(t),lwd=2,type="l",col="blue",ylim=c(ym,yM),ylab="population size [bln]",xlab="time [yrs]",main=expression(paste("Population growth (", sigma, "=",sig[i],")")))
	s=sig[i]
	txt.main=paste(s*100,"%")

	plot(t,f(t),lwd=2,type="l",col="blue",ylim=c(ym,yM),ylab="population size [bln]",xlab="time [yrs]",main=txt.main)
	for(k in 1:min(n.paths,5)){
		points(t.vec,N[k,],type="l",col=col.v[k])
	}
	points(c(0,50),rep(f0,2),type="l",lty=3)
	M[i,,]=N
}

dev.new()
par(mfrow=c(2,2))
	#t.samp=t.vec[2001]
for(i in 1:n.sig){
	y=hist(M[i,,2001],plot=FALSE)
	yM=max(y$density)*1.1
	#xm=max(0,f0-i*sqrt(20))
	xm=floor(min(M[i,,2001]))
	xM=ceiling(max(M[i,,2001]))
	#xM=f0+i*sqrt(20)
	hist(M[i,,2001],breaks=20,freq=FALSE,col="grey",ylim=c(0,yM),ylab="density",xlab="population size in 20Y [bln]",main=paste(sig[i]*100,"%"))
	x=seq(xm,xM,.01)
	points(rep(f(20),2),c(0,yM),col="blue",type="l",lwd=2,lty=2)
	points(x,(1/x)/(sig[i]*sqrt(20))*dnorm((log(x/f0)-20*(r-0.5*(sig[i])^2))/(sig[i]*sqrt(20))),col="red",type="l",lwd=2)
}
