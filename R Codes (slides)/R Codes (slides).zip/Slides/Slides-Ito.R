
sigma=0.2
T=5
dt=0.001
t=seq(0,T,dt)
nt=length(t)
n.paths=4
col.v=rep("blue",4)

f=function(x){exp(sigma*x)}

y0=f(0)
dW=sqrt(dt)*matrix(rnorm(n.paths*(nt-1)),ncol=nt-1,nrow=n.paths)

W=matrix(0,ncol=nt,nrow=n.paths)
Y2=matrix(y0,ncol=nt,nrow=n.paths)
Y3=matrix(y0,ncol=nt,nrow=n.paths)
for(i in 2:nt){
	W[,i]=W[,i-1]+dW[,i-1]	
	Y2[,i]=Y2[,i-1]+sigma*Y2[,i-1]*(W[,i]-W[,i-1])
	Y3[,i]=Y3[,i-1]+sigma*Y2[,i-1]*(W[,i]-W[,i-1])+0.5*(sigma^2)*Y3[,i-1]*dt
}
Y1=exp(sigma*W)

dev.new()
par(mfrow=c(2,2))
for(i in 1:n.paths){
	plot(t,Y1[i,],ylim=c(min(Y2[i,]),max(Y1[i,])),col="blue",ylab=substitute(paste("X(t) and ",Y^(n),"(t)")),type="l",main=paste("path #",i))
	points(t,Y2[i,],col="red",type="l",lty=2)
}

dev.new()
par(mfrow=c(2,2))
for(i in 1:n.paths){
	plot(t,Y1[i,],ylim=c(min(Y2[i,]),max(Y1[i,])),col="blue",ylab=substitute(paste("X(t) and ",X^(n),"(t)")),type="l",main=paste("path #",i))
	points(t,Y3[i,],col="green",type="l",lty=2)
}

