#source("ScaledRandomWalk.R")
T=5
n=c(5,25,100,500)
delta=T/n
n.MC=3

Z1=matrix(rnorm(n.MC*n[1]),nrow=n.MC,ncol=n[1])
X1=matrix(0,nrow=n.MC,ncol=n[1]+1)
Z2=matrix(rnorm(n.MC*n[2]),nrow=n.MC,ncol=n[2])
X2=matrix(0,nrow=n.MC,ncol=n[2]+1)
Z3=matrix(rnorm(n.MC*n[3]),nrow=n.MC,ncol=n[3])
X3=matrix(0,nrow=n.MC,ncol=n[3]+1)
Z4=matrix(rnorm(n.MC*n[4]),nrow=n.MC,ncol=n[4])
X4=matrix(0,nrow=n.MC,ncol=n[4]+1)

for(i in  1:n[1]){
	X1[,i+1]=X1[,i]+sqrt(delta[1])*Z1[,i]
}
for(i in  1:n[2]){
	X2[,i+1]=X2[,i]+sqrt(delta[2])*Z2[,i]
}
for(i in  1:n[3]){
	X3[,i+1]=X3[,i]+sqrt(delta[3])*Z3[,i]
}
for(i in  1:n[4]){
	X4[,i+1]=X4[,i]+sqrt(delta[4])*Z4[,i]
}

par(mfrow=c(2,2))

plot(seq(0,T,delta[1]),X1[1,],ylim=c(min(X1),max(X1)),type="p",pch=19,col="blue",main=paste("n=" , n[1]),xlab="time",ylab="space")
points(seq(0,T,delta[1]),X1[1,],type="l",col="blue",lty=2)
points(seq(0,T,delta[1]),X1[2,],type="p",pch=19,col="magenta")
points(seq(0,T,delta[1]),X1[2,],type="l",col="magenta",lty=2)
points(seq(0,T,delta[1]),X1[3,],type="p",pch=19,col="cyan")
points(seq(0,T,delta[1]),X1[3,],type="l",col="cyan",lty=2)

plot(seq(0,T,delta[2]),X2[1,],ylim=c(min(X2),max(X2)),type="p",pch=19,col="blue",main=paste("n=" , n[2]),xlab="time",ylab="space")
points(seq(0,T,delta[2]),X2[1,],type="l",col="blue",lty=2)
points(seq(0,T,delta[2]),X2[2,],type="p",pch=19,col="magenta")
points(seq(0,T,delta[2]),X2[2,],type="l",col="magenta",lty=2)
points(seq(0,T,delta[2]),X2[3,],type="p",pch=19,col="cyan")
points(seq(0,T,delta[2]),X2[3,],type="l",col="cyan",lty=2)

plot(seq(0,T,delta[3]),X3[1,],ylim=c(min(X3),max(X3)),type="p",pch=19,col="blue",main=paste("n=" , n[3]),xlab="time",ylab="space")
points(seq(0,T,delta[3]),X3[1,],type="l",col="blue",lty=2)
points(seq(0,T,delta[3]),X3[2,],type="p",pch=19,col="magenta")
points(seq(0,T,delta[3]),X3[2,],type="l",col="magenta",lty=2)
points(seq(0,T,delta[3]),X3[3,],type="p",pch=19,col="cyan")
points(seq(0,T,delta[3]),X3[3,],type="l",col="cyan",lty=2)

plot(seq(0,T,delta[4]),X4[1,],ylim=c(min(X4),max(X4)),type="l",col="blue",main=paste("n=" , n[4]),xlab="time",ylab="space")
#points(seq(0,T,delta[4]),X4[1,],type="l",col="blue",lty=2)
#points(seq(0,T,delta[4]),X4[2,],type="p",pch=19,col="magenta")
points(seq(0,T,delta[4]),X4[2,],type="l",col="magenta")
#points(seq(0,T,delta[4]),X4[3,],type="p",pch=19,col="cyan")
points(seq(0,T,delta[4]),X4[3,],type="l",col="cyan")

