
S0=70
sigma=0.18
K=81
mu=0
r=0.05
T=4

BS.call=function(r,S0,K,vol,T){
	d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
	d2=d1-vol*sqrt(T)
	return(S0*pnorm(d1)-K*exp(-r*T)*pnorm(d2))
}

BS.put=function(r,S0,K,vol,T){
  d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
  d2=d1-vol*sqrt(T)
  return(K*exp(-r*T)*pnorm(-d2)-S0*pnorm(-d1))
}

RN.prob=function(r,mu,vol,dt){
  u=exp(mu*dt+vol*sqrt(dt))
  d=exp(mu*dt-vol*sqrt(dt))
  p=(exp(r*dt)-d)/(u-d)
  return(p)
}

CRR.call=function(r,mu,S0,K,vol,T,n){
  dt=T/n
  u=exp(mu*dt+vol*sqrt(dt))
  d=exp(mu*dt-vol*sqrt(dt))
  p=(exp(r*dt)-d)/(u-d)  
  #p=RN.prob(r,mu,vol,dt)
  j=seq(0,n)
  alpha=u
  beta=exp(-2*vol*sqrt(dt))
  S=S0*alpha^n*beta^j
  Payoff=pmax(S-K,0)
  return(Payoff%*%dbinom(j,n,1-p)*exp(-r*T))
}

CRR.put=function(r,mu,S0,K,vol,T,n){
  dt=T/n
  u=exp(mu*dt+vol*sqrt(dt))
  #d=exp(mu*dt-vol*sqrt(dt))
  #p=(exp(r*dt)-d)/(u-d)
  p=RN.prob(r,mu,vol,dt)
  j=seq(0,n)
  alpha=u
  beta=exp(-2*vol*sqrt(dt))
  S=S0*alpha^n*beta^j
  Payoff=pmax(K-S,0)
  return(Payoff%*%dbinom(j,n,1-p)*exp(-r*T))
}


BS.Price.call=BS.call(r,S0,K,sigma,T)
BS.Price.put=BS.put(r,S0,K,sigma,T)
n=seq(1,200)
N=length(n)
CRR.Price.call=rep(0,N)
CRR.Price.put=rep(0,N)
for(k in 1:N){
  CRR.Price.call[k]=CRR.call(r,mu,S0,K,sigma,T,n[k])
  CRR.Price.put[k]=CRR.put(r,mu,S0,K,sigma,T,n[k])  
}
plot(n,CRR.Price.call,type="l",lty=1,col="red", lwd=1, ylim=c(min(CRR.Price.call,BS.Price.call),max(CRR.Price.call,BS.Price.call)), ylab="Call price", cex.axis=1, cex.lab=1.5)
points(n,rep(BS.Price.call,N),type="l",lty=2,col="blue", lwd=2)

plot(n,CRR.Price.put,type="l",lty=1,col="red", lwd=1, ylim=c(min(CRR.Price.put,BS.Price.put),max(CRR.Price.put,BS.Price.put)), ylab="Put price", cex.axis=1, cex.lab=1.5)
points(n,rep(BS.Price.put,N),type="l",lty=2,col="blue", lwd=2)

# producing the table to analyse mu
CRR.call.p=function(r,mu,S0,K,vol,T,n,p){
  dt=T/n
  if(p==0){
    p=RN.prob(r,mu,vol,dt)
  }
  j=seq(0,n)
  alpha=exp(mu*dt+vol*sqrt(dt))
  beta=exp(-2*vol*sqrt(dt))
  S=S0*alpha^n*beta^j
  Payoff=pmax(S-K,0)
  return(Payoff%*%dbinom(j,n,1-p)*exp(-r*T))
}

mu=seq(-0.1,0.1,0.01)
n.mu=length(mu)
n=c(1,2,10)
n.n=length(n)
res=matrix(0,nrow=n.mu,ncol=n.n)
p=rep(0,n.mu)
for(j in 1:n.n){
  for(i in 1:n.mu){
    res[i,j]=CRR.call.p(r,mu[i],S0,K,sigma,T,n[j],0)
    if(j==n.n){
      dt=T/n[j]
      u=exp(mu[i]*dt+sigma*sqrt(dt))
      d=exp(mu[i]*dt-sigma*sqrt(dt))
      p[i]=(exp(r*dt)-d)/(u-d)
    }
  }
}

