
mu=-0.1
sigma=0.35
S0=5
T=5
dt=0.001
t=seq(0,T,dt)
nt=length(t)
n.paths=4
col.v=rep("blue",4)

dW=sqrt(dt)*rnorm(nt-1)

W=rep(0,nt)
for(i in 2:nt){
	W[i]=W[i-1]+dW[i-1]	
}
X=S0*exp((mu-sigma^2/2)*t+sigma*W)

dev.new()
par(mfrow=c(2,2))
sj=c(1000,100,10,1)
nj=length(sj)
for(j in 1:nj){
	dtj=sj[j]*dt
	idx=seq(1,nt,sj[j])
	tj=t[idx]
	#ntj=length(tj)
	ntj=length(idx)
	X.hat=rep(S0,ntj)
	print(ntj)
	for(i in 2:ntj){
	  X.hat[i]=X.hat[i-1]*(1+mu*dtj+sigma*(W[idx[i]]-W[idx[i-1]]))
	}
	plot(t,X,ylim=c(min(X.hat,X),max(X.hat,X)),col="blue",ylab=expression(Y[t]),type="l",main=paste("time step ",dtj))
	points(tj,X.hat,col="red",type="p",pch=19)
	points(tj,X.hat,col="red",type="l",pch=19)
	points(t,X,col="blue",ylab=expression(Y[t]),type="l")
}


