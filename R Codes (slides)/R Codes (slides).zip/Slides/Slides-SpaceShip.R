t<-seq(0,1,0.01)*3600
k<-8000
lambda<-1/1000
h0<-650
v=function(t){k*(1-exp(-lambda*t))}
h<-function(t){h0+k*(t+(exp(-lambda*t)-1)/lambda)}

dev.new()
par(mfrow=c(1,2))
plot(t/3600,v(t)*3.6,type='l',col="blue",lwd=1.5,xlab="Time [h]", ylab="Speed [km/h]")
plot(t/3600,h(t)/1000,type='l',col="blue",lwd=1.5,xlab="Time [h]", ylab="Altitude [km]")