#source("ItoIntegral.R")

dt=0.000001
a=0
b=10
t=seq(a,b,dt)
nt=length(t)

W=rep(0,nt)
I=rep(0,nt)
dW=sqrt(dt)*rnorm(nt-1)
for(i in 1:(nt-1)){
	W[i+1]=W[i]+dW[i]
	I[i+1]=I[i]+W[i]*dW[i]
}

y=((W[nt])^2-b)/2
N=10
cj=c(1000,500,250,100,50,25,10,5,2,1)
dj=dt*cj
res=rep(0,N)
s=seq(1,nt,100)
par(mfrow=(c(1,2)))
	plot(t[s],W[s],type="l",ylim=c(min(W),max(W)),xlab="t",ylab=expression(W[t]),col="blue",main=expression(paste("Sample path of ",W[t])))
	text(4,0,expression(paste(W[T],"=2.647")))

for(j in 1:N){
	Wj=W[seq(1,nt,cj[j])]
	nj=length(Wj)
	Ij=rep(0,nj)
#	plot(0,0,type="p",ylim=c(min(W),max(W)),xlim=c(0,),col="blue",main="dW")

	for(i in 1:(nj-1)){
		dWj=(Wj[i+1]-Wj[i])
#		rect(Wj[i],0, Wj[i], Wj[i], density = NULL, col = "blue", border = NULL)
		Ij[i+1]=Ij[i]+Wj[i]*dWj
	}
	res[j]=Ij[nj]
}

plot(1/dj,res,type="p",pch=19,xlab=expression(delta^{-1}),ylab=expression("Ito sum"),col="blue",main=expression("Convergence of Ito sum"))
points(1/dj,res,type="l",lty=2,col="blue")
points(1/c(dj[1],dj[N]),rep(y,2),type="l",lty=2)
text(5000,-1.2,expression(paste(I[t],"=",-1.497)))