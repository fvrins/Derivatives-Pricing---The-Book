# ============== FIGURE 13.2 ================================

#clean data space
rm(list=ls(all=TRUE))
set.seed(3)

T=10
dt=0.01
t=seq(0,T,dt)
nT=length(t)
n=c(50,5)#(1000,200,50,5)
cex.val=1.3
dW=c(0,rnorm(nT-1)*sqrt(dt))
W=cumsum(dW)
W2=W^2/2
mW=min(W)
MW=max(W)
ylW=1.1*c(mW,MW)
ylW2=c(-5,6)#1*c(0,max(mW^2,MW^2))#1*c(-T/2,max(mW^2,MW^2))
add.drift=0


# Plot W
if(add.drift==0){
  dev.new()
  plot(t,W,ylim=ylW,type="l",col="blue",lwd=1,xlab="",ylab="",xaxt="n",yaxt="n")#,mgp=c(2,1,0)
  #ylW2[1]=ylW[1]
  axis(1,cex.axis=cex.val)
  mtext("t", side=1, line=2.2, cex=cex.val)
  axis(2,cex.axis=cex.val)
  mtext(expression(W[t]), side=2, line=2.2, cex=cex.val)
  points(c(0,T),rep(0,2),type="l",col="grey",lty=2)
}

# Plot W^2
dev.new()
plot(t,W2,ylim=ylW2,type="l",col="blue",lwd=1,xlab="",ylab="",xaxt="n",yaxt="n")#,mgp=c(2,1,0)
#plot(t,f(t),type="l",col="blue",lwd=2,ylab=substitute(paste("f(t) and ",f^(n),"(t)")),mgp=c(2,1,0))
axis(1,cex.axis=cex.val)
mtext("t", side=1, line=2.2, cex=cex.val)
axis(2,cex.axis=cex.val)
mtext(expression(W[t]^2/2), side=2, line=2.2, cex=cex.val)
points(c(0,T),rep(0,2),type="l",col="grey",lty=2)

for(i in 1:length(n)){
  dev.new()
  #plot(t,W2,ylim=ylW2,type="l",col="blue",lwd=1,xlab="",ylab="",mgp=c(2,1,0))#ylab=substitute(paste("f(t) and ",f^(n),"(t)"))
  plot(t,W2,ylim=ylW2,type="l",col="blue",lwd=1,xlab="",ylab="",xaxt="n",yaxt="n")#,mgp=c(2,1,0)
  axis(1,cex.axis=cex.val)
  mtext("t", side=1, line=2.2, cex=cex.val)
  axis(2,cex.axis=cex.val)
  mtext(expression(W[t]^2/2), side=2, line=2.2, cex=cex.val)
  ni=n[i]
	s=seq(1,nT,ni)
	N=length(s)
	print(N-1)
	f.hat=rep(0,N)
	Wi=W[s]
	#points(rep(t[s[1]],2),c(0,f.hat[1]),type="l",lty=3,col="black")
	for(j in 2:N){
		f.hat[j]=f.hat[j-1]+add.drift*ni*dt/2+Wi[j-1]*(Wi[j]-Wi[j-1])
		points(rep(t[s[j]],2),c(0,f.hat[j]),type="l",lty=3,col="black")
	}
	points(t[s],f.hat,type="l",col="red",lty=2,lwd=1)
	points(t[s],f.hat,type="p",pch=19,col="red")
}
