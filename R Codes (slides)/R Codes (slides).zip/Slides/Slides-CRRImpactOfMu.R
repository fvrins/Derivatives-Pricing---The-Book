# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 9.9 -  Impact of mu on option price in CRR
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

s0=70
K=81
T=4
r=0.05
mu=seq(-0.05,0.1,0.01)
sigma=0.18
mu.star=r-sigma^2/2
n.vec=c(2,10,250)
N=length(n.vec)
M=length(mu)
v=matrix(0,nrow=N,ncol=M)
col.v=c("blue","red","magenta","cyan","orange","yellow","brown","green")
type.v=c(1,2,3)
for(i in 1:N){
  n=n.vec[i]
for(k in 1:M){
  delta=T/n
  alpha=exp(mu[k]*delta+sigma*sqrt(delta))
  beta=exp(-2*sigma*sqrt(delta))
  j=seq(0,n)
  betaj=beta^j
  u=alpha
  d=exp(mu[k]*delta-sigma*sqrt(delta))
  p=(exp(r*delta)-d)/(u-d)
  payoff=pmax(s0*alpha^n*betaj-K,0)
  v[i,k]=exp(-r*T)*payoff%*%dbinom(j,n,1-p)
}
  if(i==1){
    plot(mu,v[i,],type="l",col=col.v[1],lty=type.v[i],ylab="Option Price",xlab=bquote(mu),lwd=2, cex.axis=1.5, cex.lab=1.5)
  }else{
    points(mu,v[i,],type="l",col=col.v[i],lty=type.v[i],lwd=2)
  }
}
points(rep(mu.star,2),c(0,100),type="l",col="black",lty=3,lwd=1)

delta.vec=T/n.vec

ptilde=function(mu,delta){
  u=exp(mu*delta+sigma*sqrt(delta))
  d=exp(mu*delta-sigma*sqrt(delta))
  return((exp(r*delta)-d)/(u-d))
}
plot(mu,ptilde(mu,delta.vec[1]),type="l",col=col.v[1],lty=type.v[1],ylab=" ",xlab=bquote(mu),lwd=2, cex.axis=1, cex.lab=1.5)
title(ylab=expression(p~"*"), line=2, cex.lab=1.5)
for(k in 1:N){
  points(mu,ptilde(mu,delta.vec[k]),type="l",col=col.v[k],lty=type.v[k],lwd=2)
}
points(rep(mu.star,2),c(0,1),type="l",col="black",lty=3,lwd=1)
points(c(mu[1],mu[M]),rep(0.5,2),type="l",col="black",lty=3,lwd=1)

dev.new()
n<-seq(1,1000000)
pn=ptilde(r-sigma^2/2,1/n)
plot(n,pn,type="l",col="blue",xlab="n",ylab=expression(p~"*"),ylim=c(0.49,0.501))
points(n,ptilde(0,1/n),type="l",col="red",lty=2)
points(c(0,max(n)),rep(1/2,2),type="l",lty=3)
