
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# EXAMPLE 5.9 - Estimation of E[(ST-K)^+] using MC with  plain MC or
#                                                         conditional sampling 
#             - Attention: this is NOT the price of a European call because 
#                         (i)  there is no discounting
#                         (ii) the expectation is computed under P (not P*)
#             - However, it is possible to get it from the call price 
#               by modifying the parameters
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())
display.title=TRUE

# Stock & option parameters
s0=12
sigma=0.2
K=15
mu=0.02
T=2

# Monte Carlo parameters
n.seq=seq(10,1000,10)       # n in {10,20,30,...,1000}
N=length(n.seq)
M=1000                      # Repeat M times each estimation featuring n samples

# Intialization of NxM matrices
ExpMax.PlainMC=matrix(0,ncol=M,nrow=N)
ExpMax.CondMC=ExpMax.PlainMC

p=1-pnorm((log(K/s0)-(mu-sigma^2/2)*T)/(sigma*sqrt(T))) #p=1-F_{S_T}(K)

for(i in 1:N){
  n<-n.seq[i]
  # fix the number n of samples to n.seq[n]
  for (m in 1:M){
    # for this n, repeat M times the MC estimation
    u=runif(n)                               # n uniform samples u_i  
    z=qnorm(u)                                      # n std normal samples z_i (PIT)
    # Plain MC
    sT<-s0*exp((mu-sigma^2/2)*T+sigma*sqrt(T)*z)    # n samples from S_T
    payoff.PlainMC<-((sT-K)+abs(sT-K))/2            # n samples from the payoff Psi(S_T)
    ExpMax.PlainMC[i,m]<-mean(payoff.PlainMC)       # average the n.seq[n] samples of the payoff
    # Conditional MC
    sT.Cond<-s0*exp((mu-sigma^2/2)*T+sigma*sqrt(T)*qnorm((1-p)+p*u))  # n.seq[n] samples from S_T|S_T>K
    payoff.CondMC<-sT.Cond-K                                          # n.seq[n] samples from the payoff Psi(S_T) (no need of the max because S_T>K by construction) 
    ExpMax.CondMC[i,m]<-mean(payoff.CondMC)*p                         # average the n.seq[n] samples of the payoff multiplied by the probability that S_T>K
  }
}

x.mn=rep(0,N)
y.mn=x.mn
x.sd=x.mn
y.sd=x.mn

# Compute mean and standard deviation of both the Plain and Conditional MC estimatorfor each n in n.seq
for(n in 1:N){
  x.mn[n]=mean(ExpMax.PlainMC[n,]) 
  x.sd[n]=sd(ExpMax.PlainMC[n,])
  y.mn[n]=mean(ExpMax.CondMC[n,])
  y.sd[n]=sd(ExpMax.CondMC[n,])
}
yl=c(min(x.mn-x.sd,y.mn-y.sd),max(x.mn+x.sd,y.mn+y.sd))

dev.new()
if(display.title){
  plot(n.seq,x.mn,xlab="n",type="l",ylab="",col="blue",ylim=yl, cex.axis=1, cex.lab=1.2,mgp=c(2,1,0),lwd=1.5,main="Convergence of MC estimator")
  legend(n.seq[round(2*N/3)], x.mn[1]+x.sd[1], legend=c("Conditional MC", "Plain MC"),
         col=c("red", "blue"), lty=c(3,1), cex=0.8)
}else{
  plot(n.seq,x.mn,xlab="n",type="l",ylab="",col="blue",ylim=yl, cex.axis=1, cex.lab=1.2,mgp=c(2,1,0),lwd=1.5)
}
points(n.seq,x.mn-x.sd,type="l",col="blue",lty=2,lwd=1.5)
points(n.seq,x.mn+x.sd,type="l",col="blue",lty=2,lwd=1.5)
points(n.seq,y.mn,type="l",col="red",lwd=1.5)
points(n.seq,y.mn+y.sd,type="l",col="red",lty=2,lwd=1.5)
points(n.seq,y.mn-y.sd,type="l",col="red",lty=2,lwd=1.5)

# Exact price can be computed using GBM call replacing r by mu and cancelling the discounting
BS.call=function(r,S0,K,vol,T){
  d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
  d2=d1-vol*sqrt(T)
  return(S0*pnorm(d1)-K*exp(-r*T)*pnorm(d2))
}
BS.call(mu,s0,K,sigma,T)*exp(mu*T)
