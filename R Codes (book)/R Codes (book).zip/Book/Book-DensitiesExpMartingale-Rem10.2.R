# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# REMARK 10.2 - This code plots densities of Exp(sigma*W_t-sigma^2/2 t) for some t
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

sigma=0.3

dx=0.01
X=3
x=c(0,dx/5000,dx/100,dx/10,seq(dx,X-dx,dx),X-dx/10,X-dx/100,X-dx/5000,X)
t=c(0.08,0.2,0.5,1,2,3,5,10,20,40)
nt=length(t)
col.v=c("red","brown","purple","magenta","pink","orange","yellow","green","cyan","blue")

f=function(x,t){
	# density (lognormal) of DD exponential of BM with vol sigma
	dnorm(log(x)/(sigma*sqrt(t))+sigma/2*sqrt(t))/(x*sigma*sqrt(t))
}
PauseIt=function(x){
	p1 <- proc.time() 
	Sys.sleep(x) 
	proc.time() - p1
}

plot(x,f(x,t[1]),type="l",col=col.v[1],xlab="x",ylab="f(x)",main="Density of Exp. Martingale",ylim=c(0,8))
print(paste("t=",t[1]," Integral (num.): ",integrate(f,0,Inf,t[1])$value))
PauseIt(0.5)
for (i in 1:nt){
	print(paste("t=",t[i]," Integral (num.): ",integrate(f,0,Inf,t[i])$value))
	points(x,f(x,t[i]),type="l",col=col.v[i])
	PauseIt(0.75)
}
