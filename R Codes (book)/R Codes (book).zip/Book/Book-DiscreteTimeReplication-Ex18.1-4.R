# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# Ex 18.1, 18.3 & 18.4
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# ----------------------------------------------------------------------------
# INUPTS
# ----------------------------------------------------------------------------

r  	  = 0.02		# risk-free rate
sigma   = 0.15			# volatility
mu	  = 0.1  # r-sigma^2/2			# drift of stock
S0      = 38
K 	  = 36			# strike


# ----------------------------------------------------------------------------
# GBM FUNCTIONS
# ----------------------------------------------------------------------------
  
d = function(tau,x,pm){
  if(pm=="p"){
    y = (r+sigma^2/2)
  }else{
    y = (r-sigma^2/2)
  }
  return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
}
Call = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( x*pnorm(d(tau,x,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,"m")) )
}

Delta = function(tau,x,option){
  # This is the delta of the option: V_x(t,x)
  if(option=="call"){
    return( pnorm(d(tau,x,"p")) )
  }else{
    return( pnorm(d(tau,x,"p"))-1 )     # put
  }
}
Gamma = function(tau,x,option){
  # This is the gamma of the option: V_xx(t,x) (same for Call andPut)
  return( dnorm(d(tau,x,"p"))/(sigma*x*sqrt(tau)) )
}
Theta = function(tau,x,option){
  # This is the theta of the option: V_t(t,x)
  if(option=="call"){
    return( -r*K*exp(-r*tau)*pnorm(d(tau,x,"m"))-dnorm(d(tau,x,"p"))*sigma*x/(2*sqrt(tau)) )
  }else{
    return( +r*K*exp(-r*tau)*pnorm(-d(tau,x,"m"))-dnorm(d(tau,x,"p"))*sigma*x/(2*sqrt(tau)) )     # put
  }  
}

# ----------------------------------------------------------------------------
# Trajectory
# ----------------------------------------------------------------------------

dt<-1/12
T<-4*dt
t<-seq(0,T,dt)
nt<-length(t)
St<-c(38.000,37.010,37.333,36.032,38.637)
Vt<-round(Call(T-t,St),3)
Deltat<-round(Delta(T-t,St,"call"),3)
Thetat<-round(Theta(T-t,St,"call"),3)
Gammat<-round(Gamma(T-t,St,"call"),3)

Pit<-rep(Vt[1],nt)
Casht.before<-rep(0,nt-1)
Casht.after<-rep(0,nt-1)
for(i in 1:(nt-1)){
	Casht.after[i]<-round((Pit[i]-Deltat[i]*St[i]),3)
	Casht.before[i]<-round(Casht.after[i]*exp(r*dt),3)
	Pit[i+1]<-round(Casht.before[i]+Deltat[i]*St[i+1],3)
}
# Example 18.1
print("Stock price trajectory:")
print(St)
print("Call price trajectory:")
print(Vt)
print("Replicating strategy trajectory:")
print(Pit)
print("Cash before rebalancing:")
print(c(Vt[1],Casht.before))
print("Cash after rebalancing:")
print(c(Casht.after,Pit[nt]))
print("Delta trajectory:")
print(Deltat[1:(nt-1)])
# Example 18.3
print("Stock price trajectory:")
print(St)
print("Call price trajectory:")
print(Vt)
print("Delta trajectory:")
print(Deltat[1:nt-1])
print("Theta trajectory:")
print(Thetat[1:nt-1])
print("Gamma trajectory:")
print(Gammat[1:nt-1])
A=round(Deltat[1:(nt-1)]*diff(St),3)
B=round(Thetat[1:(nt-1)]*dt,3)
C=round(Gammat[1:(nt-1)]*diff(St)^2/2,3)
print("rounded Delta*dS")
print(A)
print("rounded Theta*dt")
print(B)
print("rounded 1/2Gamma*(dS)^2")
print(C)
print(A+B+C)
print(diff(Vt))
print("PnL errors")
print(diff(Vt)-(A+B+C))