
u<-c(0.7910,0.4404,0.5517,0.025,0.7486) #uniform samples
z<-qnorm(u)
est<-mean(pmax(0,2*z))
print(est)
#using more samples:
n<-100000
z<-qnorm(runif(n))
est<-mean(pmax(0,2*z))
print(est)
#theoretical
th<-2*dnorm(0)
print(th)