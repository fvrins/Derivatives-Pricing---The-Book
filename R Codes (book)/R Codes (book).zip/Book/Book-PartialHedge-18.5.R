# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 18.8 - Partial hedge payoffs
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

x<-seq(6,76)
x.plot<-seq(6,76,2)
K<-36
Kp<-40
V0<-7.89
S0<-38
T<-5
r<-0.02
Payoff.1<-function(x){-((x-K)+abs(x-K))/2}
Payoff.2<-function(x){((x-Kp)+abs(x-Kp))/2}
Delta0<-0.7347
CT<-(V0-Delta0*S0)*exp(r*T)
Payoff.a<-function(x){Payoff.1(x)+Payoff.2(x)}
Payoff.b<-function(x){Payoff.1(x)+Delta0*x+CT}

dev.new()
#plot(x,Payoff.1(x),type="l",col="blue",xlab=expression(S[T]),ylab="Value at expiry",main="",cex=1.2,ylim=c(-15,15))
plot(x,Payoff.1(x),type="l",col="blue",xaxt="n",yaxt="n",xlab="",ylab="",main="",ylim=c(-15,15))
axis(1,cex.axis=1.2)
mtext(expression(S[T]), side=1, line=2.5, cex=1.2)
axis(2,cex.axis=1.2)
mtext("Value at expiry", side=2, line=2.2, cex=1.2)
points(x,Payoff.2(x),type="l",lty=2,col="blue")
points(x,Payoff.a(x),type="l",lty=3,col="blue")
points(x.plot,Payoff.a(x.plot),type="p",col="blue")

dev.new()
#plot(x,Payoff.1(x),type="l",col="blue",xlab=expression(S[T]),ylab="Value at expiry",main="",cex=1.2,ylim=c(-15,15))
plot(x,Payoff.1(x),type="l",col="blue",xaxt="n",yaxt="n",xlab="",ylab="",main="",ylim=c(-15,15))
axis(1,cex.axis=1.2)
mtext(expression(S[T]), side=1, line=2.5, cex=1.2)
axis(2,cex.axis=1.2)
mtext("Value at expiry", side=2, line=2.2, cex=1.2)
points(x,CT+Delta0*x,type="l",lty=2,col="blue")
points(x,Payoff.b(x),type="l",lty=3,col="blue")
points(x.plot,Payoff.b(x.plot),type="p",col="blue")
