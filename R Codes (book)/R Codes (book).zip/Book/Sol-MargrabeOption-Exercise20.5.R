
r=0.05
T<-1
S0.a<-38
S0.b<-42
mu.a=0.02
mu.b=0.04
sigma.a=0.1
sigma.b=0.15
rho=-0.8
X0<-S0.b/S0.a
sigma=sqrt(sigma.a^2+sigma.b^2-2*rho*sigma.a*sigma.b)

BS.call=function(r,S0,K,vol,T){
	d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
	d2=d1-vol*sqrt(T)
	return(S0*pnorm(d1)-K*exp(-r*T)*pnorm(d2))
}

BS.Call.Margrabe<-S0.a*BS.call(0,X0,1,sigma,T)

M<-10000000
Z<-rnorm(M)
Z.perp<-rnorm(M)
ST.b<-S0.b*exp((r-(sigma.b)^2/2)*T+sigma.b*sqrt(T)*Z)
ST.a<-S0.a*exp((r-(sigma.a)^2/2)*T+sigma.a*sqrt(T)*(rho*Z+sqrt(1-rho^2)*Z.perp))
MC.Call.Margrabe<-exp(-r*T)*mean(((ST.b-ST.a)+abs(ST.b-ST.a))/2)

print(MC.Call.Margrabe)
print(BS.Call.Margrabe)