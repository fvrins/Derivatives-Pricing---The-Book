# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 14.2 -  Euler scheme for SDE
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())
T=10
dt=0.01
t=seq(0,T,dt)
nT=length(t)
#n=c(5000,1000,250,100,1)
n=c(1000,250,50,20)
S0=10
mu=1/100
sigma=20/100

# Draw a sample path for the Brownian motion W
dW=c(0,rnorm(nT-1)*sqrt(dt))
W=cumsum(dW)

f=function(t){S0*exp((mu-sigma^2/2)*t+sigma*W)}
#plot(t,f(t))

#plot(t,f(t),type="l",col="blue",lwd=2,ylab=substitute(paste("f(t) and ",f^(n),"(t)")),mgp=c(2,1,0))
for(i in 1:length(n)){
  plot(t,f(t),ylim=c(0,15),type="l",col="blue",lwd=2,xlab="",ylab="",mgp=c(2,1,0))#ylab=substitute(paste("f(t) and ",f^(n),"(t)"))
  ni=n[i]
	s=seq(1,nT,ni)
	N=length(s)
	print(N-1)
	f.hat=rep(S0,N)
	Wi=W[s]
	#points(rep(t[s[1]],2),c(0,f.hat[1]),type="l",lty=3,col="black")
	for(j in 2:N){
		f.hat[j]=f.hat[j-1]*(1+mu*ni*dt+sigma*(Wi[j]-Wi[j-1]))
		points(rep(t[s[j]],2),c(0,f.hat[j]),type="l",lty=3,col="black")
	}
	points(t[s],f.hat,type="l",col="red",lty=2,lwd=2)
	points(t[s],f.hat,type="p",pch=19,col="red")
}
points(t,f(t),type="l",col="blue",lwd=3)