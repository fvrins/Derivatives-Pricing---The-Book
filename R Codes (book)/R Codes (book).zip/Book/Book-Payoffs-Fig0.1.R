
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE .01 -  Payoff of Zero-coupon bond, forward contract, 
#               European call and European put
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# Parameters
K=10 # strike
display.title=TRUE #TRUE of FALSE

# range
x=seq(0,20,.01)
nx=length(x)

if(display.title){
  # Zero-coupon bond with face value $1
  plot(x,rep(1,nx),col="blue",type="l",lwd=2,xlab="x",ylab=expression(psi(x)),ylim=c(-1,2),main="Zero-coupon bond with face value $1")
  points(x,rep(0,nx),col="black",type="l",lty=2)
  # Forward contract with strike K
  plot(x,x-K,col="blue",type="l",lwd=2,xlab="x",ylab=expression(psi(x)),ylim=c(-12,12),main=bquote("Forward contract with strike K="~.(K)))
  points(x,rep(0,nx),col="black",type="l",lty=2)
  # European call with strike K
  plot(x,((x-K)+abs(x-K))/2,type="l",col="blue",lwd=2,xlab="x",ylab=expression(psi(x)),ylim=c(-2,10),main=bquote("European call option with strike K="~.(K)))
  points(x,rep(0,nx),col="black",type="l",lty=2)
  # European put with strike K
  plot(x,((K-x)+abs(K-x))/2,type="l",col="blue",lwd=2,xlab="x",ylab=expression(psi(x)),ylim=c(-2,10),main=bquote("European put option with strike K="~.(K)))
  points(x,rep(0,nx),col="black",type="l",lty=2)
}else{
  # Zero-coupon bond with face value $1
  plot(x,rep(1,nx),col="blue",type="l",lwd=2,xlab="x",ylab=expression(psi(x)),ylim=c(-1,2))
  points(x,rep(0,nx),col="black",type="l",lty=2)
  # Forward contract with strike K
  plot(x,x-K,col="blue",type="l",lwd=2,xlab="x",ylab=expression(psi(x)),ylim=c(-12,12))
  points(x,rep(0,nx),col="black",type="l",lty=2)
  # European call with strike K
  plot(x,((x-K)+abs(x-K))/2,type="l",col="blue",lwd=2,xlab="x",ylab=expression(psi(x)),ylim=c(-2,10))
  points(x,rep(0,nx),col="black",type="l",lty=2)
  # European put with strike K
  plot(x,((K-x)+abs(K-x))/2,type="l",col="blue",lwd=2,xlab="x",ylab=expression(psi(x)),ylim=c(-2,10))
  points(x,rep(0,nx),col="black",type="l",lty=2)
}