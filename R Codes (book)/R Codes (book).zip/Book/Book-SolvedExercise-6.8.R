
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# EXERCISE 6.8 - Estimation of Corr[S^a_T,S^b_T] using MC
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

s0.a<-30
s0.b<-12
mu.a<-0.1
mu.b<-0.15
sigma.a<-0.2
sigma.b<-0.17
rho<-seq(-0.9,0.9,0.1)

M<-50000

n.rho<-length(rho)
Z<-rnorm(M)
Z.perp<-rnorm(M)
corr.rho<-rep(0,n.rho)
for(i in 1:n.rho){
  Z.a<-Z
  Z.b<-rho[i]*Z+sqrt(1-rho[i]^2)*Z.perp

  ST.a<-s0.a*exp(mu.a+sigma.a*Z.a)
  ST.b<-s0.b*exp(mu.b+sigma.b*Z.b)

  corr.rho[i]<-cor(ST.a,ST.b)
}

corr.th=function(r){
  (exp(r*sigma.a*sigma.b)-1)/sqrt((exp(sigma.a^2)-1)*(exp(sigma.b^2)-1))
}
dev.new()
plot(rho,corr.th(rho),type="l",col="blue")
points(rho,corr.rho,type="l",col="red",lty=2)