# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 5.3 -  Approximation E[exp(max(X,Y))] using Monte Carlo
#               where X~Y~N(0,1) iid.
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

M=10
N=c(10,100,1000,10000)
LN=length(N)
Est=matrix(0,nrow=M,ncol=LN)

for(j in 1:LN){
	Nj=N[j]
	for(m in 1:M){
		z=rep(0,Nj)
		u=runif(2*N[j])
		x=qnorm(u[1:Nj])
		y=qnorm(u[(Nj+1):(2*Nj)])
		for(k in 1:Nj){
			z[k]=max(x[k],y[k])
		}
		Est[m,j]=mean(z)
	}
}
boxplot(Est)
points(c(0,4),rep(1/sqrt(pi),2),type="l",col="red",lty=2,lwd=2)
