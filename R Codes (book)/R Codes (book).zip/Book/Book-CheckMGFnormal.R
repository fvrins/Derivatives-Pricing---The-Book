
n<-1000000
mu<--1
sigma<-0.5
u<-seq(0,5,0.1)
nu<-length(u)
z<-rnorm(n,mu,sigma)
phiZ<-function(u){exp(mu*u+(sigma*u)^2/2)}
phiZ.hat<-rep(0,nu)
for(i in 1:nu){
  phiZ.hat[i]<-mean(exp(u[i]*z))
}

plot(u,phiZ(u),type="l",col="blue")
points(u,phiZ.hat,type="l",col="red",lty=2)
