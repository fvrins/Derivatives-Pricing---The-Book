# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 18.1 - Dynamic replication in the BSM model
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

#clean data space
rm(list=ls(all=TRUE))

# ----------------------------------------------------------------------------
# INUPTS
# ----------------------------------------------------------------------------

T  	  = 1			  # maturity
r  	  = 2/100		# risk-free rate
mu	  = 0.1			# alpha (drift of stock)
S0 	  = 38			# strike
K 	  = 38			# strike
sigma = 0.15		# volatility
delta = 1/252   # rebalancing times
m     = 5       # nb of trajectories
set.seed(1)
cex.val<-1.3
# ----------------------------------------------------------------------------
# GBM FUNCTIONS
# ----------------------------------------------------------------------------

d = function(tau,x,pm){
  if(pm=="p"){
    y = (r+sigma^2/2)
  }else{
    y = (r-sigma^2/2)
  }
  return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
}
Call = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( x*pnorm(d(tau,x,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,"m")) )
}
Delta.Call = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( pnorm(d(tau,x,"p")))
}

# ----------------------------------------------------------------------------
# GBM Trajectories
# ----------------------------------------------------------------------------

t<-seq(0,T,delta)
nt<-length(t)
V0<-Call(T,S0)
Delta0<-Delta.Call(T,S0)
C0=V0-Delta0*S0
Pi<-rep(V0,nt)
C<-rep(C0,nt)

idx.plot<-seq(1,nt,2)
for(j in 1:m){
  z<-rnorm(nt-1)
  w<-c(0,sqrt(delta)*cumsum(z))
  s<-S0*exp((mu-sigma^2/2)*t+sigma*w)
  v<-Call(T-t,s)
  Delta=Delta.Call(T-t,s)
  v.int<-((s-K)+abs(s-K))/2
  for(i in 2:nt){
    #at the end of delta, before rebalancing
    C[i]<-C[i-1]*exp(r*delta)-(Delta[i]-Delta[i-1])*s[i]
    Pi[i]<-C[i]+Delta[i]*s[i]
  }
  dev.new()
  plot(t,s,type="l",col="blue",ylim=c(25,50),xaxt="n",yaxt="n",xlab="",ylab="",main="")
  axis(1,cex.axis=cex.val)
  mtext("t", side=1, line=2.5, cex=cex.val)
  axis(2,cex.axis=cex.val)
  mtext(expression(S[t]), side=2, line=2.2, cex=cex.val)
  
  points(c(0,T),rep(S0,2),col="grey",type="l",lty=3)
  dev.new()
  plot(t,v,type="l",col="blue",ylim=c(0,10),xaxt="n",yaxt="n",xlab="",ylab="",main="")
  axis(1,cex.axis=cex.val)
  mtext("t", side=1, line=2.5, cex=cex.val)
  axis(2,cex.axis=cex.val)
  mtext("Option and replication strategy values", side=2, line=2.2, cex=cex.val)
  points(t[idx.plot],Pi[idx.plot],type="p",col="red")
  points(t,v.int,type="l",col="magenta",lty=2)
}