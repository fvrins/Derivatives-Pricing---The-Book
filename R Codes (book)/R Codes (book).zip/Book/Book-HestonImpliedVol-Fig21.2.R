# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 21.2 - Implied volatility surface
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

library(NMOF)
library(plotly)
tau<-c(0.25,0.5,0.75,seq(1,10))
#tau<-seq(1,24)/12
n.tau<-length(tau)
K<-c(1000,seq(2000,8000,500),9000)
#K<-seq(120,180,5)
n.K<-length(K)
S<-4000
#S <- 150; 
r <- 0.02; 
q <- 0
v0  <- 0.16#0.2^2  ## variance, not volatility
vT  <- 0.04#0.2^2  ## variance, not volatility
rho <- -0.7#-0.7; 
k <- 1.1#0.1; 
sigma <- 0.45#0.5

M<-expand.grid(K,tau)
x<-M$Var1
y<-M$Var2
z<-outer(K,tau)
nz<-length(z)
for(i in 1:n.tau){
  for(j in 1:n.K){
    ## get Heston price and BSM implied volatility
    z[j,i] <- callHestoncf(S = S, X = K[j], tau = tau[i], r = r, q = q,
                           v0 = v0, vT = vT, rho = rho, k = k,
                           sigma = sigma, implVol = TRUE)$value #$impliedVol   #
  } 
}
z<-unlist(z)

persp(K,tau,z,main="", xlab="strike (K)", ylab="time-to-expiry (tau)",zlab="Price",
theta = 135, phi = 15,ticktype="detailed",
col = "springgreen", shade = 0.5)

