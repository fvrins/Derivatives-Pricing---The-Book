
pdf= "normal" #"normal"# "exp"# "3x2"# "unif"

if(pdf=="unif"){
  a=-1#0#0.25#
  b=2#1#0.75#
	#x=seq(a-0.5,b+0.5,.001)
  x=seq(-2,3,.001)
	p=function(x){
		dunif(x,a,b)
	}
	F=function(x){
		punif(x,a,b)
	}
}else if(pdf=="3x2"){
	x=seq(-1,2,.01)
	p=function(x){
		3*x^2*(x>0)*(x<1)
	}
	F=function(x){
		x^3*(x>0 & x<1)+1*(x>=1)
	}
}else if(pdf=="exp"){
	lambda=0.5#0.5#1#2
	x=seq(-1,6,.01)
	p=function(x){
		dexp(x,lambda)
	}
	F=function(x){
		pexp(x,lambda)
	}
}else if(pdf=="normal"){
	mu=-1.5#0#-1.5
	sigma=2#1
	x=seq(-8,8,.01)
	p=function(x){
		dnorm(x,mu,sigma)
	}
	F=function(x){
		pnorm(x,mu,sigma)
	}
}

mx=min(x)
Mx=max(x)
dev.new()
y=p(x)
Mp=max(y)*1.05
plot(x, y, type="l", col = "blue", xlab="x", ylab = "p(x)",lwd=1.5, ylim=c(0,Mp)) 
grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted",
     lwd = par("lwd"), equilogs = TRUE)
points(x, y, type="l", col = "blue",lwd=1.5) 
#points(x, y, type="l", col = "red",lwd=1.5,lty=2) 
#points(x, y, type="l", col = "magenta",lwd=1.5,lty=3) 

dev.new()
y=F(x)
Mp=1.05
plot(x, y, type="l", col = "blue", xlab="x", ylab = "F(x)",lwd=1.5, ylim=c(0,Mp)) 
grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted",
     lwd = par("lwd"), equilogs = TRUE)
#points(x, y, type="l", col = "red",lwd=1.5,lty=2) 
#points(x, y, type="l", col = "magenta",lwd=1.5,lty=3) 