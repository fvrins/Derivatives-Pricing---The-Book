# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 18.6 - Hedging errors impact
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# ----------------------------------------------------------------------------
# INUPTS
# ----------------------------------------------------------------------------

r  	  = 0.02		# risk-free rate
sigma = 0.15		# volatility
S0    = 38      # current value
K 	  = 36			# strike
T     = 5       # maturity

# ----------------------------------------------------------------------------
# GBM FUNCTIONS
# ----------------------------------------------------------------------------
  
d = function(tau,x,pm){
  if(pm=="p"){
    y = (r+sigma^2/2)
  }else{
    y = (r-sigma^2/2)
  }
  return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
}
Call = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( x*pnorm(d(tau,x,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,"m")) )
}
Delta.Call = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( pnorm(d(tau,x,"p")))
}

V0<-Call(T,S0)
Delta0<-Delta.Call(T,S0)
C0=V0-Delta0*S0

# Effect of t
dt<-0.1
t<-seq(0,T,dt)
nt<-length(t)
Vt<-Call(T-t,rep(S0,nt))
Pit<-C0*exp(r*t)+Delta0*S0

dev.new()
#plot(t,Vt,ylim=c(0,8),type="l",col="blue",xlab="t",ylab="Option & Hedge values",cex=1.2)
plot(t,Vt,ylim=c(0,8),type="l",col="blue",xaxt="n",yaxt="n",xlab="",ylab="",main="")
axis(1,cex.axis=1.2)
mtext("t", side=1, line=2.5, cex=1.2)
axis(2,cex.axis=1.2)
mtext("Option & Hedge values", side=2, line=2.2, cex=1.2)
points(t,Pit,type="l",lty=2,col="blue")

dev.new()
#plot(t,Pit-Vt,ylim=c(0,5),type="l",col="blue",xlab="t",ylab="Book value",cex=1.2)
plot(t,Pit-Vt,ylim=c(0,5),type="l",col="blue",xaxt="n",yaxt="n",xlab="",ylab="",main="")
axis(1,cex.axis=1.2)
mtext("t", side=1, line=2.5, cex=1.2)
axis(2,cex.axis=1.2)
mtext("Book value", side=2, line=2.2, cex=1.2)
points(t,Pit,type="l",lty=2,col="blue")

# Effect of S0
St<-seq(20,55)
nSt<-length(St)
Vt<-Call(rep(T,nSt),St)
Pit<-C0+Delta0*St

dev.new()
#plot(St,Vt,ylim=c(-5,25),type="l",col="blue",xlab=expression(S[0]),ylab="Option & Hedge values",cex=1.2)
plot(St,Vt,ylim=c(-5,25),type="l",col="blue",xaxt="n",yaxt="n",xlab="",ylab="",main="")
axis(1,cex.axis=1.2)
mtext(expression(S[0]), side=1, line=2.5, cex=1.2)
axis(2,cex.axis=1.2)
mtext("Option & Hedge values", side=2, line=2.2, cex=1.2)
points(St,Pit,type="l",lty=2,col="blue")
points(S0,V0,type="p",pch=19,col="blue")
points(rep(S0,2),c(-10,100),col="grey",lty=2,type="l")
points(c(0,100),rep(V0,2),col="grey",lty=2,type="l")
dev.new()
#plot(St,Pit-Vt,ylim=c(-8,0),type="l",col="blue",xlab=expression(S[0]),ylab="Book value",cex=1.2)
plot(St,Pit-Vt,ylim=c(-8,0),type="l",col="blue",xaxt="n",yaxt="n",xlab="",ylab="",main="")
axis(1,cex.axis=1.2)
mtext(expression(S[0]), side=1, line=2.5, cex=1.2)
axis(2,cex.axis=1.2)
mtext("Book value", side=2, line=2.2, cex=1.2)
points(rep(S0,2),c(-10,100),col="grey",lty=2,type="l")