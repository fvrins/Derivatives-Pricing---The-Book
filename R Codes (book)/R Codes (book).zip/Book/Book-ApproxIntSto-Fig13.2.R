# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 13.2 -  Approximation of a stochastic integral
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# Ito correction
add.drift=0 #"0" if standard calculus (wrong solution) "1" if stochastic calculus (correct solution: add t/2)

T=10
dt=0.01
t=seq(0,T,dt)
nT=length(t)
#n=c(5000,1000,250,100,1)
n=c(1000,50,5,1)#c(1000,200,50,5)
S0=10
mu=1/100
sigma=20/100
dW=c(0,rnorm(nT-1)*sqrt(dt))
W=cumsum(dW)
W2=W^2/2
mW=min(W)
MW=max(W)
ylW=1.1*c(mW,MW)
ylW2=0.6*c(-T/2,max(mW^2,MW^2))


dev.new()
par(mfrow=c(3,2))
#if(add.drift==0){
  plot(t,W,ylim=ylW,type="l",col="blue",lwd=2,xlab="",ylab="",mgp=c(2,1,0))
  ylW2[1]=ylW[1]
#}

plot(t,W2,ylim=ylW2,type="l",col="blue",lwd=2,xlab="",ylab="",mgp=c(2,1,0))


#f=function(t){S0*exp((mu-sigma^2/2)*t+sigma*W)}
#plot(t,f(t))

#plot(t,f(t),type="l",col="blue",lwd=2,ylab=substitute(paste("f(t) and ",f^(n),"(t)")),mgp=c(2,1,0))
for(i in 1:length(n)){
  plot(t,W2,ylim=ylW2,type="l",col="blue",lwd=2,xlab="",ylab="",mgp=c(2,1,0))#ylab=substitute(paste("f(t) and ",f^(n),"(t)"))
  ni=n[i]
	s=seq(1,nT,ni)
	N=length(s)
	print(N-1)
	f.hat=rep(0,N)
	Wi=W[s]
	#points(rep(t[s[1]],2),c(0,f.hat[1]),type="l",lty=3,col="black")
	for(j in 2:N){
		f.hat[j]=f.hat[j-1]+add.drift*ni*dt/2+Wi[j-1]*(Wi[j]-Wi[j-1])
		points(rep(t[s[j]],2),c(0,f.hat[j]),type="l",lty=3,col="black")
	}
	points(t[s],f.hat,type="l",col="red",lty=2,lwd=2)
	points(t[s],f.hat,type="p",pch=19,col="red")
}
#points(t,W2,type="l",col="blue",lwd=3)