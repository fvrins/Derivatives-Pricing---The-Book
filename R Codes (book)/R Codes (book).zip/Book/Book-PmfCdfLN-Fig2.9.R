t=c(1,5,10)
nt=length(t)
mu=0.05
sigma=0.2
S0=38
muSt=S0*exp(mu*t)

lnpdf=function(x,t){
  sdt=sigma*sqrt(t)
  mut=(mu-sigma^2/2)*t
  1/(x)*dnorm(log(x/S0),mut,sdt)
}

lncdf=function(x,t){
  sdt=sigma*sqrt(t)
  mut=(mu-sigma^2/2)*t
  pnorm(log(x/S0),mut,sdt)
}

col.v=c("blue","red","magenta")
dev.new()
x=seq(1,110,.01)
plot(x,lnpdf(x,t[1]),type="l",ylab=expression(p[S[t]](x),xlab="x"),lwd=1.5,col=col.v[1])
for(i in 2:nt){
  points(x,lnpdf(x,t[i]),type="l",lty=i,lwd=1.5,col=col.v[i])  
}
grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted",
     lwd = par("lwd"), equilogs = TRUE)
dev.new()
x=seq(1,110,.01)
plot(x,lncdf(x,t[1]),type="l",ylab=expression(p[S[t]](x),xlab="x"),lwd=1.5,col=col.v[1])
for(i in 2:nt){
  points(x,lncdf(x,t[i]),type="l",lty=i,lwd=1.5,col=col.v[i])  
}
grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted",
     lwd = par("lwd"), equilogs = TRUE)