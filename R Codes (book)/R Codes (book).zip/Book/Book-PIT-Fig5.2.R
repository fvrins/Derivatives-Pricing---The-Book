# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 5.2 -  Sampling Uniform, Normal and Exponential using RNG and PIT
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# simulate N U(0,1)
N=10000
u=runif(N)

# Generate X ~ N(mu,sigma^2)
mu=1
sigma=2
z=qnorm(u,mu,sigma) # same as rnorm(N,mu,sigma)

# Generate X ~ Exp(k)
k=2
w=qexp(u,k)  # same as rexp(N,k)

# plot
dev.new()
par(mfrow=c(1,3))
hist(u,freq=FALSE,col="grey")
s=seq(0,1,1/100)
points(s,rep(1,length(s)),type="l",col="red",lwd=2)
hist(z,freq=FALSE,col="grey")
s=seq(-3*sigma,3*sigma,sigma/100)
points(s,dnorm(s,mu,sigma),type="l",col="red",lwd=2)
hist(w,freq=FALSE,col="grey")
s=seq(0,5/k,1/(k*100))
points(s,dexp(s,k),type="l",col="red",lwd=2)