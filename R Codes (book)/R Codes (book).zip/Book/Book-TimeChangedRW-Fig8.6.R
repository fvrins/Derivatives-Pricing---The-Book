# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 8.6 -  Sample paths of time-scaled rand walk (X^{(delta)})
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

mu=0.05
sigma=0.2
T=5
delta.vec<-c(1,5,10,20)
n.delta<-length(delta.vec)
nsteps.vec<-T*delta.vec
dt.vec=1/delta.vec
nmax=max(nsteps.vec)
n.MC=100
col.v=c("blue","green","red","pink","orange","yellow","brown","cyan","magenta","black")
yL=mu*T+sigma*c(-T,T)*1.2
#par(mfrow=c(2,2))
for(i in 1:n.delta){
	dev.new()
	t<-seq(0,T,dt.vec[i])
	for(j in 1:n.MC){
		z<-2*rbinom(nsteps.vec[i],1,0.5)-1
		M<-c(0,cumsum(z))
		X<-mu*t+sigma*sqrt(dt.vec[i])*M
		if(j==1){
			XT<-X[length(X)]
			plot(t,X,type="l",lty=1,lwd=2,col=col.v[j],ylim=yL,xlab="t",ylab=expression(X^(delta)))
		}else{
			points(t,X,type="l",lty=1,lwd=2,col=col.v[j])
			XT<-c(XT,X[length(X)])
		}
	}
	print(mean(XT))
	print(sd(XT))
	for(j in 1:length(t)){
		points(rep(t[j],2),yL,type="l",lty=3,col="grey90")
	}
}