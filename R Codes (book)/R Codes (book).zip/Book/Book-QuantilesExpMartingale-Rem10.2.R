# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# REMARK 10.2 - This code plots the CDF and quantiles of Exp(sigma*W_t-sigma^2/2 t)
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

sigma=0.5
mu=-sigma^2/2

t=seq(0,40,0.5)
nt=length(t)
ts=seq(0,40,5)
n.ts=length(ts)
idx=which(t==ts)
p=seq(.05,.95,.05)
np=length(p)
nmed=which(p==0.5)
u.LN=matrix(0,ncol=nt,nrow=np)
col.v=c("blue","red","cyan","magenta","green")

F=function(x,t){
	pnorm((log(x)-mu*t)/(sigma*sqrt(t)))
}

# ============================================================================
# QUANTILES TRAJECTORIES
# ============================================================================

# erf=function(x){2*pnorm(x*sqrt(2))-1}

for(i in 1:nt){
for(j in 1:np){
	m=mu*t[i]
	s=sigma*sqrt(t[i])

	u.LN[j,i]=exp(s*qnorm(p[j])+m)
}
}

n.Cplot<-2
n.Rplot<-1
par(mfrow = c(n.Rplot,n.Cplot ))

col.std="blue"
col.med="magenta"
col.y="red"

# plot 1
# ------

yl=c(0,1)
x=seq(0,5,.05)
tv=c(1,5,10,20,40)
plot(x,F(x,tv[1]), col=col.std,ylim=yl,type="l",ylab=substitute(paste("P(",E[t],"<=x)")),xlab="x",main=expression(paste("CDF of ",E[t])))
for(j in 2:length(tv)){
	
	points(x,F(x,tv[j]),col=col.v[j],type="l")
}
points(c(0,max(x)),c(1,1),type="l",lty=2)
points(c(0,max(x)),c(0,0),type="l",lty=2)
points(c(0,1),c(0.5,0.5),type="l",lty=3)
points(c(1,1),c(0,0.5),type="l",lty=3)

text(x=3,y=0.63,"value of t:")
legend(x=2,y=0.6,col=col.v,tv,lty=1)


# plot 2
# ------

yl=c(0,max(ceiling(u.LN)))
plot(t,u.LN[1,], col=col.std,ylim=yl,type="l",ylab="q(t,p)",xlab="t",main=expression(paste("Quantiles of ",E[t])))
for(j in 2:np){
	if(j==nmed){colc=col.med}else{colc=col.std}
	points(t,u.LN[j,],col=colc,type="l")
}
points(c(0,t[nt]),c(1,1),type="l",lty=2)
points(c(0,t[nt]),c(0,0),type="l",lty=2)

