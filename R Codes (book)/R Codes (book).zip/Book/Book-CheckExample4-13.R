
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# EXAMPLE 4.13 -  Check the result given in the book
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

theta<--0.25

L<-function(z){exp(-theta^2/2-theta*z)}
f<-function(z){2*dnorm(z)}
fzL<-function(z){z*L(z)*f(z)}
fL<-function(z){L(z)*f(z)}

f.theta<-function(z){z*dnorm(z+theta)}
#Etilde[Z|Z>0]
1/(1-pnorm(theta))*integrate(f.theta,0,Inf)$value

#
integrate(fzL,0,Inf)$value/integrate(fL,0,Inf)$value

M<-1000000
z<-rnorm(M)
zp<-z[which(z>0)]
Lzp<-L(zp)
mean(zp*Lzp)/mean(Lzp)

#analytical result
dnorm(theta)/(1-pnorm(theta))-theta