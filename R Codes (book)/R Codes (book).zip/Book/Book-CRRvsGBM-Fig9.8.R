# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 9.8 -  CRR vs GBM OPTION PRICING
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# ----------------------------------------------------------------------------
# INUPTS
# ----------------------------------------------------------------------------

tau  	  = 2			# maturity
r  	  = 0.01		# risk-free rate
sigma = 0.20		# volatility
mu	  = 0.02    # r-sigma^2/2			# drift of stock
S0    =12
K 	  = 11			# strike

# ----------------------------------------------------------------------------
# GBM FUNCTIONS
# ----------------------------------------------------------------------------
  
d = function(tau,x,pm){
  if(pm=="p"){
    y = (r+sigma^2/2)
  }else{
    y = (r-sigma^2/2)
  }
  return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
}
Fwd = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( x-K*exp(-r*tau))
}
Call = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( x*pnorm(d(tau,x,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,"m")) )
}
Put = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( K*exp(-r*tau)*pnorm(-d(tau,x,"m"))-x*pnorm(-d(tau,x,"p")) )
}

# ----------------------------------------------------------------------------
# CRR FUNCTIONS
# ----------------------------------------------------------------------------

n.vec<-seq(1,200)
l.n<-length(n.vec)
Call.CRR<-Put.CRR<-0*n.vec

p.star=function(delta){
  u=exp(mu*delta+sigma*sqrt(delta))
  d=exp(mu*delta-sigma*sqrt(delta))
  return((exp(r*delta)-d)/(u-d))
}

for(n in 1:l.n){
  s<-seq(0,n)
  delta<-tau/n
  alpha<-exp(mu*delta+sigma*sqrt(delta))
  beta<-exp(-2*sigma*sqrt(delta))
  q.star<-1-p.star(delta)
  s.vec<-S0*alpha^n*beta^{s}
  Call.CRR[n]<-sum((abs(s.vec-K)+(s.vec-K))/2*dbinom(s,n,q.star))
  Put.CRR[n]<-sum((abs(K-s.vec)+(K-s.vec))/2*dbinom(s,n,q.star))
}
Call.CRR<-Call.CRR*exp(-tau*r)
Put.CRR<-Put.CRR*exp(-tau*r)
Call.GBM<-Call(tau,S0)
Put.GBM<-Put(tau,S0)

dev.new()
plot(n.vec,Call.CRR,type="l",col="red",xlab="n",ylab="Call price",main="")
points(c(0,max(n.vec)),rep(Call.GBM,2),type="l",col="blue",lty=2)
dev.new()
plot(n.vec,Put.CRR,type="l",col="red",xlab="n",ylab="Put price",main="")
points(c(0,max(n.vec)),rep(Put.GBM,2),type="l",col="blue",lty=2)