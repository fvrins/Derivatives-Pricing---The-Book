# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 21.1 - Implied volatility principle
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# ----------------------------------------------------------------------------
# INUPTS
# ----------------------------------------------------------------------------

tau  	  = 1			# maturity
r  	  = 2/100		# risk-free rate
alpha	= 3*r			# alpha (drift of stock)
#sigma = 0.2			# volatility
S0      =38
K 	  = 42			# strike

sigma.vec<-seq(1,500)/100
nsigma=length(sigma.vec)
call.vec<-put.vec<-0*sigma.vec

for(i in 1:nsigma){
sigma<-sigma.vec[i]
# ----------------------------------------------------------------------------
# FUNCTIONS
# ----------------------------------------------------------------------------

d = function(tau,x,pm){
	if(pm=="p"){
		y = (r+sigma^2/2)
	}else{
		y = (r-sigma^2/2)
	}
	return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
}
Fwd = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( x-K*exp(-r*tau))
}
Call = function(tau,x){
	# This is the price of the option: V(t,x)
	# If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
	return( x*pnorm(d(tau,x,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,"m")) )
}
Put = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( K*exp(-r*tau)*pnorm(-d(tau,x,"m"))-x*pnorm(-d(tau,x,"p")) )
}
call.vec[i]<-Call(tau,S0)
put.vec[i]<-Put(tau,S0)
}

call.iv<-25
put.iv<-call.iv-(S0-K*exp(-r*tau))
f=function(sigma){
	d = function(tau,x,pm){
		if(pm=="p"){
			y = (r+sigma^2/2)
		}else{
			y = (r-sigma^2/2)
		}
		return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
	}
	Call = function(tau,x){
		# This is the price of the option: V(t,x)
		# If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
		return( x*pnorm(d(tau,x,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,"m")) )
	}
	Put = function(tau,x){
  		# This is the price of the option: V(t,x)
  		# If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  		return( K*exp(-r*tau)*pnorm(-d(tau,x,"m"))-x*pnorm(-d(tau,x,"p")) )
	}
	#return(call.iv-Call(tau,S0))
	return(put.iv-Put(tau,S0))
}
sigma.iv<-uniroot(f,c(0.1,3))$root
# ----------------------------------------------------------------------------
# Plot fun
# ----------------------------------------------------------------------------

plot(sigma.vec,call.vec,col="blue",type="l",lwd=2,xlab=expression(sigma),ylab="price",ylim=c(0,40), cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
points(sigma.vec,rep(max(0,S0-K*exp(-r*tau)),nsigma),col="grey",type="l",lwd=2,lty=3)
points(sigma.vec,rep(S0,nsigma),col="grey",type="l",lwd=2,lty=3)
arrows(0,call.iv,sigma.iv*0.95,call.iv,length=0.15)
arrows(sigma.iv,call.iv*0.95,sigma.iv,0,length=0.15)
points(rep(sigma.iv,2),c(0,call.iv),col="grey",type="l",lwd=2,lty=2)


plot(sigma.vec,put.vec,col="blue",type="l",lwd=2,xlab=expression(sigma),ylab="price",ylim=c(0,40), cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
points(sigma.vec,rep(max(0,K*exp(-r*tau)-S0),nsigma),col="grey",type="l",lwd=2,lty=3)
points(sigma.vec,rep(K*exp(-r*tau),nsigma),col="grey",type="l",lwd=2,lty=3)
arrows(0,put.iv,sigma.iv*0.95,put.iv,length=0.15)
arrows(sigma.iv,put.iv*0.95,sigma.iv,0,length=0.15)
points(rep(sigma.iv,2),c(0,put.iv),col="grey",type="l",lwd=2,lty=2)
