
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 3.6 -  Stock return analysis
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

library(tseries)
X=read.csv("AAPL20Y.csv")
a.min<-46
b.max<-5035
a<-a.min
b<-b.max
t=X$Date[a:b]
print(t[1])
print(t[length(t)])
P=X$Adj.Close[a:b]
n.P=length(P)
r=log(P[2:n.P]/P[1:(n.P-1)])
n.r=length(r)

dev.new()
mu.P=mean(P)
sigma.P=sd(P)
plot(P,type="p",pch=19,col="blue",cex.axis=1.2,xlab="i",ylab=expression(s[i]))
points(P,type="l",col="blue")
points(c(0,n.P),rep(mu.P,2),col="grey",type="l",lty=2)

dev.new()
mu.r=mean(r)
sigma.r=sd(r)
plot(r,type="p",pch=19,col="blue",cex.axis=1.2,xlab="i",ylab=expression(x[i]))
points(r,type="l",col="blue")
points(c(0,n.P),rep(mu.r,2),col="grey",type="l",lty=2)
points(c(0,n.P),rep(mu.r+3*sigma.r,2),col="grey",type="l",lty=2)
points(c(0,n.P),rep(mu.r-3*sigma.r,2),col="grey",type="l",lty=2)

dev.new()
x.P=seq(mu.P-3*sigma.P,mu.P+3*sigma.P,0.001)
hist(P,prob=T,col="blue",main="",cex.axis=1,xlab=expression(s[i]),ylab="Frequency",breaks=20,xlim=c(mu.P-3*sigma.P,mu.P+3*sigma.P))
points(x.P,dnorm(x.P,mu.P,sigma.P),type="l",col="red",lwd=2)

dev.new()
x.r=seq(mu.r-3*sigma.r,mu.r+3*sigma.r,0.001)
hist(r,prob=T,col="blue",main="",cex.axis=1,xlab=expression(x[i]),ylab="Frequency",breaks=20)
points(x.r,dnorm(x.r,mu.r,sigma.r),type="l",col="red",lwd=2)


r.std=(r-mu.r)/sigma.r
dev.new()
rs<-sort(r.std)
plot(qnorm(seq(1,n.r)/(n.r+1),0,1),rs,type="p", pch = 19, col="blue", main="",xaxt="n",yaxt="n",xlab="",ylab="",cex.axis=1.2)
axis(1,cex.axis=1.2)
mtext("Q(i)", side=1, line=2.2, cex=1.2)
axis(2,cex.axis=1.2)
mtext(expression(paste(hat(Q),"(i)")), side=2, line=2.2, cex=1.2)
x=seq(-3,3,.01)
points(x,x,type="l",col="red",lty=2,lwd=2)

shapiro.test(r)
acfvalues<-acf(r,lag.max=5, col="blue", main="",xlab="k",ylab="c(k)",cex.axis=1.2)
adf.test(r)
kpss.test(r)

print(mu.r*(252))
print(sigma.r*sqrt(252))
Xtreme<-which(r.std<=-3|r.std>=3)
