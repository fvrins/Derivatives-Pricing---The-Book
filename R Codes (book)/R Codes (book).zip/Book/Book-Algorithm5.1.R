
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# ALGORITHM 5.1 -  Sampling from the distribution Pr(X=i)=i/21 if i in {1,2,...,6} 
#                                                                 0 otherwise
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

N     = 10000   # nb of Monte Carlo simulations

# distribution from which we want to sample (can be changed)
x = seq(1,6)            # attainable values (support)
p  = seq(1,6)/21        # corresponding probabilities
np = length(p)          # number of possible values
p.cum = c(0,cumsum(p))  # cumulative probabilities (strating from 0)


ui<-runif(N)            # uniform samples (from RNG)
xi<-0*ui
for(i in 1:N){
  idx<-which(ui[i]<p.cum)[1]
  xi[i]<-x[idx-1]
}

# check that the frequencies are in line with the probabilities
dev.new()
freqi=as.vector(table(xi))/N
plot(x,p,col="blue",pch=1,lwd=2,ylim=c(0,max(freqi,p)))
points(x,freqi,col="red",pch=3,lwd=2)
legend(1, 0.20, legend=c("Frequency", "Probability"),
       col=c("red", "blue"), pch=c(3,1), cex=0.8)

mu.th=x%*%p
mu.MC=mean(xi)

print(c(paste("expectation:",mu.th)))
print(c(paste("Monte Carlo estimation using",N,"samples: ",mu.MC)))
