

n<-1000000
mu<-1
sigma<-2
x<-rnorm(n,mu,sigma)

prob.th<-1.5-pnorm(1)#=1-(pnorm(1,mu,sigma)-pnorm(-1,mu,sigma)) =1-(pnorm(0)-pnorm(-1))
prob.est<-length(which(abs(x)>1))/n

print(paste("Theoretical: ", prob.th))
print(paste("MC estimation: ", prob.est))

