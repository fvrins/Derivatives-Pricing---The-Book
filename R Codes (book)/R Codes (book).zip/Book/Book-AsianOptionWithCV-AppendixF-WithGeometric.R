# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# Appendix F : Pricing Asian option using CV with European options
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())
library(matrixStats)

T=2#5
n=5#10#5
dt=T/n
t=seq(0,T,dt)

S0=12#100
K=11#100
r=0.01#0#0.02
sigma=0.2#0.15#0.05#0.2

Type="Geometric" #"Geometric", "Arithmetic"

BS=function(r,S0,K,vol,T){
  d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
  d2=d1-vol*sqrt(T)
  return(S0*pnorm(d1)-K*exp(-r*T)*pnorm(d2))
}

BS(r,S0,K,sigma,T)

n.seq=seq(1000,50000,1000)
n.M=length(n.seq)
N=3 # Nb of samples to compute the variance of the estimators

Payoff.mat=matrix(0,nrow=n.M,ncol=N)
Payoff.CV.mat=matrix(0,nrow=n.M,ncol=N)
Payoff.CV.alpha.mat=matrix(0,nrow=n.M,ncol=N)

for(j in 1:n.M){
  
  M=n.seq[j] # nb of MC simulations
  
  for(k in 1:N){

    S=matrix(S0,nrow=M,ncol=n+1)
    Z=matrix(rnorm(M*n),nrow=M,ncol=n)

    for(i in 1:n){
      S[,i+1]=S[,i]*exp((r-sigma^2/2)*dt+sigma*sqrt(dt)*Z[,i])
    }
    if(Type=="Arithmetic"){
      A=rowSums(S[,2:(n+1)])/n
    }else{
      A=(rowProds(S[,2:(n+1)]))^(1/n)
    }
    Payoff=((A-K)+abs(A-K))/2*exp(-r*T)
    P = mean(Payoff)
    #print(P)
    Payoff.MC=matrix(S0,nrow=M,ncol=n)
    Payoff.TH=rep(0,n)
    for(i in 1:n){
      Payoff.MC[,i]=((S[,i+1]-K)+abs(S[,i+1]-K))/2*exp(-r*i*dt)
      Payoff.TH[i]=BS(r,S0,K,sigma,i*dt)
    }
    Payoff.BS.MC=rowSums(Payoff.MC)/n
    alpha=cov(Payoff,Payoff.BS.MC)/var(Payoff.BS.MC)
    Payoff.CV=mean(Payoff-Payoff.BS.MC)+sum(Payoff.TH)/n
    Payoff.CV.alpha=mean(Payoff)-alpha*(mean(Payoff.BS.MC)-sum(Payoff.TH)/n)
    #print(Payoff.CV)
    Payoff.mat[j,k]=P
    Payoff.CV.mat[j,k]=Payoff.CV
    Payoff.CV.alpha.mat[j,k]=Payoff.CV.alpha
  }
}

x.mn=rep(0,n.M)
y.mn=x.mn
z.mn=x.mn
x.sd=x.mn
y.sd=x.mn
z.sd=x.mn
for(n in 1:n.M){
  x.mn[n]=mean(Payoff.mat[n,])
  x.sd[n]=sd(Payoff.mat[n,])
  y.mn[n]=mean(Payoff.CV.mat[n,])
  y.sd[n]=sd(Payoff.CV.mat[n,])
  z.mn[n]=mean(Payoff.CV.alpha.mat[n,])
  z.sd[n]=sd(Payoff.CV.alpha.mat[n,])
}
yl=c(min(x.mn-x.sd,y.mn-y.sd),max(x.mn+x.sd,y.mn+y.sd))

plot(n.seq,x.mn,xlab="n",type="l",ylab="",col="blue",ylim=yl)
points(n.seq,x.mn-x.sd,type="l",col="blue",lty=2)
points(n.seq,x.mn+x.sd,type="l",col="blue",lty=2)
points(n.seq,y.mn,type="l",col="red")
points(n.seq,y.mn+y.sd,type="l",col="red",lty=2)
points(n.seq,y.mn-y.sd,type="l",col="red",lty=2)
points(n.seq,z.mn,type="l",col="red")
points(n.seq,z.mn+z.sd,type="l",col="green",lty=2)
points(n.seq,z.mn-z.sd,type="l",col="green",lty=2)
# it is decreasing with n because the volatility of the average decreases with n...
legend(round(M/4), x.mn[1]+x.sd[1], legend=c("Plain MC","Conditional MC (alpha=1)","Conditional MC (alpha=alpha*)"),
       col=c( "blue","red", "green"), lty=rep(2,3), cex=0.8)
print(z.mn[n.M])