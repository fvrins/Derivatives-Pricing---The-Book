
type="Bin"# "Bin"# "Geo"# "Ber"# "de"# "maxdeuxdes"# "sumdeuxdes"#
if(type=="de"){
	x=c(1,2,3,4,5,6)
	p=rep(1,6)/6

	mx=min(x)
	Mx=max(x)
	Mp=max(p)+0.2
}else if(type=="maxdeuxdes"){
	x=c(1,2,3,4,5,6)
	p=c(1,3,5,7,9,11)/36
	mx=min(x)
	Mx=max(x)
	Mp=max(p)
}else if(type=="sumdeuxdes"){
	x=c(2,3,4,5,6,7,8,9,10,11,12)
	p=c(1,2,3,4,5,6,5,4,3,2,1)/36
	mx=min(x)
	Mx=max(x)
	Mp=max(p)
}else if(type=="Ber"){
	pb=0.25
	x=c(0,1)
	p=c(1-pb,pb)
	mx=min(x)
	Mx=max(x)
	Mp=1
}else if(type=="Bin"){
	pb=0.5
	n=20
	x=seq(0,n)
	p=dbinom(x,n,pb)
	mx=min(x)
	Mx=max(x)
	Mp=0.25
}else if(type=="Geo"){
	pb=1/6
	x=seq(1,30)
	p=dgeom(x-1,pb)
	mx=min(x)
	Mx=max(x)
	Mp=max(p)
}else if(type=="Poi"){
	lambda=5
	x=seq(0,20)
	p=dpois(x,lambda)
	mx=min(x)
	Mx=max(x)
	Mp=max(p)+0.05
}
F=cumsum(p)

nx=length(x)

x.grid=c(0,x,max(x)+1)
y.grid.p=c(0,p)
y.grid.F=c(0,1.1)

dev.new()
plot(x, p, type="p", pch=19, col = "blue", xlab="x", ylab = "p(x)",xlim=c(mx-1,Mx+1),ylim=c(0,Mp)) 
grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted",
     lwd = par("lwd"), equilogs = TRUE)
#points(x, p, type="p", pch=0, col = "red",cex=1.5) 


dev.new()
plot(x, F, type="p", pch=19, col = "blue", xlab="x", ylab = "F(x)",xlim=c(mx-1,Mx+1),ylim=c(0,1.1)) 
points(c(mx-1,mx-0.5),rep(0,2),type="l",col="blue",lwd=2,lty=3)
points(c(mx-0.5,x[1]),rep(0,2),type="l",col="blue",lwd=2)
for(i in 1:(nx-1)){
	points(c(x[i],x[i+1]),rep(F[i],2),type="l",col="blue",lwd=2)
}
points(c(Mx,Mx+0.5),rep(1,2),type="l",col="blue",lwd=2)
points(c(Mx+0.5,Mx+1),rep(1,2),type="l",col="blue",lwd=2,lty=3)
grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted",
     lwd = par("lwd"), equilogs = TRUE)
