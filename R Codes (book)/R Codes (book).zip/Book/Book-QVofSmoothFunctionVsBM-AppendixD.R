# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# Appendix D
# This function comptues the QV of a (smooth) function f and of a trajectory of a Brownian motion W up to a given fixed time T.
# It shows that QV.f.T(n), the quadratic variation of f at time T estimated from a time grid with n points partitionning [0,T], tends to 0 as n->infinity. Because <f>_T is precisely defined as the limit of QV.f.T(n) as n->infinity, this shows that <f>_T=0. It is done here for T=3 but it works for all T>0. 
# By contrast, doing the same for a trajectory W (instead of a smooth function) does not yields 0 but T, showing that <W>_T=T.
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())


T=3                 # this is the time at which you want to compute <f>_T and <W>_T
n.vec=seq(1,2000)*T # vector of the number n of points in the time grid partitionning [0,T]
delta.vec=T/n.vec   # corresponding vector of time-steps
N=length(n.vec)
n.max=max(n.vec)

QV.f.T=rep(0,N) # vector of the estimated QV for the n given in n.vec. The "true" QV can be obtained by looking at the limit as n->infty
QV.W.T=rep(0,N) # same for W

f=function(t){ # this is the chosen "smooth" f function in our example
  sin(t)*exp(t)
}
W=c(0,sqrt(T/n.max)*cumsum(rnorm(n.max)))  #this is the path of a Brownian motion simulated with a very small time step.

W.t=function(idx){ # this function returns the value of W at the times corresponding to a given time grid
  W[idx]
}

for(i in 1:N){
  # for each partition, i.e., for each time grid (made of n.vec[i] points)
  ti=seq(0,T,delta.vec[i])
  increments.f=diff(f(ti))      # we compute the increments of f over the considered time grid
  QV.f.T[i]=sum(increments.f^2) # we compute the sum of the square of these increments
  
  idx=ti*n.max/T+1
  increments.W=diff(W.t(idx))   # we compute the increments of W over the considered time grid
  QV.W.T[i]=sum(increments.W^2) # we compute the sum of the square of these increments
}

# We see that QV.f.T converges to 0 as n is increasing, showing that the limit (which is <f>_T) is 0. 
# Similarly, QV.W.T converges to T as n is increasing, showing that the limit (which is <W>_T) is T. 

par(mfrow=c(1,2))
t.vec=seq(0,T,delta.vec[N])
yM=max(f(t.vec),W)
ym=min(f(t.vec),W)
plot(t.vec,f(t.vec),type="l",col="red",ylim=c(ym,yM),xlab="t",ylab="f and W",main=expression(paste("Function f(t) and BM ",W[t])))
points(t.vec,W,type="l",col="green")
plot(n.vec,QV.W.T,type="l",col="green",ylim=c(0,1.5*T),xlab="number n of points in the partition of [0,3]", ylab="Estimated QV (true= limit as n is infinity)", main="QV of f (red) vs W (green) at T=3")
points(n.vec,QV.f.T,type="l",col="red")
points(c(0,n.max),rep(0,2),type="l",lty=2,col="red")
points(c(0,n.max),rep(T,2),type="l",lty=2,col="green")