
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 3.2 - Sampling from a Bernoulli distribution
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# Parameters
display.title=TRUE #TRUE of FALSE
pi=0.25
mu.X=pi               # expectation of a Ber(pi)
sd.X=sqrt(pi*(1-pi))  # standard deviation of a Ber(pi)

ns=c(1,5,10,50) # vector or n 
l.ns=length(ns)

par(mfrow=c(2,2))
col1="blue"
col2="red"
plot.what="cdf" # pdf or cdf
dist.what="sum" #sum or mean

for(n in 1:l.ns){


	# -----------------------------
	# Exact distribution (binomial)
	# ------------------------------
	
	p=rep(0,ns[n]+1)
	for(i in 1:(ns[n]+1)){
	  p[i]=dbinom(i-1,ns[n],pi)
	}

	# ----------------------------
	# Approximation (CLT)
	# ----------------------------

	mu = ns[n]*mu.X
	sd = sqrt(ns[n])*sd.X

	# ----------------------------
	# Plot
	# ----------------------------

	y=seq(0,ns[n],1)

	if(dist.what=="mean"){
		y=y-mu
		y=y/sd
		mu=0
		sd=1
	}

	xM=mu+4*sd
	xm=mu-4*sd
	dx=(xM-xm)/100
	x=seq(xm,xM,dx)
	z=c(xm,y,xM)
	nz=length(z)-1

	if(display.title){
	  if(plot.what=="pdf"){
	    thresh=max(dnorm(x,mu,sd)/50)
	    plot(x,dnorm(x,mu,sd),type="l",col=col1,ylab="probability",main=bquote(.(dist.what)~"of "~.(ns[n])~"Ber("~.(pi)~")"),lwd=2)
	    points(y,p,type="p",col=col2,pch=19,cex=0.6)
	    
	    points(c(xm,xM),rep(0,2),type="l",col=col2,lwd=2)
	    points(y,rep(0,length(y)),type="p",col="white",pch=19,cex=0.4)
	    for(i in 1:length(p)){
	      points(rep(y[i],2),c(thresh,max(thresh,p[i])),type="l",lty=3,col="black")
	    }
	    #points(c(xm,xM),rep(0,2),type="l",lty=2,col="black")
	  }else{
	    q=c(0,cumsum(p))
	    y=c(0,y)
	    plot(x,pnorm(x,mu,sd),type="l",col=col1,ylab="probability",main=bquote(.(dist.what)~"of "~.(ns[n])~"Ber("~.(pi)~")"),lwd=2)
	    points(c(xm,xM),rep(1,2),type="l",lty=2,col="black")
	    for(i in 1:nz){
	      points(y[i+1],q[i+1],type="p",pch=19,col=col2,cex=0.5)
	      points(z[i:(i+1)],rep(q[i],2),type="l",lwd=2,col=col2)
	      points(rep(y[i+1],2),c(q[i],q[i+1]),type="l",lty=2,col=col2)
	    }
	  }
	}else{
	if(plot.what=="pdf"){
		thresh=max(dnorm(x,mu,sd)/50)
		plot(x,dnorm(x,mu,sd),type="l",col=col1,main=paste("m =",ns[n]),ylab="probability",lwd=2)
		points(y,p,type="p",col=col2,pch=19,cex=0.6)
		
		points(c(xm,xM),rep(0,2),type="l",col=col2,lwd=2)
		points(y,rep(0,length(y)),type="p",col="white",pch=19,cex=0.4)
		for(i in 1:length(p)){
			points(rep(y[i],2),c(thresh,max(thresh,p[i])),type="l",lty=3,col="black")
		}
		#points(c(xm,xM),rep(0,2),type="l",lty=2,col="black")
	}else{
		q=c(0,cumsum(p))
		y=c(0,y)
		plot(x,pnorm(x,mu,sd),type="l",col=col1,main=paste("m =",ns[n]),ylab="probability",lwd=2)
		points(c(xm,xM),rep(1,2),type="l",lty=2,col="black")
		for(i in 1:nz){
			points(y[i+1],q[i+1],type="p",pch=19,col=col2,cex=0.5)
			points(z[i:(i+1)],rep(q[i],2),type="l",lwd=2,col=col2)
			points(rep(y[i+1],2),c(q[i],q[i+1]),type="l",lty=2,col=col2)
		}
	}
	}
}
