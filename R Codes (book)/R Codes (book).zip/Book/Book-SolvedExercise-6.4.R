
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# EXERCISE 6.4 - Joint CDF of X=-ln(U) and Y =-ln(U)-ln(V) where U,V are iid U(0,1)
#                   We compare the proportion of (X,Y) below a given threshold (x,y) 
#                   and compare it to the CDF found  
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

M<-100000

U<-runif(M)
V<-runif(M)
X<-(- log(U))
Y<-(- log(U)-log(V))
x<-2
y<-5

freq<-length(which((X<=x) & (Y<=y)))/M

cdf=function(x,y){
  (1-exp(-x))-x*exp(-y)
}
print(paste("Proportion of points below (x,y):",freq))
print(paste("Probability to observe (X,Y) below (x,y):",cdf(x,y)))
