# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 10.1 - Sample paths of a scaled random walk W^{(n)}
#             - Extra figures also provide the evolution of the QV <W^{(n)}>_t wrt t
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

DotSize=1.2
AxisSize=1.3

T=1000
dt=1
t=seq(0,T,dt)
nt=length(t)
M=rep(0,nt)
M2=rep(0,nt)

for(i in 2:nt){
	if(runif(1)>0.5){x=1}else{x=-1}
	M[i]=M[i-1]+x
}

# FIGURE 10.2
dev.new()
par(mfrow=c(2,2))
n=c(5,50,250,1000)
for(j in 1:4){
	cj=n[j]
	idx=seq(1,cj+1,1)
	tj=t[idx]/cj
	Mj=M[idx]/sqrt(cj)
	#if(j<=2){
		plot(tj,Mj,type="p",pch=19,col="blue",xlim=c(0,1),ylim=c(min(Mj),max(Mj)),xlab="t",ylab=expression(W^(n)[t]),main=paste("n = ",cj),cex=0.75)
	#}else{
	#	plot(0,0,type="l",pch=19,col="blue",xlim=c(0,1),ylim=c(min(Mj),max(Mj)),xlab="t",ylab=expression(W^n[t]),main=paste("n = ",cj))
	#}
	points(tj,Mj,type="l",col="blue",lty=2)
	#for(i in 2:length(tj)){
	#	points(c(tj[i-1],tj[i]),rep(Mj[i-1],2),type="l",col="blue",lwd=2)
	#	points(c(tj[i],tj[i]),c(Mj[i-1],Mj[i]),type="l",col="blue",lwd=2)
	#}
}

# FIGURE 10.1
dev.new()
idx.max=11
t1=t[1:idx.max]
ym=min(M[1:idx.max])
yM=max(M[1:idx.max])
#plot(t1,M[1:idx.max],type="p",pch=19,col="blue",xlim=c(0,idx.max),ylim=c(ym,yM),xlab="t",ylab=expression(M[t]),main="Random walk",cex=0.75)
#plot(t1,M[1:idx.max],type="p",pch=19,col="blue",xlim=c(0,idx.max),ylim=c(ym,yM),xlab="t",ylab=expression(paste(M[t]," , ",M[nt])),main="Random walk (speed up x2)",cex=0.75)
#plot(t1,M[1:idx.max],type="p",pch=19,col="blue",xlim=c(0,idx.max),ylim=c(ym,yM),xlab="t",ylab=expression(paste(M[t]," , ",M[nt]," , ",{W[t]}^(n))),main="Random walk (scaled n=2)",cex=DotSize,cex.lab=AxisSize,cex.axis=AxisSize,mgp=c(2,1,0))
plot(t1,M[1:idx.max],type="p",pch=15,col="red",xlim=c(0,idx.max),ylim=c(ym,yM),xlab="t",ylab=expression(paste(M[t]," , ",M[nt]," , ",{W[t]}^(n))),main="",cex=DotSize,cex.lab=AxisSize,cex.axis=AxisSize,mgp=c(2,1,0))
points(t1,M[1:idx.max],type="l",col="red",lty=2)
for(j in 1:idx.max){
	points(c(0,idx.max),rep(M[j],2),type="l",lty=3)
}
for(j in 1:idx.max){
	points(rep(j,2),c(ym,yM),type="l",lty=3)
}
t2=t1/2
W2=M[1:idx.max]
W3=W2
W3[2:length(W2)]=W2[2:length(W2)]/sqrt(2)
yw=min(W2)
yW=max(W2)
points(t2,W2,type="p",pch=17,col="magenta",lwd=2)#,xlim=c(0,idx.max),ylim=c(ym,yM),xlab="t",ylab=expression(W^2[t]),main="scaled random walk",cex=0.75)
points(t2,W2,type="l",col="magenta",lty=2)

points(t2,W3,type="p",pch=19,col="blue",lwd=2)#,xlim=c(0,idx.max),ylim=c(ym,yM),xlab="t",ylab=expression(W^2[t]),main="scaled random walk",cex=0.75)
points(t2,W3,type="l",col="blue",lty=2)

# Paths for various n on different figures (linear interpolation)
dev.new()
par(mfrow=c(2,2))
n=c(5,50,250,1000)
for(j in 1:4){
  dev.new()
	cj=n[j]
	idx=seq(1,cj+1,1)
	tj=t[idx]/cj
	Mj=M[idx]/sqrt(cj)
	if(j<=2){
		#plot(tj,Mj,type="p",pch=19,col="blue",xlim=c(0,1),ylim=c(min(Mj),max(Mj)),xlab="t",ylab=expression(W^n [t]),main=paste("n = ",cj),cex=0.75)
	  plot(tj,Mj,type="p",pch=19,col="blue",xlim=c(0,1),ylim=c(min(Mj),max(Mj)),xlab="t",ylab=expression({W[t]}^(n)),main="",cex=DotSize,cex.lab=AxisSize,cex.axis=AxisSize,mgp=c(2,1,0))
	}else{
		#plot(0,0,type="l",pch=19,col="blue",xlim=c(0,1),ylim=c(min(Mj),max(Mj)),xlab="t",ylab=expression(W^n [t]),main=paste("n = ",cj))
	  plot(0,0,type="l",pch=19,col="blue",xlim=c(0,1),ylim=c(min(Mj),max(Mj)),xlab="t",ylab=expression({W[t]}^(n)),main="",cex=DotSize,cex.lab=AxisSize,cex.axis=AxisSize,mgp=c(2,1,0))
	}
	points(tj,Mj,type="l",col="blue",lty=2)
	#for(i in 2:length(tj)){
	#	points(c(tj[i-1],tj[i]),rep(Mj[i-1],2),type="l",col="blue",lwd=2)
	#	points(c(tj[i],tj[i]),c(Mj[i-1],Mj[i]),type="l",col="blue",lwd=2)
	#}
}

# Paths for various n on different figures (piecewise constant interpolation)
dev.new()
par(mfrow=c(2,2))
n=c(5,50,250,1000)
for(j in 1:4){
	cj=n[j]
	idx=seq(1,cj+1,1)
	tj=t[idx]/cj
	Mj=M[idx]/sqrt(cj)
	if(j<=2){
		plot(tj,Mj,type="p",pch=19,col="blue",xlim=c(0,1),ylim=c(min(Mj),max(Mj)),xlab="t",ylab=expression(W^n[t]),main=paste("n = ",cj),cex=0.75)
	}else{
		plot(0,0,type="l",pch=19,col="blue",xlim=c(0,1),ylim=c(min(Mj),max(Mj)),xlab="t",ylab=expression(W^n[t]),main=paste("n = ",cj))
	}
	for(i in 2:length(tj)){
		points(c(tj[i-1],tj[i]),rep(Mj[i-1],2),type="l",col="blue",lwd=2)
		points(c(tj[i],tj[i]),c(Mj[i-1],Mj[i]),type="l",col="blue",lwd=2)
	}
}

# Quadratic variation for different n
par(mfrow=c(2,2))
n=c(5,50,250,1000)
for(j in 1:4){
	cj=n[j]
	idx=seq(1,cj+1,1)
	tj=t[idx]/cj
	Mj=M[idx]/sqrt(cj)
	dMj=diff(Mj)
	dMj2=c(0,cumsum(dMj^2))
	#if(j<=2){
		plot(tj,dMj2,type="p",pch=19,col="blue",xlim=c(0,1),ylim=c(0,tj[cj+1]),xlab="t",ylab=expression(W^n[t]),main=paste("n = ",cj),cex=0.75)
	#}else{
	#	plot(0,0,type="l",pch=19,col="blue",xlim=c(0,1),ylim=c(0,tj[cj+1]),xlab="t",ylab=expression(W^n[t]),main=paste("n = ",cj))
	#}
	points(tj,dMj2,type="l",col="blue",lty=2)
	#for(i in 2:length(tj)){
	#	points(c(tj[i-1],tj[i]),rep(Mj[i-1],2),type="l",col="blue",lwd=2)
	#	points(c(tj[i],tj[i]),c(Mj[i-1],Mj[i]),type="l",col="blue",lwd=2)
	#}
}

# illustration of linear interpolation of the paths of a RW
dev.new()
plot(0,0,type="l",pch=19,col="blue",xlim=c(0,T),ylim=c(min(M),max(M)),xlab="t",ylab=expression(W^n[t]),main=paste("n = 1"))
	for(i in 2:nt){
		points(c(t[i-1],t[i]),rep(M[i-1],2),type="l",col="blue",lwd=2)
		points(c(t[i],t[i]),c(M[i-1],M[i]),type="l",col="blue",lwd=2)
	}

dev.new()
par(mfrow=c(2,2))
Y1=c(1,1,-1,1,1,1,-1,-1)
M1=c(0,cumsum(Y1))
Y2=c(-1,-1,-1,1,-1,1,1,-1)
M2=c(0,cumsum(Y2))
plot(1:8,Y1,type="p",pch=19,col="blue",ylim=c(-1,1),xlab="i",ylab=expression(Y[i](omega)))
points(1:8,Y1,type="l",lty=1,col="blue",lwd=1)
plot(0:8,M1,type="p",pch=19,col="blue",ylim=c(min(M1),max(M1)),xlab=expression(t),ylab=expression(M[t](omega)),xaxt="n",yaxt="n")
points(0:8,M1,type="l",lty=1,col="blue",lwd=1)
points(rep(3.27,2),c(0,1.27),type="l",lty=3)
points(c(0,3.27),rep(1.27,2),type="l",lty=3)
axis(1,at=c(0,1,2,3,3.27,4,5,6,7,8),labels=c("0","1","2","","","4","5","6","7","8"))
mtext("3.27", side=1,at=3.27,padj=1.5)
axis(2,at=c(0,1,1.27,2,3,4),labels=c("0","","","2","3","4"))
mtext("1.27", side=2,at=1.27,padj=-1.5)

plot(1:8,Y2,type="p",pch=19,col="blue",ylim=c(-1,1),xlab="i",ylab=expression(Y[i](omega)))
points(1:8,Y2,type="l",lty=1,col="blue",lwd=1)
plot(0:8,M2,type="p",pch=19,col="blue",ylim=c(min(M2),max(M2)),xlab=expression(t),ylab=expression(M[t](omega)),xaxt="n",yaxt="n")
points(0:8,M2,type="l",lty=1,col="blue",lwd=1)
#points(7.54,-1.54,type="p",pch=1,col="red",cex=1.5)
points(rep(7.54,2),c(0,-1.54),type="l",lty=3)
points(c(0,7.54),rep(-1.54,2),type="l",lty=3)
axis(1,at=c(0,1,2,3,4,5,6,7,7.54,8),labels=c("0","1","2","3","4","5","6","","",""))
mtext("7.54", side=1,at=7.54,padj=1.5)
axis(2,at=c(0,-1,-1.54,-2,-3),labels=c("0","-1","","-2","-3"))
mtext("-1.54", side=2,at=-1.54,padj=-1.5)
