# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 10.3-4 -  Sample paths of (geometric) Brownian motion
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())
T=5
n=250
delta=T/n
t=seq(0,n)*delta

M=4
s0=35
mu=c(0,-0.5,0,0.1)
sigma=c(0.1,0.2,0.3,0.5)

N=4
col.v=c("blue","red","magenta","cyan")

# FIGURE 10.3
Z=matrix(rnorm(N*n),nrow=N,ncol=n)
W=matrix(0,nrow=N,ncol=n+1)

for(i in 1:n){
  W[,i+1]=W[,i]+sqrt(delta)*Z[,i]
}

mW=min(W)
MW=max(W)

dev.new()
plot(t,W[1,],type="l",col=col.v[1], ylim=c(mW,MW), xlab= "t", ylab=expression(W[t]), lwd=2, cex.axis=1, cex.lab=1.5,mgp=c(2,1,0))
for(i in 2:N){
  points(t,W[i,],type="l",col=col.v[i], lwd=2)  
}
points(t,0*t,type="l",lty=2)

# FIGURE 10.4
for(j in 1:M){

  f=function(j,w){
    return(s0*exp((mu[j]-sigma[j]^2/2)*t+sigma[j]*w))
  }
  mS=min(f(j,W[1,]),f(j,W[2,]),f(j,W[3,]),f(j,W[4,]))
  MS=max(f(j,W[1,]),f(j,W[2,]),f(j,W[3,]),f(j,W[4,]))
  
  dev.new()
  plot(t,f(j,W[1,]),type="l",col=col.v[1], ylim=c(mS,MS), xlab= "t", ylab=expression(S[t]), cex.axis=1, cex.lab=1.5, lwd=2,mgp=c(2,1,0))
  for(i in 2:N){
    points(t,f(j,W[i,]),type="l",col=col.v[i], lwd=2)  
  }
  points(t,s0*exp(mu[j]*t),type="l",lty=2)
}
