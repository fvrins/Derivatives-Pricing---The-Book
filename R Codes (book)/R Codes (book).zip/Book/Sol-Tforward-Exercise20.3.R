
# GBM parameters(mu does not matter as we are under P*)
S0=18
sigma=0.2

# Option parameters
K=18
T=1

# Monte Carlo parameters
dt=0.005
t=seq(0,T,dt)
nt=length(t)
n.paths=500000

# Interest rates parameters
rate.mode="stochastic" #"stochastic" or "deterministic"
r0=0.04 # value of r if "deterministc", Initial value of r if "stochastic"

if(rate.mode=="stochastic"){
	kappa=0.1     # speed of mean reversion
	theta=0.03    # long-term mean
	eta=0.02    # volatility
	
	# A,B functions in the Ornstein-Uhlenbeck modeland ZCB prices
	IRparam=c(r0,theta,kappa,eta)
	B=function(t,T,IRparam){
		kappa=IRparam[3]
		return(1/kappa*(1-exp(-kappa*(T-t))))
	}
	A=function(t,T,IRparam){
		r0=IRparam[1]; theta=IRparam[2]; kappa=IRparam[3]; eta=IRparam[4]
		return(exp((theta-(eta^2)/(2*kappa^2))*(B(t,T,IRparam)+t-T)-(eta^2)/(4*kappa)*B(t,T,IRparam)*B(t,T,IRparam)))
	}
	P=function(T,IRparam){
		return(A(0,T,IRparam)*exp(-B(0,T,IRparam)*IRparam[1]))
	}
	F0=S0/P(T,IRparam)
	r=matrix(r0,ncol=nt,nrow=n.paths) # sample paths for r
}else{
	eta=0
	F0=S0/exp(-r0*T)
}

# Call price in the standard Black-Scholes-Merton model with fixed rate r
BS=function(r,S0,K,vol,T){
	d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
	d2=d1-vol*sqrt(T)
	return(S0*pnorm(d1)-K*exp(-r*T)*pnorm(d2))
}

# vector of correlation values between the BM driving S (W) and that driving r (W.r)
rho=seq(-1,1,0.2)   
n.rho=length(rho)

# sampe paths for two independent Brownian motions
dW=sqrt(dt)*matrix(rnorm((nt-1)*n.paths),ncol=(nt-1),nrow=n.paths)
dW.perp=sqrt(dt)*matrix(rnorm((nt-1)*n.paths),ncol=(nt-1),nrow=n.paths)

S=matrix(S0,ncol=nt,nrow=n.paths) # sample paths for S_t
D=matrix(1,ncol=nt,nrow=n.paths)  # sample paths for 1/beta_t=exp{\int_0^t r_s ds}

Price.Th=rep(0,n.rho)     # Analytical BSM price using the T-forward measure approach
Price.BS=rep(0,n.rho)     # Analytical BSM price assuming that r=r0
Price.MC=rep(0,n.rho)     # Monte Carlo estimate using either Euler or exact scheme for the short-rate process

for(i in 1:n.rho){
	dW.r=rho[i]*dW+sqrt(1-rho[i]^2)*dW.perp
	int.fun=function(t){sigma^2+2*rho[i]*sigma*eta*B(t,T,IRparam)+eta^2*B(t,T,IRparam)^2}
	vol.fun=1/sqrt(T)*sqrt(integrate(int.fun,0,T)$value)
	for(j in 2:nt){
		if(rate.mode=="stochastic"){
		  # exact scheme for r
			r[,j]=r[,j-1]*exp(-kappa*dt)+theta*(1-exp(-kappa*dt))+eta/sqrt(2*kappa)*sqrt(1-exp(-2*kappa*dt))/sqrt(dt)*dW.r[,j-1]
			# Euler scheme for r: 
			#r[,j]=r[,j-1]+kappa*(theta-r[,j-1])*dt+eta*dW.r[,j-1]
			D[,j]=D[,j-1]*exp(-r[,j-1]*dt)
			S[,j]=S[,j-1]*exp((r[,j-1]-sigma^2/2)*dt+sigma*dW[,j-1])  # exact scheme for S
		}else{
			D[,j]=D[,j-1]*exp(-r0*dt)
			S[,j]=S[,j-1]*exp((r0-sigma^2/2)*dt+sigma*dW[,j-1])
		}
	}
	Payoff=((S[,nt]-K)+abs(S[,nt]-K))/2
	Price.MC[i]=mean(Payoff*D[,nt])
	
	if(rate.mode=="stochastic"){
		#P.emp=mean(D[,nt])
		Price.Th[i]=BS(0,F0,K,vol.fun,T)*P(T,IRparam)                   
		Price.BS[i]=BS(r0,S0,K,sigma,T)                                 

	}else{
		Price.Th[i]=BS(0,F0,K,vol.fun,T)*exp(-r0*T)
		Price.BS[i]=BS(r0,S0,K,sigma,T)
	}
}

par(mfrow=c(2,2))
col.v=c("blue","red","green","cyan")
n.plot=4
yl=c(min(S[1:n.plot,]),max(S[1:n.plot,]))

plot(t,S[1,],type="l",col=col.v[1],ylim=yl,ylab=expression(S[t](omega)),main="Stock sample paths")
for(i in 2:n.plot){
	points(t,S[i,],type="l",col=col.v[i])
}
if(rate.mode=="stochastic"){
	yl=c(min(r[1:n.plot,]),max(r[1:n.plot,]))
	plot(t,r[1,],type="l",ylim=yl,col=col.v[1],ylab=expression(r[t](omega)),main="Short-rate sample paths")
	for(i in 2:n.plot){
		points(t,r[i,],type="l",col=col.v[i])
	}
}else{
	plot(t,rep(r0,nt),type="l",col=col.v[1],ylab=expression(D[t](omega)),main="Short-rate sample paths")
}

yl=c(min(D[1:n.plot,]),max(D[1:n.plot,]))

plot(t,D[1,],type="l",ylim=yl,col="blue",ylab=expression(D[t](omega)),main="Discount factor sample paths")
for(i in 2:n.plot){
	points(t,D[i,],type="l",col=col.v[i])
}
points(t,P(t,IRparam),type="l",col="black",lty=2)

yl=c(min(Price.Th,Price.BS,Price.MC),max(Price.Th,Price.BS,Price.MC))
plot(rho,Price.Th,ylim=yl,type="l",xlab=expression(rho),ylab="Price",col="blue",main="Impact of correlation on option price")
points(rho,Price.MC,type="p",col="magenta",lty=2)
points(rep(0,2),yl,type="l",lty=3)

