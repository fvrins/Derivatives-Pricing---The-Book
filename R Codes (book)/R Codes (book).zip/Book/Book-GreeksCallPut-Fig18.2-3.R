# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 18.2 - Greeks call/put
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# ----------------------------------------------------------------------------
# INUPTS
# ----------------------------------------------------------------------------

T  	  = 5			# maturity
r  	  = 2/100		# risk-free rate
#alpha	= 3*r			# alpha (drift of stock)
K 	  = 38			# strike
sigma = 0.2			# volatility

# ----------------------------------------------------------------------------
# FUNCTIONS
# ----------------------------------------------------------------------------

d = function(tau,x,pm){
	if(pm=="p"){
		y = (r+sigma^2/2)
	}else{
		y = (r-sigma^2/2)
	}
	return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
}
Delta = function(tau,x,option){
	# This is the delta of the option: V_x(t,x)
  if(option=="call"){
	  return( pnorm(d(tau,x,"p")) )
  }else{
    return( pnorm(d(tau,x,"p"))-1 )     # put
  }
}
Gamma = function(tau,x,option){
	# This is the gamma of the option: V_xx(t,x) (same for Call andPut)
  return( dnorm(d(tau,x,"p"))/(sigma*x*sqrt(tau)) )
}
Theta = function(tau,x,option){
	# This is the theta of the option: V_t(t,x)
  if(option=="call"){
    return( -r*K*exp(-r*tau)*pnorm(d(tau,x,"m"))-dnorm(d(tau,x,"p"))*sigma*x/(2*sqrt(tau)) )
  }else{
    return( +r*K*exp(-r*tau)*pnorm(-d(tau,x,"m"))-dnorm(d(tau,x,"p"))*sigma*x/(2*sqrt(tau)) )     # put
  }  
}
Call = function(tau,x){
	# This is the price of the option: V(t,x)
	# If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
	return( x*pnorm(d(tau,x,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,"m")) )
}
Put = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( K*exp(-r*tau)*pnorm(-d(tau,x,"m"))-x*pnorm(-d(tau,x,"p")) )
}

# ----------------------------------------------------------------------------
# Plot fun
# ----------------------------------------------------------------------------

x=seq(K/4,2*K,0.1)
nx=length(x)
xP=seq(K/4,2*K,1)
SK.call=((xP-K)+abs(xP-K))/2	# max(0,S_t-K) = option exercise price of call
SK.put=((K-xP)+abs(K-xP))/2	# max(0,S_t-K) = option exercise price of put

t=seq(0,T,round(T/10,2))
nt=length(t)
col.v=c("blue","cyan","green","yellow","pink","magenta","purple","orange","red","brown","black")

# Call v(t,x)
# -----------------------------------------------------------
dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
plot(xP,SK.call,type="p",xlab="x",ylab="v(t,x)",main="", cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
for(j in 1:nt){			
	points(x,Call(T-t[j],x),type="l",col=col.v[j],lwd=2)
}

# Put v(t,x)
# -----------------------------------------------------------
dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
plot(xP,SK.put,type="p",xlab="x",ylab="v(t,x)",main="", cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
for(j in 1:nt){			
  points(x,Put(T-t[j],x),type="l",col=col.v[j],lwd=2)
}

# Verification BSM for Call
# -----------------------------------------------------------
#dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
#par(mfrow=c(1,2))
#t.id=6
#t.plot=t[t.id]
#y=c(Call(t.plot,x),Delta(t.plot,x,"call"),Gamma(t.plot,x,"call"),Theta(t.plot,x,"call"))
#yL=c(min(y),max(y))
#plot(x,Call(t.plot,x),type="l",lwd=2,col=col.v[t.id],xlab="x",ylab="y",main=paste("Greeks of Call wrt x for t = ", t[t.id]),ylim=yL, cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
#points(x,Delta(t.plot,x,"call"),type="l",lty=2,col="red",lwd=2)
#points(x,Gamma(t.plot,x,"call"),type="l",lty=2,col="blue",lwd=2)
#points(x,Theta(t.plot,x,"call"),type="l",lty=2,col="green",lwd=2)

#plot(xP,Call(t.plot,xP),type="l",lwd=2,col=col.v[t.id],xlab="x",ylab="f(t,x)", main="Verification of BSM (call)", cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
#points(xP,(Theta(t.plot,xP,"call")+sigma^2*xP^2/2*Gamma(t.plot,xP,"call")+r*xP*Delta(t.plot,xP,"call"))/r,type="p",col="black")
#points(xP,SK.call,type="l",lty=2)

# Verification BSM for Put
# -----------------------------------------------------------
#dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
#par(mfrow=c(1,2))
#t.id=6
#t.plot=t[t.id]
#y=c(Call(t.plot,x),Delta(t.plot,x,"put"),Gamma(t.plot,x,"put"),Theta(t.plot,x,"put"))
#yL=c(min(y),max(y))
#plot(x,Call(t.plot,x),type="l",lwd=2,col=col.v[t.id],xlab="x",ylab="y",main=paste("Greeks of Put wrt x for t = ", t[t.id]),ylim=yL, cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
#points(x,Delta(t.plot,x,"put"),type="l",lty=2,col="red",lwd=2)
#points(x,Gamma(t.plot,x,"put"),type="l",lty=2,col="blue",lwd=2)
#points(x,Theta(t.plot,x,"put"),type="l",lty=2,col="green",lwd=2)
#
#plot(xP,Put(t.plot,xP),type="l",lwd=2,col=col.v[t.id],xlab="x",ylab="f(t,x)", main="Verification of BSM (put)", cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
#points(xP,(Theta(t.plot,xP,"put")+sigma^2*xP^2/2*Gamma(t.plot,xP,"put")+r*xP*Delta(t.plot,xP,"put"))/r,type="p",col="black")
#points(xP,SK.put,type="l",lty=2)


# Plot greeks for call and puts
# -----------------------------------------------------------
dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
par(mfrow=c(2,3))

# call
#plot(x,rep(0,nx),col="white",type="p",xlab="x",ylab="Delta(t,x)",ylim=c(0,1), cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
plot(x,rep(0,nx),col="white",type="p",xaxt="n",yaxt="n",xlab="",ylab="",ylim=c(0,1))
axis(1,cex.axis=1)
mtext("x", side=1, line=2.5, cex=1)
axis(2,cex.axis=1)
mtext(expression(paste(Delta,"(t,x)")), side=2, line=2.2, cex=1)
for(j in 1:(nt-1)){			
  points(x,Delta(T-t[j],x,"call"),type="l",col=col.v[j],lwd=2)
}
points(x,rep(0,nx),type="l",lty=2)
points(x,rep(1,nx),type="l",lty=2)

#plot(x,rep(0,nx),col="white",type="p",xlab="x",ylab="Gamma(t,x)",ylim=c(0,2.5), cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
plot(x,rep(0,nx),col="white",type="p",xaxt="n",yaxt="n",xlab="",ylab="",ylim=c(0,0.1))
axis(1,cex.axis=1)
mtext("x", side=1, line=2.5, cex=1)
axis(2,cex.axis=1)
mtext(expression(paste(Gamma,"(t,x)")), side=2, line=2.2, cex=1)
for(j in 1:(nt-1)){			
  points(x,Gamma(T-t[j],x,"call"),type="l",col=col.v[j],lwd=2)
}
points(x,rep(0,nx),type="l",lty=2)

#plot(x,rep(0,nx),col="white",type="p",xlab="x",ylab="Theta(t,x)",ylim=c(-0.1,0), cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
plot(x,rep(0,nx),col="white",type="p",xaxt="n",yaxt="n",xlab="",ylab="",ylim=c(-2.5,1))
axis(1,cex.axis=1)
mtext("x", side=1, line=2.5, cex=1)
axis(2,cex.axis=1)
mtext(expression(paste(Theta,"(t,x)")), side=2, line=2.2, cex=1)
for(j in 1:(nt-1)){			
  points(x,Theta(T-t[j],x,"call"),type="l",col=col.v[j],lwd=2)
}
points(x,rep(0,nx),type="l",lty=2)

# put

#plot(x,rep(0,nx),col="white",type="p",xlab="x",ylab="Delta(t,x)",ylim=c(-1,0), cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
plot(x,rep(0,nx),col="white",type="p",xaxt="n",yaxt="n",xlab="",ylab="",ylim=c(-1,0))
axis(1,cex.axis=1)
mtext("x", side=1, line=2.5, cex=1)
axis(2,cex.axis=1)
mtext(expression(paste(Delta,"(t,x)")), side=2, line=2.2, cex=1)

for(j in 1:(nt-1)){			
  points(x,Delta(T-t[j],x,"put"),type="l",col=col.v[j],lwd=2)
}
points(x,rep(-1,nx),type="l",lty=2)
points(x,rep(0,nx),type="l",lty=2)

#plot(x,rep(0,nx),col="white",type="p",xlab="x",ylab="Gamma(t,x)",ylim=c(0,2.5), cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
plot(x,rep(0,nx),col="white",type="p",xaxt="n",yaxt="n",xlab="",ylab="",ylim=c(0,0.1))
axis(1,cex.axis=1)
mtext("x", side=1, line=2.5, cex=1)
axis(2,cex.axis=1)
mtext(expression(paste(Gamma,"(t,x)")), side=2, line=2.2, cex=1)
for(j in 1:(nt-1)){			
  points(x,Gamma(T-t[j],x,"put"),type="l",col=col.v[j],lwd=2)
}
points(x,rep(0,nx),type="l",lty=2)

#plot(x,rep(0,nx),col="white",type="p",xlab="x",ylab="Theta(t,x)",ylim=c(-0.07,0.03), cex.axis=1.5, cex.lab=1.5,cex.main=1.5)
plot(x,rep(0,nx),col="white",type="p",xaxt="n",yaxt="n",xlab="",ylab="",ylim=c(-2.5,1))
axis(1,cex.axis=1)
mtext("x", side=1, line=2.5, cex=1)
axis(2,cex.axis=1)
mtext(expression(paste(Theta,"(t,x)")), side=2, line=2.2, cex=1)
for(j in 1:(nt-1)){			
  points(x,Theta(T-t[j],x,"put"),type="l",col=col.v[j],lwd=2)
}
points(x,rep(0,nx),type="l",lty=2)