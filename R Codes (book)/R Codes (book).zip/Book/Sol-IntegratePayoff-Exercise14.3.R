
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# EXERCISE 14.3 -  Expectation using numerical integration
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

S0=12
sigma=0.2
K=11
r=0.05
T=2
security<-"call" #"call", "put" or "forward"

fwd=function(r,S0,K,T){
  S0-K*exp(-r*T)
}

BS.call=function(r,S0,K,vol,T){
  d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
  d2=d1-vol*sqrt(T)
  return(S0*pnorm(d1)-K*exp(-r*T)*pnorm(d2))
}

BS.put=function(r,S0,K,vol,T){
  d1=1/(vol*sqrt(T))*(log(S0/K)+(r+(vol^2)/2)*T)
  d2=d1-vol*sqrt(T)
  return(K*exp(-r*T)*pnorm(-d2)-S0*pnorm(-d1))
}

Payoff.fwd=function(x){
  S0*exp((r-sigma^2/2)*T+sigma*sqrt(T)*x)-K
}
if(security=="call"){
  price.exact<-BS.call(r,S0,K,sigma,T)
  g=function(x){(Payoff.fwd(x)+abs(Payoff.fwd(x)))/2*dnorm(x)}
}else if(security=="put"){
  price.exact<-BS.put(r,S0,K,sigma,T)
  g=function(x){(-Payoff.fwd(x)+abs(-Payoff.fwd(x)))/2*dnorm(x)}
}else{# forward
  price.exact<-fwd(r,S0,K,T)
  g=function(x){Payoff.fwd(x)*dnorm(x)}
}

print(c("price (exact): ",price.exact))
price.integrate<-integrate(g,K-100,K+100)$value*exp(-r*T)
print(c("price (numerical integration): ",price.integrate))

n.vec<-10^(seq(1,6))
ns<-length(n.vec)
price.RiemannSum<-rep(0,ns)
for(i in 1:ns){
  dx<-10/n.vec[i]
  x<-seq(-5,5,dx)
  nx<-length(x)
  price.RiemannSum[i]<-(sum(g(x[1:nx-1]))*dx)*exp(-r*T)
}

yL=(c(min(price.exact,price.RiemannSum),max(price.exact,price.RiemannSum))-price.exact)*1.2+price.exact
plot(log(n.vec,10),price.RiemannSum,type="p",col="red",xlab="n [Number of steps in Riemann sum]",ylab="Option price",ylim=yL)
points(log(n.vec,10),price.RiemannSum,type="l",col="red")
points(log(n.vec,10),rep(price.exact,ns),type="l",col="blue")
points(log(n.vec,10),rep(price.integrate,ns),type="p",col="blue",pch=15)
