
# Analytical expression of the MGF of X~N(mu,sigma^2)
phiZ<-function(u){exp(mu*u+(sigma*u)^2/2)}

n<-1000
mu<--1
sigma<-0.5
z<-qnorm(runif(n))
x<-mu+sigma*z
phiZ.hat<-mean(exp(x))
print(paste("theoretical: ", phiZ(1)))
print(paste("numerical (MC):", phiZ.hat))

# Check at points u other than 1
u<-seq(0,5,0.1)
nu<-length(u)
x<-rnorm(n,mu,sigma)
phiZ.hat<-rep(0,nu)
for(i in 1:nu){
  phiZ.hat[i]<-mean(exp(u[i]*x))
}

plot(u,phiZ(u),type="l",col="blue")
points(u,phiZ.hat,type="l",col="red",lty=2)

#repeat
M=100
n.vec=c(100,1000,100000)
N<-length(n.vec)
phiZ.hat<-matrix(0,ncol=M,nrow=N)
dev.new()
par(mfrow=c(1,3))
for(i in 1:N){
  n=n.vec[i]
  for(j in 1:M){
    phiZ.hat[i,j]<-mean(exp(mu+sigma*qnorm(runif(n))))
  }
  hist(phiZ.hat[i,])
}

phiZ.mn<-phiZ.sd<-rep(0,N)
  
for(i in 1:N){
  phiZ.mn[i]<-mean(phiZ.hat[i,])
  phiZ.sd[i]<-sd(phiZ.hat[i,])
}

plot(log(n.vec,10),rep(phiZ(1),N),type="l",col="blue")
points(log(n.vec,10),phiZ.mn,type="l",lty=2,col="red")
points(log(n.vec,10),phiZ.mn+phiZ.sd,type="l",lty=2,col="red")
points(log(n.vec,10),phiZ.mn-phiZ.sd,type="l",lty=2,col="red")
