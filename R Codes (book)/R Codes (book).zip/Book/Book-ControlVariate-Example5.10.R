
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# EXAMPLE 5.10 - Estimation of E[Phi(X)], X~a+bZ using MC with  plain MC or
#                                                               control variate
# FIGURE 5.5 a & b
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())
display.title=TRUE

# Parameters
a=1
b=4
mu.th=pnorm(a/sqrt(1+b^2))  # Analytical expression of E[Phi(X)]

# Monte Carlo
n.seq=seq(10,1000,10)       # n in {10,20,30,...,1000}
N=length(n.seq)
M=1000                      # Repeat M times each estimation featuring n samples

# Intialization of NxM matrices
mu.hat=matrix(0,ncol=M,nrow=N)
mu.tilde.alpha1=mu.hat
mu.tilde=mu.hat
alpha<-mu.hat

for(n in 1:N){
  for (m in 1:M){
    x=a+b*rnorm(n.seq[n])         # n samples from N(a,b^2) 
    v<-tanh(x)                    # n samples for V=tanh(X)
    mu.hat[n,m]=mean(v)           # mu.hat_n(V)
    w<-pnorm(x)                   # n samples for our control variate W=Phi(X)
    mu.tilde.alpha1[n,m]=mu.hat[n,m]-(mean(w)-mu.th)      #mu.tilde_n(V;1)
    alpha[n,m]<-cov(v,w)/var(w)                           #alpha.hat*
    mu.tilde[n,m]=mu.hat[n,m]-alpha[n,m]*(mean(w)-mu.th)  #mu.tilde_n(V;1)
  }
}
x.mn=rep(0,N)
y.mn=x.mn
z.mn=x.mn
x.sd=x.mn
y.sd=x.mn
z.sd=x.mn

# Compute mean and standard deviation of mu.hat_n(V), mu.tilde_n(V;1) and mu.tilde_n(V;alpha.hat*) for each n over the M estimations
for(n in 1:N){
  # mu.hat(V)
  x.mn[n]=mean(mu.hat[n,]) 
  x.sd[n]=sd(mu.hat[n,])
  # mu.tilde(V;1)
  y.mn[n]=mean(mu.tilde.alpha1[n,])
  y.sd[n]=sd(mu.tilde.alpha1[n,])
  # mu.tilde(V;alpha.hat*)
  z.mn[n]=mean(mu.tilde[n,])
  z.sd[n]=sd(mu.tilde[n,])
}
yl=c(min(x.mn-x.sd,y.mn-y.sd),max(x.mn+x.sd,y.mn+y.sd))

dev.new()
par(mfrow=c(1,2))
u=seq(-10,10,.01)
s=seq(-1,1,.01)
if(display.title){
  # Plot Fig. 5.5a
  plot(2*pnorm(u)-1,tanh(u),type="l",xlab=expression(2*Phi(x)-1),ylab=expression("tanh (x)"),col="black",lwd=2, cex.axis=1, cex.lab=1.5,mgp=c(2.6,0.8,0))
  points(s,s,type="l",col="black",lwd=1,lty=2)
  # Plot Fig. 5.5b
  plot(n.seq,x.mn,xlab="n",type="l",ylab="",col="blue",ylim=yl, cex.axis=1, cex.lab=1.5,mgp=c(2,1,0))
  points(n.seq,x.mn-x.sd,type="l",col="blue",lty=2)
  points(n.seq,x.mn+x.sd,type="l",col="blue",lty=2)
  points(n.seq,y.mn,type="l",col="red")
  points(n.seq,y.mn+y.sd,type="l",col="red",lty=2)
  points(n.seq,y.mn-y.sd,type="l",col="red",lty=2)
  points(n.seq,z.mn,type="l",col="green")
  points(n.seq,z.mn+z.sd,type="l",col="green",lty=2)
  points(n.seq,z.mn-z.sd,type="l",col="green",lty=2)
  legend(n.seq[round(N/4)], x.mn[1]+x.sd[1], legend=c("Plain MC","Conditional MC (alpha=1)","Conditional MC (alpha=alpha*)"),
         col=c( "blue","red", "green"), lty=rep(2,3), cex=0.8)
}else{
  # Plot Fig. 5.5a
  plot(2*pnorm(u)-1,tanh(u),type="l",xlab=expression(2*Phi(x)-1),ylab=expression("tanh (x)"),col="black",lwd=2, cex.axis=1, cex.lab=1.5,mgp=c(2.6,0.8,0))
  points(s,s,type="l",col="black",lwd=1,lty=2)
  # Plot Fig. 5.5b
  plot(n.seq,x.mn,xlab="n",type="l",ylab="",col="blue",ylim=yl, cex.axis=1, cex.lab=1.2,mgp=c(2,1,0),lwd=1.5)
  points(n.seq,x.mn-x.sd,type="l",col="blue",lty=2,lwd=1.5)
  points(n.seq,x.mn+x.sd,type="l",col="blue",lty=2,lwd=1.5)
  points(n.seq,y.mn,type="l",col="red",lwd=1.5)
  points(n.seq,y.mn+y.sd,type="l",col="red",lty=2,lwd=1.5)
  points(n.seq,y.mn-y.sd,type="l",col="red",lty=2,lwd=1.5)
  points(n.seq,z.mn,type="l",col="green")
  points(n.seq,z.mn+z.sd,type="l",col="green",lty=2)
  points(n.seq,z.mn-z.sd,type="l",col="green",lty=2)
}


# Numerical computation of alpha^* (for check)
f1<-function(x){
  tanh(x)*pnorm(x)*dnorm(x,a,b)-mu.th*tanh(x)*dnorm(x,a,b)
}
f2<-function(x){
  (pnorm(x)-mu.th)^2*dnorm(x,a,b)
}
alpha.star<-integrate(f1,-Inf,Inf)$value/integrate(f2,-Inf,Inf)$value

print(mean(alpha))
print(alpha.star)

