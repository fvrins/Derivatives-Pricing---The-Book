
# Simulate OU process

r0=0.02
kappa=0.35
theta=0.03
eta=0.001
scheme="exact" # "exact" or "Euler"

T=15
dt=0.01
t=seq(0,T,dt)
nt=length(t)
M=10
M.plot=10

sd=eta/sqrt(2*kappa)*sqrt(1-exp(-2*kappa*dt))

r=matrix(r0,ncol=nt,nrow=M)	# short rate process
R=matrix(0,ncol=nt,nrow=M)	# Integral of short rate process

Z=matrix(rnorm((nt-1)*M),ncol=(nt-1),nrow=M)

for(i in 2:nt){
	if(scheme=="Euler"){
		r[,i]=(1-kappa*dt)*r[,i-1]+kappa*theta*dt+eta*sqrt(dt)*Z[,i-1]
	}else{
		r[,i]=r[,i-1]*exp(-kappa*dt)+theta*(1-exp(-kappa*dt))+sd*Z[,i-1]
	}
	# R = integral of r
	R[,i]=R[,i-1]+r[,i-1]*dt
}

D=exp(-R)
D.avg=colSums(D)/M

par(mfrow=c(1,2))
yl=c(min(r[1:M.plot,]),max(r[1:M.plot,]))
col.v=c("blue","red","green","magenta","cyan","purple","yellow","orange","pink","black")
plot(t,r[1,],type="l",col=col.v[1],ylim=yl,xlab="t",ylab=expression(r[t](omega)),main="Sample paths of OU process")
for(i in 2:M.plot){
	points(t,r[i,],type="l",col=col.v[i])
}
points(c(0,T),rep(theta,2),type="l",lty=3)

# Check ZCB price

B=function(t){
	res=(1-exp(-kappa*t))/kappa
	return(res)
}

A=function(t){
	res=exp((theta-0.5*(eta/kappa)^2)*(B(t)-t)-0.25*(eta/kappa*B(t))^2)
	ind=which(t==0)
	res[ind]=rep(1,length(ind))
	return(res)
}
plot(t,A(t)*exp(-r0*B(t)),type="l",col="blue",xlab="t",ylab=expression(paste("P(0,t) and ",hat(P),"(0,t)")),mgp=c(2,1,0),main="Zero-coupon Bond Price")
s=seq(1,nt,100)
points(t[s],D.avg[s],type="p",col="red")

#dev.new()
#plot(t,r[1,],type="l",col=col.v[1],ylim=yl,xlab="t",ylab=expression(r[t](omega)),main=substitute(list(r0,kappa,theta,eta),list(r0=r0*100,kappa=kappa*100,theta=theta*100,eta=eta*100)),cex.axis=1.5,cex.lab=1.5,mgp=c(2,1,0))
#for(i in 2:M.plot){
#	points(t,r[i,],type="l",col=col.v[i])
#}
#points(c(0,T),rep(theta,2),type="l",lty=3)
