# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 18.6 - Understanding the decomposition of hedging errors through time
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

# ----------------------------------------------------------------------------
# INUPTS
# ----------------------------------------------------------------------------

s0=38
r  	  = 2/100		# risk-free rate
#alpha	= 3*r			# alpha (drift of stock)
K 	  = 36			# strike
sigma = 0.15			# volatility

# ----------------------------------------------------------------------------
# FUNCTIONS
# ----------------------------------------------------------------------------

d = function(tau,x,pm){
  if(pm=="p"){
    y = (r+sigma^2/2)
  }else{
    y = (r-sigma^2/2)
  }
  return( 1/sigma/sqrt(tau)*(log(x/K)+y*tau) )
}
Delta = function(tau,x,option){
  # This is the delta of the option: V_x(t,x)
  if(option=="call"){
    return( pnorm(d(tau,x,"p")) )
  }else{
    return( pnorm(d(tau,x,"p"))-1 )     # put
  }
}
Gamma = function(tau,x,option){
  # This is the gamma of the option: V_xx(t,x) (same for Call andPut)
  return( dnorm(d(tau,x,"p"))/(sigma*x*sqrt(tau)) )
}
Theta = function(tau,x,option){
  # This is the theta of the option: V_t(t,x)
  if(option=="call"){
    return( -r*K*exp(-r*tau)*pnorm(d(tau,x,"m"))-dnorm(d(tau,x,"p"))*sigma*x/(2*sqrt(tau)) )
  }else{
    return( +r*K*exp(-r*tau)*pnorm(-d(tau,x,"m"))-dnorm(d(tau,x,"p"))*sigma*x/(2*sqrt(tau)) )     # put
  }  
}
Call = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( x*pnorm(d(tau,x,"p"))-K*exp(-r*tau)*pnorm(d(tau,x,"m")) )
}
Put = function(tau,x){
  # This is the price of the option: V(t,x)
  # If tau=T-t, this is the time-t Black-Scholes price of Call option on S_t with strike K
  return( K*exp(-r*tau)*pnorm(-d(tau,x,"m"))-x*pnorm(-d(tau,x,"p")) )
}


# ----------------------------------------------------------------------------
# Plot fun
# ----------------------------------------------------------------------------

x=seq(K/4,2*K,0.01*10)
nx=length(x)
xP=seq(K/4,2*K,0.1*10)
SK.call=((xP-K)+abs(xP-K))/2	# max(0,S_t-K) = option exercise price of call
SK.put=((K-xP)+abs(K-xP))/2	# max(0,S_t-K) = option exercise price of put
col.v=c("blue","cyan","green","yellow","pink","magenta","purple","orange","red","brown","black")


# Call f(t,x)
# -----------------------------------------------------------
dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
T=5
x=seq(s0*0.5,s0*1.5,0.1)
plot(x,Call(T,x),type="l",col=col.v[1],lwd=2,ylim=c(-5,25),main="",xlab="Stock price", ylab="Option & Hedge prices")

x.grid=c(22,30,38,46,54)
y.grid=Call(T,x.grid)
y.grid.est=Call(T,s0)+Delta(T,s0,"call")*(x.grid-s0)
n.grid=length(x.grid)

points(x,Call(T,s0)+Delta(T,s0,"call")*(x-s0),type="l",col=col.v[1],lty=2)

for(j in 1:n.grid){			
  points(rep(x.grid[j],2),c(-5,40),type="l",col="gray",lty=3)
  points(c(x[1],x[length(x)]),rep(y.grid[j],2),type="l",col="gray",lty=3)
  points(x.grid[j],y.grid[j],type="p",col=col.v[1],pch=16)
  points(x.grid[j],y.grid.est[j],type="p",col=col.v[1],pch=1)
  
  arrows(x.grid[j], y.grid[j], x.grid[j], y.grid.est[j], length = 0.12, angle = 20,
         code = 3, col = col.v[1])
}

dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
plot(x,(Call(T,s0)+Delta(T,s0,"call")*(x-s0))-Call(T,x),type="l",col=col.v[1],lwd=2,ylim=c(-8,0),main="",xlab="Stock price", ylab="Price of delta-hedged option")


# Call f(t,x)
# -----------------------------------------------------------
col.v=c("blue","orange","green","magenta","pink","orange","red","brown","black")
dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
T=4/12
dt=1/12
t=seq(0,T,dt)
nt=length(t)

x.hedge=c(38,37.010,37.333,36.032,38.637)
v.hedge=c(2.694,1.786,1.802,0.669,2.637)
v.hedge.est=c(2.694,1.886,2.067,1.046,2.403)

delta.hedge=rep(0,nt-1)  
x=seq(36,39,0.1)
plot(x,Call(T,x),type="l",col=col.v[1],lwd=2,ylim=c(0.5,3),xaxt="n",main="",xlab="Stock price", ylab="Option & Hedge prices")
axis(1, at = x.hedge, labels=TRUE)

points(x.hedge[1],v.hedge[1],type="p",col=col.v[1],pch=15,cex=1.8)
points(rep(x.hedge[1],2),c(0,10),type="l",col="grey",lty=3)

for(j in 2:nt){			
  if(j==nt){
    points(x,((x-K)+abs(x-K))/2,type="l",col=col.v[j],lwd=2)
  }else{
    points(x,Call(T-t[j],x),type="l",col=col.v[j],lwd=2)
  }
  points(x.hedge[j],Call(T-t[j-1],x.hedge[j]),type="p",col=col.v[j],pch=1,cex=1.8)
  
  
  points(x.hedge[j],v.hedge[j],type="p",col=col.v[j],pch=16,cex=1.8)
  points(rep(x.hedge[j],2),c(0,10),type="l",col="grey",lty=3)
  
  
  #arrows(x.hedge[j-1], v.hedge[j-1], x.hedge[j], v.hedge[j], length = 0.12, angle = 20,
  #       code = 2, col = col.v[1])
  
  delta.hedge[j-1]=Delta(T-t[j-1],x.hedge[j-1],"call")

  points(x.hedge[j],v.hedge.est[j-1]+delta.hedge[j-1]*(x.hedge[j]-x.hedge[j-1]),type="p",col=col.v[j],pch=0,cex=1.8)
  
  points(x.hedge[j],v.hedge.est[j],type="p",col=col.v[j],pch=15,cex=1.8,lwd=2)
  arrows(x.hedge[j-1], v.hedge.est[j-1], x.hedge[j], v.hedge.est[j], length = 0.2, angle = 20,
         code = 2, col = "black",lty=1,lwd=1.5)
}



# Call f(t,x) wrt t
# -----------------------------------------------------------
dev.new(width=12, height=12, unit="in",noRStudioGD = TRUE)
T=5
dt=0.01
t=seq(0,T,dt)
Delta.0=Delta(T,s0,"call")
Cash.0=Call(T,s0)-Delta.0*s0

plot(t,Call(T-t,s0),type="l",col=col.v[1],lwd=2,ylim=c(0,8),main="",xlab="Time", ylab="Option & Hedge prices")
points(t,Cash.0*exp(r*t)+Delta.0*s0,type="l",col=col.v[1],lty=2)

col.v=c("blue","cyan","green","yellow","pink","magenta","purple","orange","red","brown","black")


#x.grid=c(22,30,38,46,54)
#y.grid=Call(T,x.grid)
#y.grid.est=Call(T,s0)+Delta(T,s0,"call")*(x.grid-s0)
#n.grid=length(x.grid)
#
#points(x,Call(T,s0)+Delta(T,s0,"call")*(x-s0),type="l",col=col.v[1],lty=2)

for(j in 1:nt){			
  #points(rep(x.grid[j],2),c(-5,40),type="l",col="gray",lty=3)
  #points(c(x[1],x[length(x)]),rep(y.grid[j],2),type="l",col="gray",lty=3)
  #points(x.grid[j],y.grid[j],type="p",col=col.v[1],pch=16)
  #points(x.grid[j],y.grid.est[j],type="p",col=col.v[1],pch=1)
  #
  #arrows(x.grid[j], y.grid[j], x.grid[j], y.grid.est[j], length = 0.12, angle = 20,
  #       code = 3, col = col.v[1])
}

dev.new()
plot(t,(Cash.0*exp(r*t)+Delta.0*s0)-Call(T-t,s0),type="l",col=col.v[1],lwd=2,ylim=c(0,5),main="",xlab="Time", ylab="Price of delta-hedged option")

