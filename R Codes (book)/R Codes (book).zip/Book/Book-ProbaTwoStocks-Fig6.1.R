# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
# FIGURE 6.1 -  CDF of two lognormal stock prices
#
# This version : 15/3/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

s01=32
s02=18
x=(s01+s02)*0.9
mu1=0.05
mu2=0.03
sigma1=0.25
sigma2=0.1

zmax=(log(x/s01)-mu1)/sigma1-0.01

rho=seq(-0.99,0.99,.01)
n.rho=length(rho)
r=rep(0,n.rho)


for(i in 1:n.rho){
  rhoi=rho[i]
  Phig=function(z)
  {
    pnorm((log((x-s01*exp(mu1+sigma1*z))/s02)-mu2-sigma2*rhoi*z)/(sigma2*sqrt(1-rhoi^2)))*dnorm(z)
  }
  r[i]=integrate(Phig,-Inf,zmax)$value
}

plot(rho,r,type="l",col="blue",xlab="x",ylab=expression(P(Pi[T]<=x)), cex.axis=1.2, cex.lab=1.2,mgp=c(2,1,0),lwd=1.5)
grid(nx = NULL, ny = NULL, col = "lightgray", lty = "dotted",
     lwd = par("lwd"), equilogs = TRUE)