
# ==============================================================================
# Code associated with the book
# DERIVATIVES PRICING
# Cambridge university press, forthcoming
#
#  Exercise 10.5
#
# This version : 11/10/2024
# Author : Frédéric Vrins
# frederic.vrins@uclouvain.be - https://sites.google.com/view/fredericvrins
#
# Comment: This code aims to be pedagogical, not to be optimal 
# ==============================================================================

# Clean workspace
rm(list = ls())

Ti<-c(1,3,4,8,15)
mu<-0.1
sigma<-0.2
S0<-32
alpha<-mu-sigma^2/2

N     = 1000   # nb of Monte Carlo simulations

# distribution from which we want to sample (can be changed)
k<-length(Ti)
T.vec<-c(0,Ti)
Delta<-diff(T.vec)
nT<-k+1

S<-matrix(ncol=k,nrow=N)
ProdLnSTi<-rep(0,N)
for(i in 1:N){
  w<-cumsum(rnorm(k)*sqrt(Delta))
  S[i,]<-S0*exp(alpha*Ti+sigma*w)
  ProdLnSTi[i]<-log(prod(S[i,]))
}

muProd.MC<-mean(ProdLnSTi)
sigmaSquaredProd.MC<-var(ProdLnSTi)

coef<-seq(k,1,-1)#(k+1-seq(1,k))
a<-k*log(S0)+alpha*(coef%*%Delta)
bSquared<-as.vector(sigma^2*((coef^2)%*%Delta))

# check that the frequencies are in line with the probabilities
dev.new()
x<-a+sqrt(bSquared)*seq(-3,3,0.01)
hist(ProdLnSTi,col="blue",prob="True")
points(x,dnorm(x,a,sqrt(bSquared)),col="red",type="l",lwd=2)
